//
//  ButtonCell.h
//  Kuipp
//
//  Created by Brandon Jue on 3/12/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ButtonCell : UITableViewCell {
	BOOL noStretch;
	
	UIButton *button;
}

@property(nonatomic,assign) BOOL noStretch;
@property(nonatomic,retain) UIButton *button;

@end
