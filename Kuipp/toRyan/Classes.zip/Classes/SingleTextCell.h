//
//  SingleTextCell.h
//  Kuipp
//
//  Created by Brandon Jue on 2/3/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SingleTextCell : UITableViewCell {
	IBOutlet UILabel *text;
}

@property(nonatomic,retain) UILabel *text;

@end
