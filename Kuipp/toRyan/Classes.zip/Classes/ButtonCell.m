//
//  ButtonCell.m
//  Kuipp
//
//  Created by Brandon Jue on 3/12/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "ButtonCell.h"

@implementation ButtonCell

@synthesize noStretch,button;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        // Initialization code.
		button = [[UIButton buttonWithType:UIButtonTypeCustom]retain];
		[button setBackgroundImage:[Misc buttonCell]forState:UIControlStateNormal];
		[button setTitleColor:[UIColor darkGrayColor]forState:UIControlStateNormal];
		button.titleLabel.font = [UIFont boldSystemFontOfSize:24];
		
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		
		[self.contentView addSubview:button];
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	CGRect c = self.contentView.bounds;
	double w = c.size.width;
	double h = c.size.height;
	
	double buf = [Misc buffer];
	
	CGRect a = self.accessoryView.frame;
	double aw = (self.accessoryView==nil?0:(a.size.width+buf*2));
	
	if (noStretch) {
		double bw = button.currentBackgroundImage.size.width;
		double bh = button.currentBackgroundImage.size.height;
		button.frame = CGRectMake((w-bw)/2,(h-bh)/2,bw,bh);
	} else {
		button.frame = CGRectMake(buf*2,buf,w-buf*4+aw,h-buf*2);
	}

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}

- (void)dealloc {
	[button release];
	
    [super dealloc];
}

@end
