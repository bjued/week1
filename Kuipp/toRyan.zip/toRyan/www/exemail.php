<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Email Test</title>
</head>

<body>
<center>Mass Mail</center>
<form action="emailUser.php" method="post">
From Email: <input type="text" name="from"><br><br>
Password: <input type="password" name="pwd"><br><br>
To Emails: <textarea name="to" rows="4" col="200"></textarea><br><br>
Subject: <input type="text" name="subject"><br><br>
Body: <textarea name="body" rows="4" col="200"></textarea><br><br>
<input type="Submit">
</form>
</body>
</html>
