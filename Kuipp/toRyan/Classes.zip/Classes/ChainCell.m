//
//  ChainCell.m
//  Kuipp
//
//  Created by Brandon Jue on 2/2/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "ChainCell.h"
#import "KuippAppDelegate.h"
#import "Profile.h"

@implementation ChainCell

@synthesize nameID,pic,name,icon,primary1,primary2,uclass,secondary;

- (IBAction)nameTouched:(UIButton*)sender {
	Profile *v = [[Profile alloc]init];
	v.uid = nameID;
	[((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).navigationController pushViewController:v animated:YES];
	[v release];
}

#pragma mark -
#pragma mark Initialization

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad {
 [super viewDidLoad];
 }
 */

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)dealloc {
	[pic release];
	[name release];
	[icon release];
	[primary1 release];
	[primary2 release];
	[uclass release];
	[secondary release];
	
    [super dealloc];
}

@end
