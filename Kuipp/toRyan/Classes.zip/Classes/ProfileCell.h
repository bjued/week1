//
//  ProfileCell.h
//  Kuipp
//
//  Created by Brandon Jue on 3/14/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileCell : UITableViewCell {
	NSDictionary *dict;
	
	UIView *nmVw;
	UILabel *name;
	UIView *blkV;
	UITextView *blck;
	
	UIView *picV;
	UIControl *picC;
	UIImageView *picW;
	
	UIView *txtV;
	UILabel *txt1;
	UILabel *txt2;
	UILabel *txt3;
	UILabel *txt4;
	UILabel *txt5;
	
	UIView *medV;
	UIControl *medC;
	UIImageView *medI;
	UILabel *medT;
	UILabel *medL;
	UIImageView *medA;
	
	UIView *intV;
	UIControl *intC;
	UIImageView *intI;
	UILabel *intT;
	UILabel *intL;
	UIImageView *intA;
	
	UIView *lvlV;
	UIImageView *lvlI;
	UILabel *lvlC;
}

@property(nonatomic,retain) NSDictionary *dict;
@property(nonatomic,retain) UIControl *picC,*medC,*intC;
@property(nonatomic,retain) UIImageView *picW,*lvlI;
@property(nonatomic,retain) UILabel *name,*txt1,*txt2,*txt3,*txt4,*txt5,*medL,*intL,*lvlC;
@property(nonatomic,retain) UITextView *blck;

@end
