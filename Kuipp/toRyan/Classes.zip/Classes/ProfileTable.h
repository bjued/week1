//
//  ProfileTable.h
//  Kuipp
//
//  Created by Brandon Jue on 2/3/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileTable : UIViewController <UITableViewDelegate,UISearchBarDelegate> {
	NSString *uid;
	
	NSMutableArray *dicts;
	NSMutableArray *heads;
	
	NSMutableArray *searchResults;
	
	int tab;
	IBOutlet UITableView *table;
	IBOutlet UISearchBar *search;
}

@property(nonatomic,retain) NSString* uid;
@property(nonatomic,assign) int tab;
- (IBAction)popBack:(UIButton*)sender;
- (IBAction)refresh:(UIButton*)sender;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
