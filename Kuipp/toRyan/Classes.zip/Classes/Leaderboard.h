//
//  Leaderboard.h
//  Kuipp
//
//  Created by Brandon Jue on 3/14/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Leaderboard : UIViewController <UIScrollViewDelegate,UITableViewDelegate> {
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableDictionary *images;
	
	RefreshCell *refreshCell;
	
	NSMutableArray *tabResults;
	
	// Views
	IBOutlet UITableView *table;
	
	// Tabs
	IBOutlet UIButton *aButton;
	IBOutlet UIButton *fButton;
}

- (void)back;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (IBAction)filter:(UIButton*)sender;
- (void)reloadView;
- (void)reloadTable;

@end
