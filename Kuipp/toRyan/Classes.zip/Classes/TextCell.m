//
//  TextCell.m
//  Kuipp
//
//  Created by Brandon Jue on 3/13/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "TextCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation TextCell

@synthesize selectable,main,foot;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        // Initialization code.
		cell = [[UIView alloc]init];
		cell.layer.masksToBounds = NO;
		cell.layer.cornerRadius = [Misc borderCurve];
		cell.layer.borderColor = [[Misc kuippOrangeColor]CGColor];
		cell.layer.borderWidth = [Misc border];
		
		main = [[UILabel alloc]init];
		main.backgroundColor = [UIColor clearColor];
		main.font = [main.font fontWithSize:[Misc mainSize]];
		main.textColor = [UIColor grayColor];
		main.numberOfLines = 0;
		main.lineBreakMode = UILineBreakModeTailTruncation;
		
		foot = [[UILabel alloc]init];
		foot.backgroundColor = [UIColor clearColor];
		foot.font = [foot.font fontWithSize:[Misc footSize]];
		foot.textColor = [UIColor lightGrayColor];
		
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		
		[self.contentView addSubview:cell];
		[cell addSubview:main];
		[cell addSubview:foot];
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect c = self.contentView.bounds;
	double w = c.size.width;
	double h = c.size.height;
	
	double buf = [Misc buffer];
	
	CGRect a = self.accessoryView.frame;
	double aw = (self.accessoryView==nil?0:(a.size.width+10));
	
	cell.frame = CGRectMake(buf*2,buf,w-buf*4+aw,h-buf*2);
	
	c = cell.frame;
	w = c.size.width-(self.accessoryView==nil?0:a.size.width);
	h = c.size.height;
	double mh = fmin([Misc heightForFontSize:[Misc mainSize]]*2,[Misc heightForText:main.text width:w-buf*2 size:[Misc mainSize]]);
	double fh = foot.numberOfLines==0?[Misc heightForText:foot.text width:w-buf*2 size:[Misc footSize]]:[Misc heightForFontSize:[Misc footSize]];
	
	main.frame = CGRectMake(buf,     buf,w-buf*2,mh);
	foot.frame = CGRectMake(buf,h-fh-buf,w-buf*2,fh);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	cell.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)setHighlighted:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	cell.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)dealloc {
	[main release];
	[foot release];
	
    [super dealloc];
}

@end
