//
//  ChainCell.h
//  Kuipp
//
//  Created by Brandon Jue on 2/2/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChainCell : UITableViewCell {
	NSString *nameID;
	IBOutlet UIImageView *pic;
	IBOutlet UIButton *name;
	IBOutlet UIImageView *icon;
	IBOutlet UILabel *primary1;
	IBOutlet UILabel *primary2;
	IBOutlet UILabel *uclass;
	IBOutlet UILabel *secondary;
}

@property(nonatomic,retain) NSString *nameID;
@property(nonatomic,retain) UIImageView *pic;
@property(nonatomic,retain) UIButton *name;
@property(nonatomic,retain) UIImageView *icon;
@property(nonatomic,retain) UILabel *primary1;
@property(nonatomic,retain) UILabel *primary2;
@property(nonatomic,retain) UILabel *uclass;
@property(nonatomic,retain) UILabel *secondary;
- (IBAction)nameTouched:(UIButton*)sender;

@end
