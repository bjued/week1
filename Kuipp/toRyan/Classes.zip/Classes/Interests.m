//
//  Interests.m
//  Kuipp
//
//  Created by Brandon Jue on 3/16/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "Interests.h"
#import "Profile.h"
#import "AnswerTab.h"

@implementation Interests

@synthesize uid;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)refreshAll {[kuipp formTo:@"selectInterests" WithPost:[NSString stringWithFormat:@"uid=%@",uid]];}

- (void)refresh:(id)obj {
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[table reloadData];
}

- (void)refreshCountKey {count.text = [NSString stringWithFormat:@"%d",50-[interest.text length]];}

- (void)cancel {
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	
	if ([uid intValue]==[[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue]||[uid intValue]==0) {
		self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Add"];
		UIButton *b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
		[b addTarget:self action:@selector(addInterests) forControlEvents:UIControlEventTouchUpInside];
	} else {
		self.navigationItem.rightBarButtonItem = nil;
	}
	
	[interest resignFirstResponder];
}

- (void)addInterests {
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Cancel"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Submit"];
	b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(add:) forControlEvents:UIControlEventTouchUpInside];
	
	interest.text = @"";
	[self refreshCountKey];
	
	[interest becomeFirstResponder];
}

- (IBAction)add:(UIButton*)sender {
	if ([interest.text length]==0) {
		NSLog(@"There is no keyword!");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Oops!"
				 message:@"You must be interested in something!"
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else {
		[self add];
	}
}

- (void)add {
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = NO;
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *p = [NSString stringWithFormat:
				   @"&uid=0&int=%@",
				   [interest.text urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"insertInterest" WithPost:p AndResponse:&response AndError:&error];
	
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	NSString *inter = [[interest.text lowercaseString]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	[del.interests setObject:[urlContents substringFromIndex:2]forKey:inter];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:inter,@"keyword", nil]];
	
	[table reloadData];//[self refreshAll];
	[self cancel];
}

- (void)deleteInterest:(int)index {
	NSString *removeMe = [[dicts objectAtIndex:index]objectForKey:@"keyword"];
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=%@&int=%@",
							[uid urlEncode],
							[removeMe urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"deleteInterests" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	[del.interests removeObjectForKey:removeMe];
	[dicts removeObjectAtIndex:index];
	
	[table reloadData];//[self refreshAll];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return [dicts count];}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *c = [tableView dequeueReusableCellWithIdentifier:@"A"];
	if (!c) c = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"A"]autorelease];
	
	NSString *word = [[dicts objectAtIndex:indexPath.row]objectForKey:@"keyword"];
	
	c.textLabel.text = word;
	c.textLabel.textColor = [Misc kuippOrangeColor];
	
	if (![[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]isEqualToString:uid]) {
		KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
		UILabel *av = [[UILabel alloc]init];
		av.textColor = [UIColor whiteColor];
		av.backgroundColor = [UIColor clearColor];
		av.font = [UIFont systemFontOfSize:[Misc mainSize]];
		if ([del.interests objectForKey:word]) {
			av.text = @"Common Interest";
		} else {
			av.text = @"Add this Interest";
		}
		[av sizeToFit];
		c.accessoryView = av;
		[av release];
	}
	
	c.selectionStyle = UITableViewCellSelectionStyleBlue;
	
	return c;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {return YES;}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
	if (editingStyle == UITableViewCellEditingStyleDelete) {
		[self deleteInterest:indexPath.row];
	}
}

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {return 44;}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	NSString *word = [[dicts objectAtIndex:indexPath.row]objectForKey:@"keyword"];
	if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]isEqualToString:uid]) {
		int i = indexPath.row;
		
		AnswerTab *a = [[AnswerTab alloc]init];
		[a selectInterest:i:[NSString stringWithFormat:@"*k%@",word]];
		NSArray *r = [NSArray arrayWithObjects:a,nil];
		[(UINavigationController*)[[self.tabBarController viewControllers]objectAtIndex:1]setViewControllers:r];
		[self.tabBarController setSelectedIndex:1];
		[a release];
	} else if (![((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).interests objectForKey:word]) {
		NSURLResponse *response;
		NSError *error;
		
		NSString *p = [NSString stringWithFormat:
					   @"&uid=0&int=%@",
					   [word urlEncode]];
		
		NSString *urlContents = [KuippConnect formTo:@"insertInterest" WithPost:p AndResponse:&response AndError:&error];
		
		((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
		
		if ([urlContents length]==0) return;
		
		if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
		
		KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
		[del.interests setObject:[urlContents substringFromIndex:2]forKey:[[word lowercaseString]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
		
		[table reloadData];
	}
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	top.frame = CGRectMake(top.frame.origin.x,-200+delta*200,top.frame.size.width,top.frame.size.height);
	bot.frame = CGRectMake(bot.frame.origin.x,367-delta*(kb.size.height-49),bot.frame.size.width,bot.frame.size.height);
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {[self keyboardAdjust:note:1];}

- (void)keyboardWasHidden:(NSNotification*)note {[self keyboardAdjust:note:0];}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[self add:nil];
	return YES;
}

- (BOOL)textField:(UITextField*)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString*)string {
	int newCount = [count.text intValue]-[string length]+range.length;
	if (newCount<0) return NO;
	count.text = [NSString stringWithFormat:@"%d",newCount];
	return YES;
}

#pragma mark -
#pragma mark Initialization
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	[Misc load:self];
	
	if (uid==nil) uid = @"0";
	
	if ([uid intValue]==[[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue]||[uid intValue]==0) {
		self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Add"];
		UIButton *b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
		[b addTarget:self action:@selector(addInterests) forControlEvents:UIControlEventTouchUpInside];
	}
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	
	if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]isEqualToString:uid]) {
		KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
		
		dicts = [[NSMutableArray alloc]init];
		for (NSString *key in [del.interests allKeys]) [dicts addObject:[NSDictionary dictionaryWithObject:key forKey:@"keyword"]];
		[table reloadData];
	} else {
		[self refreshAll];
	}
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[dicts release];
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	NSArray *a = [self.navigationController viewControllers];
	if ([a count]>1) {
		Profile *p = (Profile*)[a objectAtIndex:[a count]-1];
		if (p.firstTime) [p profileTutorial:3];
	}
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[uid release];
	table.delegate = nil;
	table.dataSource = nil;
	interest.delegate = nil;
	
    [super dealloc];
}

@end
