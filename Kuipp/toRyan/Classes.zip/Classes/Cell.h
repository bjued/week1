//
//  Cell.h
//  Kuipp
//
//  Created by Brandon Jue on 3/9/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Cell : UITableViewCell {
	BOOL selectable;
	
	NSDictionary *dict;
	
	UIView *pict;
	UIView *cell;
	UIView *back;
	
	UIControl *ctrl;
	UIImageView *imag;
	UIButton *name;
	UILabel *main;
	UILabel *foot;
}

@property(nonatomic,assign) BOOL selectable;
@property(nonatomic,retain) NSDictionary *dict;
@property(nonatomic,retain) UIView *cell,*back;
@property(nonatomic,retain) UIControl *ctrl;
@property(nonatomic,retain) UIImageView *imag;
@property(nonatomic,retain) UIButton *name;
@property(nonatomic,retain) UILabel *main,*foot;

@end
