//
//  KuippIt.m
//  Kuipp
//
//  Created by Brandon Jue on 1/4/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "KuippIt.h"
#import "Question.h"
#import "KuippConnect.h"
#import "Parser.h"

@implementation KuippIt

- (IBAction)popBack:(UIButton*)sender {
	[self.navigationController popToViewController:[[self.navigationController viewControllers]objectAtIndex:1] animated:YES];
}

- (void)refresh {
	NSURLResponse *response;
	NSError *error;
	
	NSString *urlContents = [KuippConnect formTo:@"selectKuippIt" WithPost:@"" AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:1]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode forView:self]) return;
	
	if (dicts!=nil) [dicts release];
	if (heads!=nil) [heads release];
	dicts = [[NSMutableArray alloc]init];
	heads = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts AndHeads:heads];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	
	[kuipp setText:@"What would you like to Kuipp?"];
	[self refreshCategory];
	[self refreshFollowers];
	[self refreshCount];
}

- (void)refreshCategory {
	if (catID==-1) [category setTitle:[NSString stringWithFormat:@"Select A Category"]forState:UIControlStateNormal];
	else [category setTitle:[[catArray objectAtIndex:catID]objectForKey:@"category"]forState:UIControlStateNormal];
}

- (void)refreshFollowers {
	NSString *string = @"";
	NSDictionary *dict;
	for (dict in folArray) {
		if ([dict objectForKey:@"directKuipp"]!=nil) {
			string = [string stringByAppendingFormat:@", %@ %@.",[dict objectForKey:@"firstName"],[[dict objectForKey:@"lastName"]substringToIndex:1]];
		}
	}
	if ([string length]==0) {
		directing.titleLabel.textAlignment = UITextAlignmentCenter;
		directing.titleLabel.font = [directing.titleLabel.font fontWithSize:15];
		[directing setTitle:@"Choose Followers" forState:UIControlStateNormal];
	} else {
		directing.titleLabel.textAlignment = UITextAlignmentLeft;
		directing.titleLabel.font = [directing.titleLabel.font fontWithSize:12];
		[directing setTitle:[string substringFromIndex:2]forState:UIControlStateNormal];
	}
	
}

- (void)refreshCount {	
	[count setText:[NSString stringWithFormat:@"%d",150-[kuipp.text length]]];
}

- (void)splitData {
	if (catArray!=nil) [catArray release];
	if (folArray!=nil) [folArray release];
	
	catArray = [[NSMutableArray alloc]init];
	folArray = [[NSMutableArray alloc]init];
	
	for (int i=0;i<[heads count];i++) {
		if ([[heads objectAtIndex:i] isEqualToString:@"Categories"]) {
			[catArray addObject:[dicts objectAtIndex:i]];
		} else if ([[heads objectAtIndex:i] isEqualToString:@"Followers"]) {
			[folArray addObject:[dicts objectAtIndex:i]];
		}
	}
}

- (IBAction)category:(UIButton*)sender {
	[keywords resignFirstResponder];
	[kuipp resignFirstResponder];
	
	CGRect nf = CGRectMake(0,0,320,460);
	UIView *overlay = [[UIView alloc]initWithFrame:nf];
	[overlay setBackgroundColor:[UIColor blackColor]];
	[overlay setAlpha:.25];
	[self.view addSubview:overlay];
	[overlay release];
	
	CGRect newFrame = CGRectMake(4,4,312,fmin(452,[catArray count]*30));
	if (catTable!=nil) [catTable release];
	catTable = [[UITableView alloc]initWithFrame:newFrame style:UITableViewStylePlain];
	[catTable setDelegate:self];
	[catTable setDataSource:self];
	[catTable setRowHeight:30];
	[self.view addSubview:catTable];
	
	[catTable reloadData];
}

- (IBAction)direct:(UIButton*)sender {
	[keywords resignFirstResponder];
	[kuipp resignFirstResponder];
	
	CGRect nf = CGRectMake(0,0,320,460);
	UIView *overlay = [[UIView alloc]initWithFrame:nf];
	[overlay setBackgroundColor:[UIColor blackColor]];
	[overlay setAlpha:.25];
	[self.view addSubview:overlay];
	[overlay release];
	
	CGRect newFrame = CGRectMake(4,4,312,fmin(452,([folArray count]+1)*30));
	if (folTable!=nil) [folTable release];
	folTable = [[UITableView alloc]initWithFrame:newFrame style:UITableViewStylePlain];
	[folTable setDelegate:self];
	[folTable setDataSource:self];
	[folTable setRowHeight:30];
	[self.view addSubview:folTable];
	
	[folTable reloadData];
}

- (IBAction)pub:(UIButton*)sender{
	isPublic = YES;
	
	[pub setBackgroundColor:[UIColor cyanColor]];
	[pri setBackgroundColor:[UIColor colorWithWhite:.9 alpha:1]];
}

- (IBAction)pri:(UIButton*)sender {
	isPublic = NO;
	
	[pri setBackgroundColor:[UIColor cyanColor]];
	[pub setBackgroundColor:[UIColor colorWithWhite:.9 alpha:1]];
}

- (IBAction)submit:(UIButton*)sender {
	if ([kuipp.text length]==0) {
		NSLog(@"There isn't a Kuipp to send.");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Error"
				 message:@"There isn't a Kuipp to send."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else if (!isPublic&&[[self directToFollowerIDs]length]==0) {
		NSLog(@"PRIVATE Kuipp sent to NOBODY");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Error"
				 message:@"Nobody can answer this Kuipp! Either make it public or direct it to a follower."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else if (catID<0) {
		NSLog(@"No Category");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Error"
				 message:@"You need to select a Category."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else {
		[manager startUpdatingLocation];
	}
}

- (void)submit {
	if (userLoc==nil) return;
	[manager stopUpdatingLocation];
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=0"
							@"&cid=%@"
							@"&qtn=%@"
							@"&key=%@"
							@"&lat=%.8f"
							@"&lon=%.8f"
							@"&pub=%@"
							@"&dir=%@",
							[[catArray objectAtIndex:catID]objectForKey:@"categoryID"],
							kuipp.text,
							keywords.text,
							userLoc.coordinate.latitude,
							userLoc.coordinate.longitude,
							isPublic?@"on":@"off",
							[self directToFollowerIDs]];

	NSString *urlContents = [KuippConnect formTo:@"insertQuestion" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:2]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode/10 forView:self]) return;
	if (![KuippConnect myKuippsCode:exitCode%10 forView:self]) return;
	
	if (qDicts!=nil) [qDicts release];
	if (qHeads!=nil) [qHeads release];
	qDicts = [[NSMutableArray alloc]init];
	qHeads = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:qDicts AndHeads:qHeads];
	[parse parseXML:[urlContents substringFromIndex:2]];
	[parse release];
	
	Question *question = [[Question alloc]init];
	question.qid =	[[NSDictionary dictionaryWithDictionary:[qDicts objectAtIndex:0]]objectForKey:@"questionID"];
	NSMutableArray *views = [NSMutableArray arrayWithArray:[self.navigationController viewControllers]];
	[views removeLastObject];
	[views addObject:question];
	[self.navigationController setViewControllers:views animated:YES];
	[question release];
	 
}

- (NSString*)directToFollowerIDs {
	NSString *string = @"";
	NSDictionary *dict;
	for (dict in folArray) {
		if ([dict objectForKey:@"directKuipp"]!=nil) {
			string = [string stringByAppendingFormat:@",%@",[dict objectForKey:@"userID"]];
		}
	}
	if ([string length]>0) string = [string substringFromIndex:1];
	return string;
}

- (IBAction)backgroundTouched:(UIControl*)sender {
	[kuipp resignFirstResponder];
	[keywords resignFirstResponder];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	if (tableView==catTable) return [catArray count];
	if (tableView==folTable) return [folArray count]+1;
	return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
	if (cell==nil) cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"]autorelease];
	
    // Configure the cell...
	NSDictionary *dict;
	if (tableView==catTable) {
		dict = [catArray objectAtIndex:indexPath.row];
		cell.textLabel.text = [dict objectForKey:@"category"];
	}
	if (tableView==folTable) {
		if (indexPath.row==0) cell.textLabel.text = @"Done";
		else {
			dict = [folArray objectAtIndex:indexPath.row-1];
			
			if ([dict objectForKey:@"directKuipp"]!=nil) cell.accessoryType = UITableViewCellAccessoryCheckmark;
			else cell.accessoryType = UITableViewCellAccessoryNone;

			cell.textLabel.text = [NSString stringWithFormat:@"%@ %@.",[dict objectForKey:@"firstName"],[[dict objectForKey:@"lastName"]substringToIndex:1]];
		}
	}
    
    return cell;
}
/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */
/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
	
	if (editingStyle == UITableViewCellEditingStyleDelete) {
		// Delete the row from the data source
		[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
	}   
	else if (editingStyle == UITableViewCellEditingStyleInsert) {
		// Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
	}   
}
 */
/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */
/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */
#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if (tableView==catTable) {
		catID = indexPath.row;
		[tableView removeFromSuperview];
		catTable = nil;
		[self refreshCategory];
		
		NSArray *views = [self.view subviews];
		[[views objectAtIndex:[views count]-1]removeFromSuperview];
	}
	if (tableView==folTable) {
		if (indexPath.row==0) {
			[folTable removeFromSuperview];
			folTable = nil;
			NSArray *views = [self.view subviews];
			[[views objectAtIndex:[views count]-1]removeFromSuperview];
		} else {
			NSMutableDictionary *dict = [folArray objectAtIndex:indexPath.row-1];
			if ([dict objectForKey:@"directKuipp"]==nil) [dict setObject:@"1" forKey:@"directKuipp"];
			else [dict removeObjectForKey:@"directKuipp"];
			[folArray replaceObjectAtIndex:indexPath.row-1 withObject:dict];
			[folTable reloadData];
			[self refreshFollowers];
		}
	}
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	if (viewMoved&&delta==1) return;
	
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	int shiftView = 40;
	
	CGRect frame = self.view.frame;
	frame.origin.y -= delta*shiftView;
	frame.size.height += delta*shiftView;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	self.view.frame = frame;
	[UIView commitAnimations];	
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	viewMoved = YES;
}

- (void)keyboardWasHidden:(NSNotification*)note {
    if (!viewMoved) return;
	[self keyboardAdjust:note:-1];
	viewMoved = NO;
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[textField resignFirstResponder];
	return YES;
}

#pragma mark -
#pragma mark UITextViewDelegate

- (void)textViewDidChange:(UITextView *)textView {
	[self refreshCount];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
	if ([text isEqualToString:@"\n"]) {
		[textView resignFirstResponder];
		return NO;
	}
	int newCount = [count.text intValue]-[text length]+range.length;
	if (newCount<0) {
		return NO;
	}
	return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
	if ([textView.text isEqualToString:@"What would you like to Kuipp?"]) textView.text = @"";
}

#pragma mark -
#pragma mark CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager*)manager didUpdateToLocation:(CLLocation*)newLocation fromLocation:(CLLocation*)oldLocation {
	userLoc = newLocation;
	
	[self submit];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
	NSLog(@"%@",error);
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Session Error"]) {
		[self.navigationController popToRootViewControllerAnimated:YES];
	}
}

#pragma mark -
#pragma mark Initialization

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/
/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/
- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	manager = [[CLLocationManager alloc]init];
	[manager setDelegate:self];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	
	catID = -1;
	
	[self pub:nil];
	
	[self refresh];
}

- (void)viewWillDisappear:(BOOL)animated {
	[manager release];
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	[super viewWillDisappear:animated];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}

@end
