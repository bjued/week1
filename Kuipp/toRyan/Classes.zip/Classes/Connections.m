//
//  Connections.m
//  Kuipp
//
//  Created by Brandon Jue on 1/4/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "Connections.h"
#import "LeaderCell.h"
#import "Profile.h"
#import "Settings.h"
#import "ASyncImageLoadDelegate.h"

@implementation Connections

@synthesize uid,tab;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)mainThreadImages {
	[images release];
	images = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images retain];
	for (NSDictionary *d in tabArray) {
		NSString *url = [d objectForKey:@"picture"];
		NSString *pic = [images objectForKey:url];
		if (pic==nil||[pic isEqual:[Misc defaultProfile]]) {
			[images setObject:[Misc defaultProfile]forKey:url];
			if (![url isEqualToString:[Misc defaultProfileURL]]) {
				ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
				[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
			}
		}
	}
}

- (void)aSyncImageLoaded {[table reloadData];}

- (void)refreshAll {
	[refreshCell refreshing];
	
	[kuipp cancel];
	NSString *p = [NSString stringWithFormat:
				   @"&uid=%@&lid=%@&cnt=%@&sch=%@",
				   [uid urlEncode],
				   [[lastIDs objectAtIndex:tab]urlEncode],
				   [[counts objectAtIndex:tab]urlEncode],
				   [search.text urlEncode]];
	
	switch (tab) {
		case  0: [kuipp formTo:@"selectUserFollowing" WithPost:p];break;
		case  1: [kuipp formTo:@"selectUserFollowers" WithPost:p];break;
		default: break;
	}
}

- (void)refreshMore {
	[lastIDs replaceObjectAtIndex:tab withObject:@""];
	NSString *cnt = [counts objectAtIndex:tab];
	cnt = [NSString stringWithFormat:@"%d",cnt?[cnt intValue]+1:1];
	[counts replaceObjectAtIndex:tab withObject:cnt];
	
	[self refreshAll];
	
	[moreCell startAnimating];
}

/*- (void)refreshAll {
	switch (tab) {
		case  0:	[self following:followingButton];break;
		case  1:	[self followers:followersButton];break;
		default:	break;
	}
}*/

- (void)refresh:(id)obj {
	if ([moreCell isAnimating]) [moreCell stopAnimating];
	
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[tabArray release];
	tabArray = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:tabArray];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	NSString *lid = [lastIDs objectAtIndex:tab];
	for (NSDictionary *user in tabArray) {
		NSString *name = [[user objectForKey:@"firstName"]stringByAppendingFormat:@" %@",[user objectForKey:@"lastName"]];
		if ([lid localizedCaseInsensitiveCompare:name]==NSOrderedAscending) {
			lid = name;
		}
	}
	[lastIDs replaceObjectAtIndex:tab withObject:lid];
	[self mainThreadImages];
	
	[refreshCell refreshed];
	
	[searchArray release];
	searchArray = [[NSMutableArray alloc]initWithArray:tabArray];
	
	[table reloadData];
	double rch = table.tableHeaderView.frame.size.height;
	if (table.contentOffset.y<rch) [table setContentOffset:CGPointMake(0,table.tableHeaderView.frame.size.height) animated:[Misc tableHideHeaderAnimated]];
}

- (IBAction)following:(UIButton*)sender {
	if (tab==0) return;
	
	tab = 0;
	
	[self selectTab:sender];
	
	[self refreshAll];
	
	[search setText:@""];
	[search setPlaceholder:@"Search Users You're Following"];
}

- (IBAction)followers:(UIButton*)sender {
	if (tab==1) return;
	
	tab = 1;
	
	[self selectTab:sender];
	
	[self refreshAll];
	
	[search setText:@""];
	[search setPlaceholder:@"Search Users Following You"];
}

- (void)selectTab:(UIButton*)sender {
	[search resignFirstResponder];	
	
	[followingButton setBackgroundImage:[Misc wideTabImage:sender==followingButton]forState:UIControlStateNormal];
	[followersButton setBackgroundImage:[Misc wideTabImage:sender==followersButton]forState:UIControlStateNormal];
	table.contentOffset = CGPointMake(0,table.tableHeaderView.frame.size.height);
}

- (IBAction)backgroundTouched:(UIControl*)sender {
	[search resignFirstResponder];
}

- (void)deleteFollowing:(int)index {
	NSDictionary *d = [tabArray objectAtIndex:index];
	NSString *user = [d objectForKey:@"userID"];
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=%@&fid=%@",
							[uid urlEncode],
							[user urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"deleteFollowing" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	[del.followingIDs removeObjectForKey:user];
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Success"
						  message:[NSString stringWithFormat:@"You are no longer following %@",[Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]]]
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
	
	[self refreshAll];
}

- (void)findFriends {
	Settings *v = [[Settings alloc]init];
	v.findFriends = YES;
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return [searchArray count];}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	LeaderCell *c = (LeaderCell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
	if (!c) c = [[[LeaderCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"A"]autorelease];
	
	NSDictionary *d = [searchArray objectAtIndex:indexPath.row];
	
	c.dict = d;
	
	c.rank.text = @"";
	
	c.imag.image = [images objectForKey:[d objectForKey:@"picture"]];
	
	c.name.text = [Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]];
	
	c.foot.text = [NSString stringWithFormat:@"Level %@ %@",[d objectForKey:@"level"],[d objectForKey:@"class"]];
	c.selectable = YES;
	
	c.accessoryView = [Misc detailDisclosure];
	
	return c;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
	return (tab==0&&([uid intValue]==0||[uid isEqualToString:[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]]))?YES:NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
	if (editingStyle == UITableViewCellEditingStyleDelete) {
		[self deleteFollowing:indexPath.row];
	}
}

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {return [Misc buffer]*2+[Misc leaderSize];}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	NSDictionary *dict = [searchArray objectAtIndex:indexPath.row];
	Profile *v = [[Profile alloc]init];
	v.uid = [[NSString alloc]initWithString:[dict objectForKey:@"userID"]];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

#pragma mark -
#pragma mark UIScrollView

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	CGSize c = scrollView.contentSize;
	CGSize f = scrollView.frame.size;
	if (s.y<0&&![kuipp fetchingData]) {
		if (!refreshCell.flipped) [refreshCell flip];
	} else if (c.height-table.tableHeaderView.frame.size.height>f.height&&s.y>c.height-f.height&&![kuipp fetchingData]) {
		[self refreshMore];
	} else {
		if (refreshCell.flipped) [refreshCell flip];
	}
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		[self refreshAll];
	}
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	/*NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	int shiftView = 37;
	double w = self.view.frame.size.width;
	double h = self.view.frame.size.height;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	if (delta==0) {
		table.frame = CGRectMake(0,shiftView,w,h-shiftView);
		self.view.frame = CGRectMake(0,0,w,h);
		table.contentOffset = CGPointMake(0,table.tableHeaderView.frame.size.height);
	} else {
		self.view.frame = CGRectMake(0,0-shiftView,w,h);
		table.frame = CGRectMake(0,shiftView,w,h-kb.size.height+49);
		table.contentOffset = CGPointMake(0,[Misc refreshCellHeight]);
	}
	[UIView commitAnimations];*/
}

- (void)keyboardWasShown:(NSNotification*)note {[self keyboardAdjust:note:1];}

- (void)keyboardWasHidden:(NSNotification*)note {[self keyboardAdjust:note:0];}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[textField resignFirstResponder];
	return YES;
}

#pragma mark -
#pragma mark UISearchBarDelegate

/*- (BOOL)searchString:(NSArray*)array inDict:(NSDictionary*)dict {
	BOOL found = YES;
	NSString *element;
	for (int i=0;i<[array count];i++) {
		element = [[[array objectAtIndex:i]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]lowercaseString];
		
		if ([element length]!=0) {
			NSRange r1 = [[[dict objectForKey:@"firstName"]lowercaseString]rangeOfString:element];
			
			NSRange r2 = [[[dict objectForKey:@"lastName"]lowercaseString]rangeOfString:element];
			
			NSRange r3 = [[[dict objectForKey:@"email"]lowercaseString]rangeOfString:element];
			
			found = found && (r1.length>0 || r2.length>0 || r3.length>0);
			
			if (!found) return NO;
		}
	}
	return found;
}*/

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	[lastIDs replaceObjectAtIndex:tab withObject:@""];
	[counts replaceObjectAtIndex:tab withObject:@"1"];
	[self refreshAll];
	[searchBar resignFirstResponder];
	
	/*[searchArray release];
	
	if ([searchBar.text length]==0) {
		if (tab==2) searchArray = [[NSMutableArray alloc]init];
		else searchArray = [[NSMutableArray alloc]initWithArray:tabArray];
	} else {
		searchArray = [[NSMutableArray alloc]init];
		
		NSArray *explode = [searchBar.text componentsSeparatedByString:@" "];
		for (int i=0;i<[tabArray count];i++) {
			NSDictionary *dict = [tabArray objectAtIndex:i];
			if ([self searchString:explode inDict:dict]) {
				[searchArray addObject:dict];
			}
		}
	}
	
	[table reloadData];
	double rch = table.tableHeaderView.frame.size.height;
	if (table.contentOffset.y<rch) [table setContentOffset:CGPointMake(0,table.tableHeaderView.frame.size.height) animated:[Misc tableHideHeaderAnimated]];
	
	[searchBar resignFirstResponder];*/
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {[searchBar resignFirstResponder];}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:YES animated:YES];
	[table setContentOffset:CGPointMake(0,[Misc refreshCellHeight]) animated:[Misc tableHideHeaderAnimated]];
	[table setAllowsSelection:NO];
	[table setScrollEnabled:NO];
	return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:NO animated:YES];
	[table setAllowsSelection:YES];
	[table setScrollEnabled:YES];
	return YES;
}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	for (UIView *v in [search subviews]) {
		if ([v conformsToProtocol:@protocol(UITextInputTraits)]) {
			@try {
				[(UITextField*)v setEnablesReturnKeyAutomatically:NO];
				[(UITextField*)v setKeyboardAppearance:UIKeyboardAppearanceAlert];
			}
			@catch (NSException *e) {
				NSLog(@"failed to change searchTextField's color and button");
			}
		}
	}
	
	[Misc load:self];
	
	NSString *s = [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"];
	if (!uid||[uid intValue]==0) uid = s;
	if ([uid intValue]==[s intValue]) {
		self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Find Friends"];
		UIButton *b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
		[b addTarget:self action:@selector(findFriends) forControlEvents:UIControlEventTouchUpInside];
	} 	
	
	UIView *v = [[UIView alloc]init];
	double w = search.frame.size.width;
	double h = search.frame.size.height;
	double r = [Misc refreshCellHeight];
	v.frame = CGRectMake(0,0,w,r+h);
	refreshCell = [Misc refreshCellView];
	refreshCell.table = table;
	refreshCell.frame = CGRectMake(0, 0, self.view.frame.size.width, r);
	search.frame = CGRectMake(0,r,w,h);
	[v addSubview:search];
	[v addSubview:refreshCell];
	[table setTableHeaderView:v];
	[v release];
	
	v = [[UIView alloc]init];
	v.contentMode = UIViewContentModeCenter;
	moreCell = [Misc activityView];
	double aiw = moreCell.frame.size.width;
	h = moreCell.frame.size.height;
	v.frame = CGRectMake((w-aiw)/2, 0, aiw, h);
	[v addSubview:moreCell];
	[table setTableFooterView:v];
	[v release];
	
	table.contentInset = UIEdgeInsetsMake(-r,0,0,0);
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aSyncImageLoaded) name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	
	lastIDs = [[NSMutableArray alloc]init];
	[lastIDs addObject:@""];[lastIDs addObject:@""];
	counts = [[NSMutableArray alloc]init];
	[counts addObject:@"1"];[counts addObject:@"1"];
	
	search.text = @"";
	
	if (tab==0) {
		tab = 1;
		[self following:followingButton];
	} else {
		tab = 0;
		[self followers:followersButton];
	}
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[lastIDs release];
	lastIDs = nil;
	[counts release];
	counts = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[uid release];
	table.delegate = nil;
	table.dataSource = nil;
	search.delegate = nil;
	
    [super dealloc];
}

@end
