//
//  SendMessage.m
//  Kuipp
//
//  Created by Brandon Jue on 12/21/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "SendMessage.h"
#import "KuippConnect.h"

@implementation SendMessage

@synthesize dict;

- (IBAction)popBack:(id)sender {
	[self.navigationController popToViewController:[[self.navigationController viewControllers]objectAtIndex:1] animated:YES];
}

- (void)refresh {
	[to setText:[dict objectForKey:@"username"]];
	[body setText:@""];
	[self refreshCount];
}

- (void)refreshCount {
	[count setText:[NSString stringWithFormat:
					@"%d",
					150-[body.text length]]];
}

- (IBAction)send:(id)sender {
	if ([body.text length]==0) {
		NSLog(@"There isn't a message to send.");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Error"
				 message:@"There isn't a message to send."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else {
		[manager startUpdatingLocation];
	}
}

- (void)send {
	if (userLoc==nil) return;
	[manager stopUpdatingLocation];
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&toUser=%@"
							@"&fromUser=0"
							@"&message=%@"
							@"&latitude=%f"
							@"&longitude=%f",
							to.text,
							body.text,
							userLoc.coordinate.latitude,
							userLoc.coordinate.longitude];
	
	NSString *urlContents = [KuippConnect formTo:@"insertMessage" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:2]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode/10 forView:self]) return;
	if (![KuippConnect sendMessageCode:exitCode%10 forView:self]) return;
	
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)backgroundTouched:(id)sender {
	[to resignFirstResponder];
	[body resignFirstResponder];
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	if (viewMoved&&delta==1) return;
	
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	int shiftView = 246-205;
	
	CGRect frame = self.view.frame;
	frame.origin.y -= delta*shiftView;
	frame.size.height += delta*shiftView;
	
	int shrinkMessage = 110;
	
	CGRect textFrame = body.frame;
	textFrame.size.height -= delta*shrinkMessage;
	
	CGRect countFrame = count.frame;
	countFrame.origin.y -= delta*shrinkMessage;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	self.view.frame = frame;
	body.frame = textFrame;
	count.frame = countFrame;
	[UIView commitAnimations];	
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	viewMoved = YES;
}

- (void)keyboardWasHidden:(NSNotification*)note {
    if (!viewMoved) return;
	[self keyboardAdjust:note:-1];
	viewMoved = NO;
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[textField resignFirstResponder];
	return YES;
}

#pragma mark -
#pragma mark UITextViewDelegate

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
	if ([count.text intValue]==0&&range.length<[text length]) {
		NSLog(@"Your message is too long.");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Error"
				 message:@"Your message is too long."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
		return NO;
	}
	return YES;
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
	if (textView.inputAccessoryView==nil) {
		[[NSBundle mainBundle]loadNibNamed:@"MessageKBBar" owner:self options:nil];
		textView.inputAccessoryView = keyboardBar;
		keyboardBar = nil;
	}
	return YES;
}

- (void)textViewDidChange:(UITextView *)textView {
	[self refreshCount];
}

#pragma mark -
#pragma mark KeyboardBarDelegate

- (IBAction)done:(id)sender {
	[body resignFirstResponder];
}

- (IBAction)clear:(id)sender {
	[body setText:@""];
	[self refreshCount];
}

#pragma mark -
#pragma mark CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager*)manager didUpdateToLocation:(CLLocation*)newLocation fromLocation:(CLLocation*)oldLocation {
	userLoc = newLocation;
	
	[self send];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
	NSLog(@"%@",error);
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Session Error"]) {
		[self.navigationController popToRootViewControllerAnimated:YES];
	}
}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	manager = [[CLLocationManager alloc]init];
	[manager setDelegate:self];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	
	[self refresh];
}

- (void)viewWillDisappear:(BOOL)animated {
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	[super viewWillDisappear:animated];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[dict release];
	
    [super dealloc];
}

@end
