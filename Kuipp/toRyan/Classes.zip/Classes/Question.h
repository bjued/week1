//
//  Question.h
//  Kuipp
//
//  Created by Brandon Jue on 12/20/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "Facebook.h"

@interface Question : UIViewController <MKMapViewDelegate,UITextViewDelegate,UITableViewDelegate,FBSessionDelegate> {
	NSString *qid;
	int tab;
	
	IBOutlet UIView* bar;
	
	Facebook *facebook;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableDictionary *images;
	
	RefreshCell *refreshCell;
	
	NSDictionary *question;
	NSMutableArray *answers;
	
	IBOutlet UIButton *tButton;
	IBOutlet UIButton *fButton;
	
	IBOutlet UIButton *publishFB;
	IBOutlet UIButton *publishTW;
	
	IBOutlet UITableView *table;
	IBOutlet MKMapView *map;
	
	UIBarButtonItem *listMap;
	
	//Reply
	IBOutlet UIView *top;
	IBOutlet UIView *bot;
	IBOutlet UITextView *textbox;
	IBOutlet UILabel *count;
}

@property(nonatomic,retain) NSString *qid;
- (void)back;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)splitData;
- (void)reloadView;
- (void)reloadMap;
- (void)reloadTable;
- (void)refreshCount;
- (void)addAnswer;
- (void)cancelAnswer;
- (void)trySend:(UIButton*)sender;
- (void)send;
- (void)listMap:(UIButton*)sender;
- (IBAction)loginFB:(UIButton*)sender;
- (void)toggleButton:(UIButton*)sender;
- (void)toProfile:(UIControl*)sender;
- (IBAction)track:(UIButton*)sender;
- (IBAction)flag:(UIButton*)sender;
- (void)keyboardAdjust:(NSNotification *)note:(int)delta;
- (void)keyboardWasShown:(NSNotification *)note;
- (void)keyboardWasHidden:(NSNotification *)note;

@end
