//
//  LoadingView.h
//  Kuipp
//
//  Created by Brandon Jue on 3/26/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LoadingView : UIViewController {
	IBOutlet UIActivityIndicatorView *activity;
}

- (void)threadedCheckSession;
- (void)checkSession;

@end
