//
//  QACell.m
//  Kuipp
//
//  Created by Brandon Jue on 1/30/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "QACell.h"

@implementation QACell

@synthesize pic,qOwner,qQuestion,qClass,aButton,aOwner,aAnswer,aTime;

#pragma mark -
#pragma mark Initialization

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */
/*
 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad {
 [super viewDidLoad];
 }
 */
/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)dealloc {
	[pic release];
	[qOwner release];
	[qQuestion release];
	[qClass release];
	[aButton release];
	[aOwner release];
	[aAnswer release];
	[aTime release];
	
    [super dealloc];
}

@end
