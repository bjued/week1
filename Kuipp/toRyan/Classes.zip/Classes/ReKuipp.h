//
//  ReKuipp.h
//  Kuipp
//
//  Created by Brandon Jue on 1/4/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ReKuipp : UIViewController <CLLocationManagerDelegate,UISearchBarDelegate,UITableViewDelegate,UIAlertViewDelegate> {
	
	NSMutableArray *dicts;
	NSMutableArray *heads;
	
	NSMutableArray *questions;
	
	IBOutlet UIButton *followingButton;
	IBOutlet UIButton *localButton;
	IBOutlet UIButton *recommendButton;
	IBOutlet UIButton *recentButton;
	
	BOOL followingTapped;
	BOOL localTapped;
	BOOL recommendTapped;
	BOOL recentTapped;
	
	IBOutlet UISearchBar *search;
	IBOutlet UITableView *table;
	
	int tab;
	
	CLLocationManager *manager;
	CLLocation *userLoc;
	
	//SearchBar
	NSMutableArray *tabResults;
	NSMutableArray *searchResults;
}

- (IBAction)popBack:(UIButton*)sender;
- (IBAction)refresh:(UIButton*)sender;
- (void)refresh;
- (void)splitData;
- (void)filter;
- (void)reduce:(int)n;
- (IBAction)following:(UIButton*)sender;
- (IBAction)local:(UIButton*)sender;
- (IBAction)recommend:(UIButton*)sender;
- (IBAction)recent:(UIButton*)sender;
- (IBAction)backgroundTouched:(UIControl*)sender;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;
- (BOOL)searchString:(NSArray *)array inDict:(NSDictionary *)dict;

@end
