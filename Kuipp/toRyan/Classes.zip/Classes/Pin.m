//
//  Pin.m
//  Kuipp
//
//  Created by Brandon Jue on 12/31/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "Pin.h"

@implementation Pin

@synthesize coordinate,title,subtitle,dict;

- (void)dealloc {
	[title release];
	[subtitle release];
	[dict release];
	
	[super dealloc];
}

@end
