//
//  Directory.h
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Directory : UIViewController {
}

- (IBAction)myKuippsPressed:(id)sender;
- (IBAction)kuippItPressed:(id)sender;
- (IBAction)reKuippPressed:(id)sender;

- (IBAction)inboxPressed:(id)sender;
- (IBAction)mapPressed:(id)sender;
- (IBAction)connectionsPressed:(id)sender;

- (IBAction)profilePressed:(id)sender;
- (IBAction)leaderboardPressed:(id)sender;
- (IBAction)settingsPressed:(id)sender;

- (IBAction)fadeWhenPressed:(UIControl*)sender;
- (IBAction)fadeWhenDepressed:(UIControl*)sender;

@end
