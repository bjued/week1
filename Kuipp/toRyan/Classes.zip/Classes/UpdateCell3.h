//
//  UpdateCell3.h
//  Kuipp
//
//  Created by Brandon Jue on 1/29/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UpdateCell3 : UITableViewCell {
	NSString *nameID1;
	NSString *nameID2;
	IBOutlet UIImageView *picLeft;
	IBOutlet UIButton *name1;
	IBOutlet UILabel *primary1;
	IBOutlet UIButton *name2;
	IBOutlet UIWebView *primary2;
	IBOutlet UIImageView *picRight;
	IBOutlet UILabel *secondary;
}

@property(nonatomic,retain) NSString *nameID1;
@property(nonatomic,retain) NSString *nameID2;
@property(nonatomic,retain) UIImageView *picLeft;
@property(nonatomic,retain) UIButton *name1;
@property(nonatomic,retain) UILabel *primary1;
@property(nonatomic,retain) UIButton *name2;
@property(nonatomic,retain) UIWebView *primary2;
@property(nonatomic,retain) UIImageView *picRight;
@property(nonatomic,retain) UILabel *secondary;
- (IBAction)name1Touched:(UIButton*)sender;
- (IBAction)name2Touched:(UIButton*)sender;

@end
