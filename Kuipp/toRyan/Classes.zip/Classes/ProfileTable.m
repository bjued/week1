//
//  ProfileTable.m
//  Kuipp
//
//  Created by Brandon Jue on 2/3/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "ProfileTable.h"
#import "QuestionCell.h"
#import "QACell.h"
#import "UserCell.h"
#import "SingleTextCell.h"
#import "Question.h"
#import "Answer.h"
#import "Profile.h"
#import "KuippConnect.h"
#import "Parser.h"

@implementation ProfileTable

@synthesize uid,tab;

- (IBAction)popBack:(UIButton*)sender {
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)refresh:(UIButton*)sender {
	NSURLResponse *response;
	NSError *error;
	
	NSString *urlContents;
	switch (tab) {
		case  0: urlContents = [KuippConnect formTo:@"selectUserQuestions" WithPost:[NSString stringWithFormat:@"&uid=%@",uid] AndResponse:&response AndError:&error];break;
		case  1: urlContents = [KuippConnect formTo:@"selectUserAnswers" WithPost:[NSString stringWithFormat:@"&uid=%@",uid] AndResponse:&response AndError:&error];break;
		case  2: urlContents = [KuippConnect formTo:@"selectUserSchool" WithPost:[NSString stringWithFormat:@"&uid=%@",uid] AndResponse:&response AndError:&error];break;
		default: urlContents = @"";break;
	}
	 
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:1]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode forView:self]) return;
	
	if (dicts!=nil) [dicts release];
	if (heads!=nil) [heads release];
	dicts = [[NSMutableArray alloc]init];
	heads = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts AndHeads:heads];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self searchBarSearchButtonClicked:search];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [searchResults count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
	
	if (tab==0) {
		QuestionCell *cell = (QuestionCell*)[tableView dequeueReusableCellWithIdentifier:@"QuestionCell"];
		if (cell==nil) {
			NSArray *topArray = [[NSBundle mainBundle]loadNibNamed:@"QuestionCell" owner:nil options:nil];
			for (id cur in topArray) {
				if ([cur isMemberOfClass:[QuestionCell class]]) {
					cell = cur;
					break;
				}
			}
		}
		
		// Find timeSince (choose to use year, day, hour, minute, second)
		NSString *date = [dict objectForKey:@"datetime"];
		NSTimeInterval time = [[NSDate dateWithTimeIntervalSince1970:[date intValue]]timeIntervalSinceNow] * -1;
		NSString *since = @"";
		if (((int)time)/60/60/24/365>0) {
			since = [NSString stringWithFormat:@"%d year%@ ago",((int)time)/60/60/24/365,((int)time)/60/60/24/365==1?@"":@"s"];
		} else if (((int)time)/60/60/24>0) {
			since = [NSString stringWithFormat:@"%d day%@ ago",((int)time)/60/60/24,((int)time)/60/60/24==1?@"":@"s"];
		} else if (((int)time)/60/60>0) {
			since = [NSString stringWithFormat:@"%d hour%@ ago",((int)time)/60/60,((int)time)/60/60==1?@"":@"s"];
		} else if (((int)time)/60>0) {
			since = [NSString stringWithFormat:@"%d minute%@ ago",((int)time)/60,((int)time)/60==1?@"":@"s"];
		} else {
			since = [NSString stringWithFormat:@"%d second%@ ago",((int)time),((int)time)==1?@"":@"s"];
		}
		
		[cell.pic setImage:[UIImage imageNamed:@"RedPin.png"]];
		
		cell.qOwner.text = [NSString stringWithFormat:@"%@ %@.",[dict objectForKey:@"firstName"],[[dict objectForKey:@"lastName"]substringToIndex:1]];
		
		cell.qQuestion.text = [dict objectForKey:@"question"];
		cell.qQuestion.frame = CGRectMake(cell.qQuestion.frame.origin.x,cell.qQuestion.frame.origin.y,232,15*150);
		[cell.qQuestion sizeToFit];
		
		cell.qClass.text = [dict objectForKey:@"class"];
		
		cell.qTime.text = [NSString stringWithFormat:@"%@ | %@ answers",since,[dict objectForKey:@"numAnswers"]];
		cell.qTime.frame = CGRectMake(cell.qTime.frame.origin.x,fmax(55,cell.qQuestion.frame.origin.y+cell.qQuestion.frame.size.height),cell.qTime.frame.size.width,cell.qTime.frame.size.height);
		
		cell.frame = CGRectMake(cell.frame.origin.x,cell.frame.origin.y,cell.frame.size.width,cell.qTime.frame.origin.y+cell.qTime.frame.size.height+1);
		
		return cell;
	} else if (tab==1) {
		QACell *cell = (QACell*)[tableView dequeueReusableCellWithIdentifier:@"QACell"];
		if (cell==nil) {
			NSArray *top = [[NSBundle mainBundle]loadNibNamed:@"QACell" owner:nil options:nil];
			for (id cur in top) {
				if ([cur isKindOfClass:[UITableViewCell class]]) {
					cell = (QACell*)cur;
					break;
				}
			}
		}
		
		// Find timeSince (choose to use year, day, hour, minute, second)
		NSString *date = [dict objectForKey:@"datetime"];
		NSTimeInterval time = [[NSDate dateWithTimeIntervalSince1970:[date intValue]]timeIntervalSinceNow] * -1;
		NSString *since = @"";
		if (((int)time)/60/60/24/365>0) {
			since = [NSString stringWithFormat:@"%d year%@ ago",((int)time)/60/60/24/365,((int)time)/60/60/24/365==1?@"":@"s"];
		} else if (((int)time)/60/60/24>0) {
			since = [NSString stringWithFormat:@"%d day%@ ago",((int)time)/60/60/24,((int)time)/60/60/24==1?@"":@"s"];
		} else if (((int)time)/60/60>0) {
			since = [NSString stringWithFormat:@"%d hour%@ ago",((int)time)/60/60,((int)time)/60/60==1?@"":@"s"];
		} else if (((int)time)/60>0) {
			since = [NSString stringWithFormat:@"%d minute%@ ago",((int)time)/60,((int)time)/60==1?@"":@"s"];
		} else {
			since = [NSString stringWithFormat:@"%d second%@ ago",((int)time),((int)time)==1?@"":@"s"];
		}
		
		[cell.pic setImage:[UIImage imageNamed:@"RedPin.png"]];
		
		cell.qOwner.text = [NSString stringWithFormat:@"%@ %@. asked:",[dict objectForKey:@"qfirstName"],[[dict objectForKey:@"qlastName"]substringToIndex:1]];
		
		cell.qQuestion.text = [dict objectForKey:@"qquestion"];
		cell.qQuestion.frame = CGRectMake(cell.qQuestion.frame.origin.x,cell.qQuestion.frame.origin.y,232,15*150);
		[cell.qQuestion sizeToFit];
		
		cell.qClass.text = [dict objectForKey:@"qclass"];
		
		cell.aOwner.text = [NSString stringWithFormat:@"%@ %@. answered:",[dict objectForKey:@"firstName"],[[dict objectForKey:@"lastName"]substringToIndex:1]];
		cell.aOwner.frame = CGRectMake(cell.aOwner.frame.origin.x,fmax(65,cell.qQuestion.frame.origin.y+cell.qQuestion.frame.size.height)+8,cell.aOwner.frame.size.width,cell.aOwner.frame.size.height);
		
		cell.aAnswer.text = [dict objectForKey:@"answer"];
		cell.aAnswer.frame = CGRectMake(cell.aAnswer.frame.origin.x,cell.aOwner.frame.origin.y+cell.aOwner.frame.size.height,276,15*150);
		[cell.aAnswer sizeToFit];
		
		cell.aTime.text = [NSString stringWithFormat:@"%@ | %@ like | %@ dislike | %@ comments",since,[dict objectForKey:@"numLike"],[dict objectForKey:@"numDislike"],[dict objectForKey:@"numComments"]];
		cell.aTime.frame = CGRectMake(cell.aTime.frame.origin.x,cell.aAnswer.frame.origin.y+cell.aAnswer.frame.size.height,cell.aTime.frame.size.width,cell.aTime.frame.size.height);
		
		cell.frame = CGRectMake(cell.frame.origin.x,cell.frame.origin.y,cell.frame.size.width,cell.aTime.frame.origin.y+cell.aTime.frame.size.height+5);
		cell.aButton.frame = CGRectMake(cell.aButton.frame.origin.x,cell.aOwner.frame.origin.y-4,cell.aButton.frame.size.width,cell.aOwner.frame.size.height+cell.aAnswer.frame.size.height+cell.aTime.frame.size.height+5);
		
		return cell;
	} else if (tab==2) {
		if ([dict objectForKey:@"e"]!=nil) {
			UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
			if (cell == nil) {
				cell = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"]autorelease];
			}
			
			cell.textLabel.text = [dict objectForKey:@"e"];
			cell.textLabel.textColor = [UIColor whiteColor];
			cell.textLabel.textAlignment = UITextAlignmentCenter;
			cell.textLabel.backgroundColor = [UIColor clearColor];
			UIView *bg = [[UIView alloc]init];
			bg.frame = CGRectMake(0,0,320,30);
			bg.backgroundColor = [UIColor darkGrayColor];
			cell.backgroundView = bg;
			
			return cell;
		}
		UserCell *cell = (UserCell*)[tableView dequeueReusableCellWithIdentifier:@"UserCell"];
		if (cell==nil) {
			NSArray *top = [[NSBundle mainBundle]loadNibNamed:@"UserCell" owner:nil options:nil];
			for (id cur in top) {
				if ([cur isMemberOfClass:[UserCell class]]) {
					cell = cur;
					break;
				}
			}
		}
		
		[cell.pic setImage:[UIImage imageNamed:@"RedPin.png"]];
		
		cell.name.text = [NSString stringWithFormat:@"%@ %@.",[dict objectForKey:@"firstName"],[[dict objectForKey:@"lastName"]substringToIndex:1]];
		[cell.name sizeToFit];
		
		cell.primary.text = [NSString stringWithFormat:@"Level %@ - %@",[dict objectForKey:@"level"],[dict objectForKey:@"class"]];
		return cell;
	}
	return nil;
}
/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */
/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */
/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */
/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
	
	if (tab==0) {
		UILabel *one = [[UILabel alloc]init];
		one.text = @"1";
		one.font = [one.font fontWithSize:12];
		[one sizeToFit];
		
		UILabel *two = [[UILabel alloc]init];
		two.text = [dict objectForKey:@"question"];
		two.font = [two.font fontWithSize:12];
		two.numberOfLines = 0;
		two.frame = CGRectMake(0,one.frame.size.height,232,15*150);
		[two sizeToFit];
		
		UILabel *three = [[UILabel alloc]init];
		three.text = @"1";
		three.font = [three.font fontWithSize:10];
		three.frame = CGRectMake(0,fmax(55,two.frame.origin.y+two.frame.size.height),13,13);
		[three sizeToFit];
		
		int ret = three.frame.origin.y+three.frame.size.height+1;
		
		[one release];
		[two release];
		[three release];
		
		return ret;
	} else if (tab==1) {
		UILabel *one = [[UILabel alloc]init];
		one.text = @"1";
		one.font = [one.font fontWithSize:12];
		[one sizeToFit];
		
		UILabel *two = [[UILabel alloc]init];
		two.text = [dict objectForKey:@"qquestion"];
		two.font = [two.font fontWithSize:12];
		two.numberOfLines = 0;
		two.frame = CGRectMake(0,one.frame.size.height,232,15*150);
		[two sizeToFit];
		
		UILabel *three = [[UILabel alloc]init];
		three.text = @"1";
		three.font = [three.font fontWithSize:12];
		three.frame = CGRectMake(0,fmax(65,two.frame.origin.y+two.frame.size.height)+8,15,15);
		[three sizeToFit];
		
		UILabel *four = [[UILabel alloc]init];
		four.text = [dict objectForKey:@"answer"];
		four.font = [four.font fontWithSize:12];
		four.numberOfLines = 0;
		four.frame = CGRectMake(0,three.frame.origin.y+three.frame.size.height,276,15*150);
		[four sizeToFit];
		
		UILabel *five = [[UILabel alloc]init];
		five.text = @"1";
		five.font = [five.font fontWithSize:10];
		five.frame = CGRectMake(0,four.frame.origin.y+four.frame.size.height,13,13);
		[five sizeToFit];
		
		int ret = five.frame.origin.y+five.frame.size.height+5;
		
		[one release];
		[two release];
		[three release];
		[four release];
		[five release];
		
		return ret;
	} else if (tab==2) {
		if ([dict objectForKey:@"e"]!=nil) return 30;
		return 56;
	}
	return 44;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
	if (tab==0) {
		Question *v = [[Question alloc]init];
		v.qid = [[searchResults objectAtIndex:indexPath.row]objectForKey:@"questionID"];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	} else if (tab==1) {
		Answer *v = [[Answer alloc]init];
		v.aid = [[searchResults objectAtIndex:indexPath.row] objectForKey:@"answerID"];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	} else {
		if ([dict objectForKey:@"e"]!=nil) return;
		Profile *v = [[Profile alloc]init];
		v.uid = [dict objectForKey:@"userID"];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	}
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	int shiftView = 36;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	if (delta==0) {
		table.frame = CGRectMake(0,shiftView,320,460-shiftView);
		self.view.frame = CGRectMake(0,0,320,460);
	} else {
		self.view.frame = CGRectMake(0,0-shiftView,320,460);
		table.frame = CGRectMake(0,shiftView,320,460-kb.size.height);
	}
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
}

- (void)keyboardWasHidden:(NSNotification*)note {
	[self keyboardAdjust:note:0];
}

#pragma mark -
#pragma mark UISearchBarDelegate

- (BOOL)searchString:(NSArray*)array inDict:(NSDictionary*)dict {
	BOOL found = YES;
	NSString *element;
	for (int i=0;i<[array count];i++) {
		element = [[[array objectAtIndex:i]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]lowercaseString];
		
		if ([element length]!=0) {
			NSRange r1 = [[[dict objectForKey:@"firstName"]lowercaseString]rangeOfString:element];
			
			NSRange r2 = [[[dict objectForKey:@"lastName"]lowercaseString]rangeOfString:element];
			
			NSRange r3 = [[[dict objectForKey:@"email"]lowercaseString]rangeOfString:element];
			
			NSRange r4 = [[[dict objectForKey:@"question"]lowercaseString]rangeOfString:element];
			
			NSRange r5 = [[[dict objectForKey:@"qquestion"]lowercaseString]rangeOfString:element];
			
			NSRange r6 = [[[dict objectForKey:@"answer"]lowercaseString]rangeOfString:element];
			
			found = found && (r1.length>0 || r2.length>0 || r3.length>0	|| r4.length>0 || r5.length>0 || r6.length>0 || [dict objectForKey:@"e"]!=nil);
			
			if (!found) return NO;
		}
	}
	return found;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	if (searchResults!=nil) [searchResults release];
	
	if ([searchBar.text length]==0) {
		searchResults = [[NSMutableArray alloc]initWithArray:dicts];
	} else {
		searchResults = [[NSMutableArray alloc]init];
		
		NSArray *explode = [searchBar.text componentsSeparatedByString:@" "];
		for (int i=0;i<[dicts count];i++) {
			NSDictionary *dict = [dicts objectAtIndex:i];
			if ([self searchString:explode inDict:dict]) {
				[searchResults addObject:dict];
			}
		}
	}
	
	[table reloadData];
	
	[searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
	[searchBar resignFirstResponder];
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:YES animated:YES];
	[table setAllowsSelection:NO];
	[table setScrollEnabled:NO];
	return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:NO animated:YES];
	[table setAllowsSelection:YES];
	[table setScrollEnabled:YES];
	return YES;
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Session Error"]) {
		[self.navigationController popToRootViewControllerAnimated:YES];
	}
}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	for (UIView *v in [search subviews]) {
		if ([v conformsToProtocol:@protocol(UITextInputTraits)]) {
			@try {
				[(UITextField*)v setEnablesReturnKeyAutomatically:NO];
				[(UITextField*)v setKeyboardAppearance:UIKeyboardAppearanceAlert];
			}
			@catch (NSException *e) {
				NSLog(@"failed to change searchTextField's color and button");
			}
		}
	}
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	if (tab!=2) [table setTableHeaderView:search];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	
	[self refresh:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	[super viewWillDisappear:animated];
}

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[uid release];
	
    [super dealloc];
}

@end
