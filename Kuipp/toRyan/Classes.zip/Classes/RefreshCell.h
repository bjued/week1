//
//  RefreshCell.h
//  Kuipp
//
//  Created by Brandon Jue on 5/2/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RefreshCell : UIView {
	BOOL flipped;
	UITableView *table;
	UIImageView *arrow;
	UIActivityIndicatorView *wheel;
	UILabel *directions;
	UILabel *lastUpdate;
}

@property(nonatomic,assign) BOOL flipped;
@property(nonatomic,retain) UITableView *table;
- (void)flip;
- (void)refreshing;
- (void)refreshed;

@end
