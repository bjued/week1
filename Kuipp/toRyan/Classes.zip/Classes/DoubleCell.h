//
//  DoubleCell.h
//  Kuipp
//
//  Created by Brandon Jue on 3/14/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DoubleCell : UITableViewCell {
	BOOL selectable;
	
	NSDictionary *dict;
	
	UIView *pict;
	UIView *cell;
	UIView *back;
	
	UIControl *ctrl;
	UIImageView *imag;
	UIControl *ctr2;
	UIImageView *ima2;
	UIButton *name;
	UILabel *main;
	UILabel *foot;
}

@property(nonatomic,assign) BOOL selectable;
@property(nonatomic,retain) NSDictionary *dict;
@property(nonatomic,retain) UIControl *ctrl,*ctr2;
@property(nonatomic,retain) UIImageView *imag,*ima2;
@property(nonatomic,retain) UIButton *name;
@property(nonatomic,retain) UILabel *main,*foot;

@end
