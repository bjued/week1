<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>PN Test</title>
</head>

<body>
<center>Push Notifications Test</center>
<form action="pnTest.php" method="post">
Device Token: <input type="text" name="deviceToken"><br><br>
Expire: <input type="text" name="expire"><br><br>
Alert: <input type="text" name="alert"><br><br>
Badge: <input type="text" name="badge"><br><br>
Sound: <input type="text" name="sound"><br><br>
<input type="Submit">
</form>
</body>
</html>