//
//  Friends.m
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "Friends.h"
#import "Profile.h"
#import "KuippConnect.h"
#import "Parser.h"

@implementation Friends

@synthesize uid;

- (IBAction)popBack:(id)sender {
	[self.navigationController popToViewController:[[self.navigationController viewControllers]objectAtIndex:1] animated:YES];
}

- (IBAction)refresh:(id)sender {
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:@"&userID=%@",uid];
	
	NSString *urlContents = [KuippConnect formTo:@"selectFollowers" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:1]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode forView:self]) return;
	
	if (dicts!=nil) [dicts release];
	if (heads!=nil) [heads release];
	dicts = [[NSMutableArray alloc]init];
	heads = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts AndHeads:heads];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	
	[self searchBar:search textDidChange:search.text];
	
	[table reloadData];
}

- (void)splitData {
	if (following!=nil) [following release];
	if (followers!=nil) [followers release];
	
	following = [[NSMutableArray alloc]init];
	followers = [[NSMutableArray alloc]init];
	
	for (int i=0;i<[heads count];i++) {
		if ([[heads objectAtIndex:i] isEqualToString:@"Following"]) {
			[following addObject:[dicts objectAtIndex:i]];
		} else if ([[heads objectAtIndex:i] isEqualToString:@"Followers"]) {
			[followers addObject:[dicts objectAtIndex:i]];
		}
	}
}

- (IBAction)add:(id)sender {
	if ([friends.text length]==0) {
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Error"
							  message:@"You didn't list any friends."
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
	
	NSURLResponse *response;
	NSError *error;
		
	NSString *poststring = [NSString stringWithFormat:
							@"&userID=0"
							@"&friends=%@",
							friends.text];
	
	NSString *urlContents = [KuippConnect formTo:@"insertFollowerNames" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:1]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode forView:self]) return;
	NSRange rng = [urlContents rangeOfString:@"[already"];
		
	if (rng.length==0) {
		if ([urlContents length]%2==0) {
			[KuippConnect checkSessionCode:[urlContents intValue] forView:self];
		} else{
			[KuippConnect friendsCode:[urlContents intValue] forView:self];
		}
	} else {
		NSString *subs = [urlContents substringFromIndex:rng.location+rng.length];
		rng = [subs rangeOfString:@"][invalid"];
			
		NSString *message= @"";
			
		NSString *already = [subs substringToIndex:rng.location];
		if ([already length]>2) {
			already = [already substringFromIndex:2];
			message = [message stringByAppendingFormat:@"Already following: %@\n",already];
		}
			
		subs = [subs substringFromIndex:rng.location+rng.length];
		rng = [subs rangeOfString:@"]"];
			
		NSString *invalid = [subs substringToIndex:rng.location];
		if ([invalid length]>2) {
			invalid = [invalid substringFromIndex:2];
			message = [message stringByAppendingFormat:@"Missing users: %@",invalid];
		}
			
		if ([message length]>0) {
			UIAlertView *alert = [[UIAlertView alloc]
								  initWithTitle:@"Error"
								  message:message
								  delegate:self
								  cancelButtonTitle:@"OK"
								  otherButtonTitles:nil];
			[alert show];
			[alert release];
		} else {
			UIAlertView *alert = [[UIAlertView alloc]
								  initWithTitle:@"Success"
								  message:@"Now following all friends."
								  delegate:self
								  cancelButtonTitle:@"OK"
								  otherButtonTitles:nil];
			[alert show];
			[alert release];
		}
		
		if (dicts!=nil) [dicts release];
		if (heads!=nil) [heads release];			
		dicts = [[NSMutableArray alloc]init];
		heads = [[NSMutableArray alloc]init];
		
		Parser *parse = [[Parser alloc]initWithDicts:dicts AndHeads:heads];
		[parse parseXML:[urlContents substringFromIndex:1]];
		[parse release];
		
		[self splitData];
		[friends setText:@""];
		
		[self searchBar:search textDidChange:search.text];
		
		[table reloadData];
	}
}

- (IBAction)backgroundTouched:(id)sender {
	[friends resignFirstResponder];
	[search resignFirstResponder];
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	if (viewMoved&&delta==1) return;
	
	NSDictionary *info = [note userInfo];
	//CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey]CGRectValue].size;
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	int shiftView = 0;
	if (activeField==friends) {
		shiftView = 216-44;
	} else {
		shiftView = 44;
	}
	
	CGRect frame = self.view.frame;
	frame.origin.y -= delta*shiftView;
	frame.size.height += delta*shiftView;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	self.view.frame = frame;
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	viewMoved = YES;
}

- (void)keyboardWasHidden:(NSNotification*)note {
    if (!viewMoved) return;
	[self keyboardAdjust:note:-1];
	viewMoved = NO;
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[textField resignFirstResponder];
	return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
	activeField = textField;
	return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
	activeField = nil;
}

#pragma mark -
#pragma mark Table view data source

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	if (section==1||[searchFollowing count]==0) {
		return @"Followers";
	} else {
		return @"Following Users";
	}
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return ([searchFollowing count]>0?1:0)+([searchFollowers count]>0?1:0);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return ([searchFollowing count]==0||section==1)?[searchFollowers count]:[searchFollowing count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"]autorelease];
    }
    
    // Configure the cell...
	NSDictionary *dict;
	if (indexPath.section==1||[searchFollowing count]==0) {
		dict = [searchFollowers objectAtIndex:indexPath.row];
	} else {
		dict = [searchFollowing objectAtIndex:indexPath.row];
	}
	[cell.textLabel setText:[dict objectForKey:@"username"]];
	[cell.detailTextLabel setText:[NSString stringWithFormat:
								   @"Level: %@ %@",
								   [dict objectForKey:@"level"],
								   [dict objectForKey:@"class"]]];

    return cell;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */
/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */
/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */
/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	Profile *profileView = [[Profile alloc]init];
	
	NSDictionary *dict;
	if (indexPath.section==1||[searchFollowing count]==0) {
		dict = [searchFollowers objectAtIndex:indexPath.row];
	} else {
		dict = [searchFollowing objectAtIndex:indexPath.row];
	}
	
	profileView.uid = [dict objectForKey:@"userID"];
	[self.navigationController pushViewController:profileView animated:YES];
	[profileView release];
}

#pragma mark -
#pragma mark UISearchBarDelegate

- (BOOL)searchString:(NSArray*)array inDict:(NSDictionary*)dict {
	BOOL found = YES;
	NSString *element;
	for (int i=0;i<[array count];i++) {
		element = [[[array objectAtIndex:i]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]lowercaseString];
		
		if ([element length]!=0) {
			NSRange username = [[[dict objectForKey:@"username"]lowercaseString]rangeOfString:element];
			
			NSRange firstName = [[[dict objectForKey:@"firstName"]lowercaseString]rangeOfString:element];
			
			NSRange lastName = [[[dict objectForKey:@"lastName"]lowercaseString]rangeOfString:element];
			
			NSRange email = [[[dict objectForKey:@"email"]lowercaseString]rangeOfString:element];
			
			NSRange level = [[[dict objectForKey:@"level"]lowercaseString]rangeOfString:element];
			
			NSRange class = [[[dict objectForKey:@"class"]lowercaseString]rangeOfString:element];
			
			found = found && (username.length>0	|| firstName.length>0	||
							  lastName.length>0	|| email.length>0		||
							  level.length>0	|| class.length>0		);
			
			if (!found) {
				return NO;
			}
		}
	}
	return found;
}

- (void)searchBar:(UISearchBar*)searchBar textDidChange:(NSString*)searchText {
	if (searchFollowing!=nil) [searchFollowing release];
	if (searchFollowers!=nil) [searchFollowers release];
	
	if ([searchText length]==0) {
		searchFollowing = [[NSMutableArray alloc]initWithArray:following];
		searchFollowers = [[NSMutableArray alloc]initWithArray:followers];
	} else {
		searchFollowing = [[NSMutableArray alloc]init];
		searchFollowers = [[NSMutableArray alloc]init];
		
		NSArray *explode = [searchText componentsSeparatedByString:@" "];
		for (int i=0;i<[following count];i++) {
			NSDictionary *dict = [following objectAtIndex:i];
			if ([self searchString:explode inDict:dict]) {
				[searchFollowing addObject:dict];
			}
		}
		for (int i=0;i<[followers count];i++) {
			NSDictionary *dict = [followers objectAtIndex:i];
			if ([self searchString:explode inDict:dict]) {
				[searchFollowers addObject:dict];
			}
		}
	}
	
	[table reloadData];
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	table.userInteractionEnabled = NO;
	
	return YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	[searchBar resignFirstResponder];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar {
	table.userInteractionEnabled = YES;
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Session Error"]) {
		[self.navigationController popToRootViewControllerAnimated:YES];
	}
}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/
/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];	
}
*/
- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	
	[self refresh:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	[super viewWillDisappear:animated];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[uid release];
	
    [super dealloc];
}

@end
