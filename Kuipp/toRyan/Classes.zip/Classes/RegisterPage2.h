//
//  RegisterPage2.h
//  Kuipp
//
//  Created by Brandon Jue on 4/23/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterPage2 : UIViewController <UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate> {
	IBOutlet UITableView *table;
	
	NSMutableDictionary *images;
	
	NSString *fName;
	NSString *lName;
	NSString *email;
	NSString *facebookID;
	IBOutlet UITextField *password;
	IBOutlet UITextField *confirm;
}

@property(nonatomic,retain) NSString *fName,*lName,*email,*facebookID;
- (void)back;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)createUser;
- (void)backgroundTouched:(id)sender;
- (void)keyboardAdjust:(NSNotification*)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
