//
//  UrQA.m
//  Kuipp
//
//  Created by Brandon Jue on 3/17/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "UrQA.h"
#import "TextCell.h"
#import "Question.h"
#import "Profile.h"
#import "Pin.h"

@implementation UrQA

@synthesize uid;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)refreshMore {
	[lastIDs release];
	lastIDs = [[NSString alloc]initWithString:@"0"];
	if (counts) {
		NSString *cnt = [NSString stringWithString:counts];
		[counts release];
		counts = [[NSString alloc]initWithFormat:@"%d",[cnt intValue]+1];
	} else {
		counts = [[NSString alloc]initWithString:@"1"];
	}
	
	[self refreshAll];
	
	[moreCell startAnimating];
}

- (void)refreshAll {
	[refreshCell refreshing];
	
	[kuipp cancel];
	if (!counts) {
		[counts release];
		counts = [[NSString alloc]initWithString:@"1"];
	}
	NSString *p = [NSString stringWithFormat:
				   @"&lid=%@&cnt=%@&sch=%@&uid=%@",
				   lastIDs?[lastIDs urlEncode]:@"0",
				   [counts urlEncode],
				   [search.text urlEncode],
				   [uid urlEncode]];
	
	if (qButton.tag==1) [kuipp formTo:@"selectUserQuestions" WithPost:p];
	if (aButton.tag==1) [kuipp formTo:@"selectUserAnswers" WithPost:p];
}

- (void)refresh:(id)obj {
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	
	[refreshCell refreshed];
	
	[self filtered:qButton.tag==1?qButton:aButton];
}

- (void)splitData {
	[questions release];
	[answers release];
	questions = [[NSMutableArray alloc]init];
	answers = [[NSMutableArray alloc]init];
	
	for (NSDictionary *d in dicts) {
		NSString *s = [d objectForKey:@"head"];
		if ([s isEqualToString:@"Questions"]) [questions addObject:d];
		else if ([s isEqualToString:@"Answers"]) [answers addObject:d];
	}
}

- (IBAction)filter:(UIButton*)sender {
	search.text = @"";
	
	[qButton setBackgroundImage:[Misc wideTabImage:sender==qButton]forState:UIControlStateNormal];
	qButton.tag = sender==qButton?1:0;
	[aButton setBackgroundImage:[Misc wideTabImage:sender==aButton]forState:UIControlStateNormal];
	aButton.tag = sender==aButton?1:0;
	
	[self refreshAll];
	
	[self filtered:sender];
}

- (void)filtered:(UIButton*)sender {
	[tabResults release];
	tabResults = [[NSMutableArray alloc]initWithArray:qButton.tag==1?questions:answers];
	
	search.placeholder = qButton.tag==1?@"Search Their Questions":@"Search Their Answers";
	[search resignFirstResponder];
	
	[self reloadView];
}

- (void)reloadView {
	if (tab==0) {
		[self reloadMap];
		[self.view sendSubviewToBack:table];
		[map setHidden:NO];
		[table setHidden:YES];
	} else {
		[self reloadTable];
		[self.view sendSubviewToBack:map];
		[map setHidden:YES];
		[table setHidden:NO];
	}
	self.navigationItem.rightBarButtonItem = [Misc mapList:tab];
	UIButton *b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(listMap:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)reloadMap {
	[map removeAnnotations:[map.annotations filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"!(self isKindOfClass: %@)",[MKUserLocation class]]]];
	
	for (NSDictionary *dict in tabResults) {
		Pin *point = [[Pin alloc]init];
		point.coordinate = CLLocationCoordinate2DMake([[dict objectForKey:@"latitude"]doubleValue],[[dict objectForKey:@"longitude"]doubleValue]);
		point.title = [Misc first:[dict objectForKey:@"firstName"]lastName:[dict objectForKey:@"lastName"]];
		point.subtitle = [dict objectForKey:qButton.tag==1?@"question":@"answer"];
		point.dict = dict;
		[map addAnnotation:point];
		[point release];
	}
	
	if (tab==0) [Misc fitMapAnnotations:map];
}

- (void)reloadTable {[self applySearchField:search];}

- (IBAction)listMap:(UIButton*)sender {
	if (tab==1) tab=0; // Was List going to Map
	else tab=1; // Was Map going to List
	
	[search resignFirstResponder];
	
	[self reloadView];
}

- (void)toProfile:(UIControl*)sender {
	Profile *v = [[Profile alloc]init];
	v.uid = [NSString stringWithFormat:@"%d",sender.tag];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return [searchResults count];}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Configure the cell...
	NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
	
	TextCell *c = (TextCell*)[tableView dequeueReusableCellWithIdentifier:@"T"];
	if (!c) c = [[[TextCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"T"]autorelease];
		
	if (qButton.tag==1) {
		c.main.text = [dict objectForKey:@"question"];
			
		NSString *nAns = [dict objectForKey:@"numAnswers"];
			
		c.foot.text = [NSString stringWithFormat:@"%@, %@ answer%@",[Misc timeSinceNow:[dict objectForKey:@"datetime"]],nAns,[nAns intValue]==1?@"":@"s"];
		c.selectable = YES;
	} else { // aButton.tag==1
		c.main.text = [dict objectForKey:@"answer"];
			
		NSString *nLik = [dict objectForKey:@"numLike"];
		NSString *nDis = [dict objectForKey:@"numDislike"];
		NSString *nCom = [dict objectForKey:@"numComments"];
			
		c.foot.text = [NSString stringWithFormat:@"%@, %@ like%@, %@ dislike%@, %@ comment%@",[Misc timeSinceNow:[dict objectForKey:@"datetime"]],nLik,[nLik intValue]==1?@"":@"s",nDis,[nDis intValue]==1?@"":@"s",nCom,[nCom intValue]==1?@"":@"s"];
		c.selectable = YES;
	}
		
	c.accessoryView = [Misc detailDisclosure];
		
	return c;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {return [Misc buffer]*2+[Misc imageSize]-[Misc heightForFontSize:[Misc nameSize]];}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	Question *v = [[Question alloc]init];
	v.qid = [[NSString alloc]initWithString:[[searchResults objectAtIndex:indexPath.row]objectForKey:@"questionID"]];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

#pragma mark -
#pragma mark MKMapViewDelegate

- (MKAnnotationView*)mapView:(MKMapView*)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
	MKAnnotationView *pin = nil;
	pin = [map dequeueReusableAnnotationViewWithIdentifier:@"A"];
	if (pin==nil) pin = [[[MKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:@"A"]autorelease];
	pin.canShowCallout = YES;
	
	NSDictionary *d = ((Pin*)annotation).dict;
	
	pin.leftCalloutAccessoryView = [Misc leftPin:d];
	pin.rightCalloutAccessoryView = [Misc rightPin:@"map detail"];
	
	if (annotation==map.userLocation) return pin;
	int qUserID = [[d objectForKey:@"userID"]intValue];
	NSString *imageName = @"";
	if ([((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).followingIDs objectForKey:[d objectForKey:@"userID"]]) imageName = @"map orange";
	else if (qUserID==[[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue]) imageName = @"map dark teal";
	else imageName = @"map teal";
	imageName = [imageName stringByAppendingString:aButton.tag==1?@" Answer":@" Question"];
	imageName = [imageName stringByAppendingString:(aButton.tag==0&&[[d objectForKey:@"numAnswers"]intValue]==0)?@" glow":@""];
	
	pin.image = [UIImage imageNamed:imageName];
	
	return pin;
}

- (void)mapView:(MKMapView*)mapView annotationView:(MKAnnotationView*)annotationView calloutAccessoryControlTapped:(UIControl*)control {
	NSDictionary *d = ((Pin*)annotationView.annotation).dict;
	if (control.tag==1) {
		Profile *v = [[Profile alloc]init];
		v.uid = [[NSString alloc]initWithString:[d objectForKey:@"userID"]];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	} else if (control.tag==2) {
		Question *v = [[Question alloc]init];
		v.qid = [[NSString alloc]initWithString:[d objectForKey:@"questionID"]];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	}
}

#pragma mark -
#pragma mark UIScrollView

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	CGSize c = scrollView.contentSize;
	CGSize f = scrollView.frame.size;
	if (s.y<0&&![kuipp fetchingData]) {
		if (!refreshCell.flipped) [refreshCell flip];
	} else if (c.height-table.tableHeaderView.frame.size.height>f.height&&s.y>c.height-f.height&&![kuipp fetchingData]) {
		[self refreshMore];
	} else {
		if (refreshCell.flipped) [refreshCell flip];
	}
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		[self refreshAll];
	}
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	/*NSDictionary *info = [note userInfo];
	 NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	 
	 CGRect kb;
	 [[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	 
	 int shiftView = 40;
	 
	 [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	 [UIView setAnimationDuration:animationDuration];
	 if (delta==0) {
	 table.frame = CGRectMake(0,shiftView,320,460-shiftView);
	 self.view.frame = CGRectMake(0,0,320,460);
	 } else {
	 self.view.frame = CGRectMake(0,0-shiftView,320,460);
	 table.frame = CGRectMake(0,shiftView,320,460-kb.size.height);
	 }
	 [UIView commitAnimations];*/
}

- (void)keyboardWasShown:(NSNotification*)note {[self keyboardAdjust:note:1];}

- (void)keyboardWasHidden:(NSNotification*)note {[self keyboardAdjust:note:0];}

#pragma mark -
#pragma mark UISearchBarDelegate

/*- (BOOL)searchString:(NSArray*)array inDict:(NSDictionary*)dict {
	BOOL found = YES;
	NSString *element;
	for (int i=0;i<[array count];i++) {
		element = [[[array objectAtIndex:i]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]lowercaseString];
		
		if ([element length]!=0) {
			NSRange r1 = [[[dict objectForKey:@"firstName"]lowercaseString]rangeOfString:element];
			
			NSRange r2 = [[[dict objectForKey:@"lastName"]lowercaseString]rangeOfString:element];
			
			NSRange r3 = [[[dict objectForKey:@"email"]lowercaseString]rangeOfString:element];
			
			NSRange r4 = [[[dict objectForKey:@"question"]lowercaseString]rangeOfString:element];
			
			NSRange r5 = [[[dict objectForKey:@"answer"]lowercaseString]rangeOfString:element];
			
			found = found && (r1.length>0 || r2.length>0 || r3.length>0 || r4.length>0 || r5.length>0);
			
			if (!found) return NO;
		}
	}
	return found;
}*/

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	[lastIDs release];
	lastIDs = [[NSString alloc]initWithString:@"0"];
	[counts release];
	counts = [[NSString alloc]initWithString:@"1"];
	[self refreshAll];
	[searchBar resignFirstResponder];
}

- (void)applySearchField:(UISearchBar*)searchBar {
	[searchResults release];
	
	searchResults = [[NSMutableArray alloc]initWithArray:tabResults];
	
	[table reloadData];
	double rch = table.tableHeaderView.frame.size.height;
	if (table.contentOffset.y<rch) [table setContentOffset:CGPointMake(0,table.tableHeaderView.frame.size.height) animated:[Misc tableHideHeaderAnimated]];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {[searchBar resignFirstResponder];}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:YES animated:YES];
	[table setContentOffset:CGPointMake(0,[Misc refreshCellHeight]) animated:[Misc tableHideHeaderAnimated]];
	[table setAllowsSelection:NO];
	[table setScrollEnabled:NO];
	return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:NO animated:YES];
	[table setAllowsSelection:YES];
	[table setScrollEnabled:YES];
	return YES;
}

#pragma mark -
#pragma mark Initialization
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	for (UIView *v in [search subviews]) {
		if ([v conformsToProtocol:@protocol(UITextInputTraits)]) {
			@try {
				[(UITextField*)v setEnablesReturnKeyAutomatically:NO];
				[(UITextField*)v setKeyboardAppearance:UIKeyboardAppearanceAlert];
			}
			@catch (NSException *e) {
				NSLog(@"failed to change searchTextField's color and button");
			}
		}
	}
	
	tab=1;
	
	[Misc load:self];
	self.navigationItem.rightBarButtonItem = [Misc mapList:tab];
	[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(listMap:) forControlEvents:UIControlEventTouchUpInside];
	
	UIView *v = [[UIView alloc]init];
	CGRect s = search.frame;
	double w = s.size.width;
	double h = s.size.height;
	double r = [Misc refreshCellHeight];
	v.frame = CGRectMake(0,0,w,r+h);
	refreshCell = [Misc refreshCellView];
	refreshCell.table = table;
	refreshCell.frame = CGRectMake(0, 0, self.view.frame.size.width, r);
	search.frame = CGRectMake(0,r,w,h);
	[v addSubview:search];
	[v addSubview:refreshCell];
	
	[table setTableHeaderView:v];
	[v release];
	
	v = [[UIView alloc]init];
	v.contentMode = UIViewContentModeCenter;
	moreCell = [Misc activityView];
	double aiw = moreCell.frame.size.width;
	h = moreCell.frame.size.height;
	v.frame = CGRectMake((w-aiw)/2, 0, aiw, h);
	[v addSubview:moreCell];
	[table setTableFooterView:v];
	[v release];
	
	table.contentInset = UIEdgeInsetsMake(-r,0,0,0);
	
	qButton.tag = 1;
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	
	[self filter:qButton.tag==1?qButton:aButton];
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[uid release];
	map.delegate = nil;
	table.delegate = nil;
	table.dataSource = nil;
	search.delegate = nil;
	
    [super dealloc];
}

@end
