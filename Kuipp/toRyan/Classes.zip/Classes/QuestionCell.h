//
//  QuestionCell.h
//  Kuipp
//
//  Created by Brandon Jue on 1/29/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuestionCell : UITableViewCell {
	IBOutlet UIImageView *pic;
	IBOutlet UILabel *qOwner;
	IBOutlet UILabel *qQuestion;
	IBOutlet UILabel *qClass;
	IBOutlet UILabel *qTime;
}

@property(nonatomic,retain) UIImageView *pic;
@property(nonatomic,retain) UILabel *qOwner;
@property(nonatomic,retain) UILabel *qQuestion;
@property(nonatomic,retain) UILabel *qClass;
@property(nonatomic,retain) UILabel *qTime;

@end
