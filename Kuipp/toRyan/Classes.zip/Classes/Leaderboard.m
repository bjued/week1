//
//  Leaderboard.m
//  Kuipp
//
//  Created by Brandon Jue on 3/14/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "Leaderboard.h"
#import "Profile.h"
#import "LeaderCell.h"
#import "ASyncImageLoadDelegate.h"

@implementation Leaderboard

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)mainThreadImages {
	[images release];
	images = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images retain];
	for (NSDictionary *d in dicts) {
		NSString *url = [d objectForKey:@"picture"];
		NSString *pic = [images objectForKey:url];
		if (pic==nil||[pic isEqual:[Misc defaultProfile]]) {
			[images setObject:[Misc defaultProfile]forKey:url];
			if (![url isEqualToString:[Misc defaultProfileURL]]) {
				ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
				[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
			}
		}
	}
}

- (void)aSyncImageLoaded {[table reloadData];}

- (void)refreshAll {
	[refreshCell refreshing];
	
	[kuipp formTo:@"selectLeaderboard"];
}

- (void)refresh:(id)obj {
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self mainThreadImages];
	
	[refreshCell refreshed];
	
	[self filter:aButton.tag==1?aButton:fButton];
}

- (IBAction)filter:(UIButton*)sender {
	[aButton setBackgroundImage:[Misc wideTabImage:sender==aButton]forState:UIControlStateNormal];
	aButton.tag = sender==aButton?1:0;
	[fButton setBackgroundImage:[Misc wideTabImage:sender==fButton]forState:UIControlStateNormal];
	fButton.tag = sender==fButton?1:0;
	
	[tabResults release];
	tabResults = [[NSMutableArray alloc]init];
				   
	for (NSDictionary *d in dicts) {
		if (aButton.tag==1&&[[d objectForKey:@"board"]intValue]==1) [tabResults addObject:d];
		else if (fButton.tag==1&&[[d objectForKey:@"board"]intValue]==2) [tabResults addObject:d];
	}
	
	[self reloadView];
}

- (void)reloadView {[self reloadTable];}

- (void)reloadTable {
	[table reloadData];
	[table setContentOffset:CGPointMake(0,table.tableHeaderView.frame.size.height) animated:[Misc tableHideHeaderAnimated]];
}

- (void)toProfile:(UIControl*)sender {
	Profile *v = [[Profile alloc]init];
	v.uid = [[NSString alloc]initWithFormat:@"%d",sender.tag];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return [tabResults count];}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	LeaderCell *c = (LeaderCell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
	if (!c) c = [[[LeaderCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"A"]autorelease];
	
    // Configure the cell...
	NSDictionary *d = [tabResults objectAtIndex:indexPath.row];
	
	c.dict = d;
	
	c.rank.text = [NSString stringWithFormat:@"%2d",indexPath.row+(aButton.tag==1?1:(indexPath.row==0?[[d objectForKey:@"rank"]intValue]:0))];
	
	c.imag.image = [images objectForKey:[d objectForKey:@"picture"]];
	
	c.name.text = [Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]];
	
	c.foot.text = [NSString stringWithFormat:@"Level %@ %@, %@ points",[d objectForKey:@"level"],[d objectForKey:@"class"],[d objectForKey:@"points"]];
	c.selectable = (fButton.tag==1&&indexPath.row==0)?NO:YES;
	
	c.accessoryView = (fButton.tag==1&&indexPath.row==0)?nil:[Misc detailDisclosure];
			
	return c;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {return [Misc buffer]*((fButton.tag==1&&indexPath.row==0)?8:2)+[Misc leaderSize];}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	if (fButton.tag==1&&indexPath.row==0) return;
	NSDictionary *d = [tabResults objectAtIndex:indexPath.row];
	Profile *v = [[Profile alloc]init];
	v.uid = [[NSString alloc]initWithString:[d objectForKey:@"userID"]];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

#pragma mark -
#pragma mark UIScrollView

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		if (!refreshCell.flipped) [refreshCell flip];
	} else {
		if (refreshCell.flipped) [refreshCell flip];
	}
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		[self refreshAll];
	}
}

#pragma mark -
#pragma mark Initialization
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	[Misc load:self];
	
	double r = [Misc refreshCellHeight];
	refreshCell = [Misc refreshCellView];
	refreshCell.table = table;
	refreshCell.frame = CGRectMake(0, 0, self.view.frame.size.width, r);
	[table setTableHeaderView:refreshCell];
	
	table.contentInset = UIEdgeInsetsMake(-[Misc refreshCellHeight],0,0,0);
	
	aButton.tag = 1;
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aSyncImageLoaded) name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	[self refreshAll];
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	table.delegate = nil;
	table.dataSource = nil;
	
    [super dealloc];
}

@end
