//
//  Game.h
//  Kuipp
//
//  Created by Brandon Jue on 2/27/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "UIScrollViewCancelControls.h"

@interface Game : UIViewController <UISearchBarDelegate,UIScrollViewDelegate,UITableViewDelegate> {
	NSString *fromProfile;
	int medDisp;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableDictionary *images;
	
	RefreshCell *refreshCell;
	UIActivityIndicatorView *moreCell;
	
	NSArray *medNames;
	NSArray *medDescs;
	
	NSString *lastIDs;
	NSString *counts;
	
	NSMutableArray *updates;
	NSMutableArray *medals;
	
	NSMutableArray *tabResults;
	
	// Views
	IBOutlet UITableView *table;
	IBOutlet UIView *scrollV;
	IBOutlet UIView *imageV;
	IBOutlet UILabel *mName;
	IBOutlet UIImageView *image;
	UIView *divider;
	IBOutlet UILabel *text;
	IBOutlet UIScrollViewCancelControls *scroll;
	
	// Tabs
	IBOutlet UIButton *uButton;
	IBOutlet UIButton *mButton;
	IBOutlet UIButton *lButton;
}

- (void)classTest;
- (void)medalTest;
@property(nonatomic,retain) NSString *fromProfile;
@property(nonatomic,assign) int medDisp;
- (void)back;
- (void)createGhostsMedals:(NSArray *)names descriptions:(NSArray *)descs;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)splitData;
- (IBAction)filter:(UIButton*)sender;
- (IBAction)leaderboard:(UIButton*)sender;
- (void)reloadView;
- (void)reloadScroll;
- (void)reloadTable;
- (void)displayMedal:(UIButton *)sender;
- (void)toProfile:(UIControl *)sender;
- (void)toMedals:(UIControl *)sender;

@end
