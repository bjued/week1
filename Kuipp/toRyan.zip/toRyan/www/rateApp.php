<?
exit ("http://kuipp.com");
?>
