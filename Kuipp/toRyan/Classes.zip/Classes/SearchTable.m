//
//  SearchTable.m
//  Kuipp
//
//  Created by Brandon Jue on 5/26/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "SearchTable.h"
#import "LeaderCell.h"
#import "Inbox.h"
#import "AskTab.h"
#import "Party.h"
#import "ASyncImageLoadDelegate.h"

@implementation SearchTable

@synthesize type,askTab,compose,checks,party;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)mainThreadImages {
	[images release];
	images = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images retain];
	for (NSDictionary *d in dicts) {
		NSString *url = [d objectForKey:@"picture"];
		NSString *pic = [images objectForKey:url];
		if (!pic||[pic isEqual:[Misc defaultProfile]]) {
			[images setObject:[Misc defaultProfile]forKey:url];
			if (![url isEqualToString:[Misc defaultProfileURL]]) {
				ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
				[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
			}
		}
	}
}

- (void)aSyncImageLoaded {[table reloadData];}

- (void)refreshAll {
	facebook = ((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).facebook;
	[kuipp cancel];
	if ([type isEqualToString:@"Kuipp"]||[type isEqualToString:@"Party"]) [kuipp formTo:@"listKuipp"];
	else if ([type isEqualToString:@"Facebook"]) [kuipp formTo:@"listFacebook" WithPost:[NSString stringWithFormat:@"at=%@",facebook.accessToken]];
	else if ([type isEqualToString:@"Twitter"]) [kuipp formTo:@"listTwitter"];
	else if ([type isEqualToString:@"Scholarships"]) [kuipp formTo:@"listScholarships"];
}

- (void)refresh:(id)obj {
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	if (![type isEqualToString:@"Facebook"]&&![type isEqualToString:@"Scholarships"]) [self mainThreadImages];
	
	[self insertChecks];
	
	[searchArray release];
	searchArray = [[NSMutableArray alloc]initWithArray:dicts];
	
	[table reloadData];
	double rch = table.tableHeaderView.frame.size.height;
	if (table.contentOffset.y<rch) [table setContentOffset:CGPointMake(0,rch) animated:[Misc tableHideHeaderAnimated]];
}

- (void)insertChecks {
	BOOL kpp = [type isEqualToString:@"Kuipp"];
	BOOL fbk = [type isEqualToString:@"Facebook"];
	BOOL sch = [type isEqualToString:@"Scholarships"];
	if (kpp||fbk) for (int i=0;i<[dicts count];i++) {
		NSMutableDictionary *d = [dicts objectAtIndex:i];
		if ((kpp&&[checks objectForKey:[d objectForKey:@"userID"]])||
			(fbk&&[checks objectForKey:[d objectForKey:@"facebookID"]])) {
			[d setObject:@"1" forKey:@"checked"];
			[dicts replaceObjectAtIndex:i withObject:d];
		}
	}
	if (sch) for (int i=0;i<[dicts count];i++) {
		NSMutableDictionary *d = [dicts objectAtIndex:i];
		if (sch&&[[d objectForKey:@"accepted"]intValue]==1) {
			[d setObject:@"1" forKey:@"checked"];
			[dicts replaceObjectAtIndex:i withObject:d];
		}
	}
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return [searchArray count];}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	LeaderCell *c = (LeaderCell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
	if (!c) c = [[[LeaderCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"A"]autorelease];
	
	NSDictionary *d = [searchArray objectAtIndex:indexPath.row];
	BOOL diff = [type isEqualToString:@"Facebook"]||[type isEqualToString:@"Scholarships"];
	c.dict = d;
	
	c.rank.text = @"";
	
	c.mark.image = [d objectForKey:@"checked"]?[[Misc checkmark]image]:[[Misc checkmarkPlaceholder]image];
	
	UIImage *img;
	if (diff) img = nil;
	else img = [images objectForKey:[d objectForKey:@"picture"]];
	c.imag.image = img;
	
	NSString *name;
	if (diff) name = [d objectForKey:@"name"];
	else name = [Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]];
	c.name.text = name;
	
	c.selectable = YES;
	
	return c;
}

/*
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
	return (tab==0&&([uid intValue]==0||[uid isEqualToString:[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]]))?YES:NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
	if (editingStyle == UITableViewCellEditingStyleDelete) {
		[self deleteFollowing:indexPath.row];
	}
}

 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {return [Misc buffer]*2+[Misc leaderSize];}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	NSMutableDictionary *d = [searchArray objectAtIndex:indexPath.row];
	if (![d objectForKey:@"checked"]) {
		[d setObject:@"1" forKey:@"checked"];
		if (askTab) {
			[(AskTab*)askTab toUser:[[d objectForKey:@"userID"]intValue]using:@"Kuipp"];
			[(AskTab*)askTab toUser:[[d objectForKey:@"facebookID"]intValue]using:@"Facebook"];
			[(AskTab*)askTab toUser:[[d objectForKey:@"twitterID"]intValue]using:@"Twitter"];
		}
		if (compose) {
			[(Inbox*)compose toUser:[[d objectForKey:@"userID"]intValue]withName:[Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]]];
			[self back];
		}
		if (party) {
			if ([type isEqualToString:@"Party"]) {
				[(Party*)party invite:[[d objectForKey:@"userID"]intValue]withName:[Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]]];
				[self back];
			} else if ([type isEqualToString:@"Scholarships"]) {
				[(Party*)party accept:[d objectForKey:@"name"]];
			}
		}
	} else {
		[d removeObjectForKey:@"checked"];
		if (askTab) {
			[(AskTab*)askTab removeUser:[[d objectForKey:@"userID"]intValue]using:@"Kuipp"];
			[(AskTab*)askTab removeUser:[[d objectForKey:@"facebookID"]intValue]using:@"Facebook"];
			[(AskTab*)askTab removeUser:[[d objectForKey:@"twitterID"]intValue]using:@"Twitter"];
		}
		if ([type isEqualToString:@"Scholarships"]&&party) {
			[(Party*)party leave];
		}
	}
	[searchArray replaceObjectAtIndex:indexPath.row withObject:d];
	[table reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationFade];
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	/*NSDictionary *info = [note userInfo];
	 NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	 
	 CGRect kb;
	 [[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	 
	 int shiftView = 37;
	 double w = self.view.frame.size.width;
	 double h = self.view.frame.size.height;
	 
	 [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	 [UIView setAnimationDuration:animationDuration];
	 if (delta==0) {
	 table.frame = CGRectMake(0,shiftView,w,h-shiftView);
	 self.view.frame = CGRectMake(0,0,w,h);
	 table.contentOffset = CGPointMake(0,table.tableHeaderView.frame.size.height);
	 } else {
	 self.view.frame = CGRectMake(0,0-shiftView,w,h);
	 table.frame = CGRectMake(0,shiftView,w,h-kb.size.height+49);
	 table.contentOffset = CGPointMake(0,[Misc refreshCellHeight]);
	 }
	 [UIView commitAnimations];*/
}

- (void)keyboardWasShown:(NSNotification*)note {[self keyboardAdjust:note:1];}

- (void)keyboardWasHidden:(NSNotification*)note {[self keyboardAdjust:note:0];}

#pragma mark -
#pragma mark UISearchBarDelegate

- (BOOL)searchString:(NSArray*)array inDict:(NSDictionary*)d {
	NSString *e;
	for (NSString *s in array) {
		e = [[s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]lowercaseString];
		int i = [e length];
		
		if (i>0) {
			NSRange r1 = [[[d objectForKey:@"firstName"]lowercaseString]rangeOfString:e];
			
			NSRange r2 = [[[d objectForKey:@"lastName"]lowercaseString]rangeOfString:e];
			
			NSRange r3 = [[[d objectForKey:@"name"]lowercaseString]rangeOfString:e];
			
			if (r1.length!=i && r2.length!=i && r3.length!=i) return NO;
		}
	}
	return YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
	[searchArray release];
	
	if ([searchBar.text length]==0) {
		searchArray = [[NSMutableArray alloc]initWithArray:dicts];
	} else {
		searchArray = [[NSMutableArray alloc]init];
		
		NSArray *explode = [searchBar.text componentsSeparatedByString:@" "];
		for (NSDictionary *d in dicts) {
			if ([self searchString:explode inDict:d]) {
				[searchArray addObject:d];
			}
		}
	}
	
	[table reloadData];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {[searchBar resignFirstResponder];}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {[searchBar resignFirstResponder];}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:YES animated:YES];
	
	[table setContentOffset:CGPointMake(0,0) animated:[Misc tableHideHeaderAnimated]];

	[table setAllowsSelection:NO];
	[table setScrollEnabled:NO];
	return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:NO animated:YES];
	
	double rch = table.tableHeaderView.frame.size.height;
	if (table.contentOffset.y<rch) [table setContentOffset:CGPointMake(0,rch) animated:[Misc tableHideHeaderAnimated]];
	
	[table setAllowsSelection:YES];
	[table setScrollEnabled:YES];
	return YES;
}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	for (UIView *v in [search subviews]) {
		if ([v conformsToProtocol:@protocol(UITextInputTraits)]) {
			@try {
				[(UITextField*)v setEnablesReturnKeyAutomatically:NO];
				[(UITextField*)v setKeyboardAppearance:UIKeyboardAppearanceAlert];
			}
			@catch (NSException *e) {
				NSLog(@"failed to change searchTextField's color and button");
			}
		}
	}
	
	[Misc load:self];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aSyncImageLoaded) name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	
	[self refreshAll];
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[type release];
	[askTab release];
	[compose release];
	[party release];
	[checks release];
	table.delegate = nil;
	table.dataSource = nil;
	search.delegate = nil;
	
    [super dealloc];
}

@end
