//
//  LineCell.m
//  Kuipp
//
//  Created by Brandon Jue on 3/14/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "LineCell.h"


@implementation LineCell

@synthesize selectable,main;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        // Initialization code.
		cell = [[UIView alloc]init];
		
		main = [[UILabel alloc]init];
		main.backgroundColor = [UIColor clearColor];
		main.font = [main.font fontWithSize:[Misc nameSize]];
		main.textColor = [UIColor darkGrayColor];
		
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		
		[self.contentView addSubview:cell];
		[self.contentView addSubview:main];
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect c = self.frame;
	double w = c.size.width;
	double h = c.size.height;
	
	cell.frame = CGRectMake(0,0,w,h);
	
	c = self.contentView.bounds;
	w = c.size.width;
	h = c.size.height;
	
	double buf = [Misc buffer];
	
	main.frame = CGRectMake(buf*2,0,w-buf*4,h);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	cell.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)setHighlighted:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	cell.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)dealloc {
	[main release];
	
    [super dealloc];
}

@end
