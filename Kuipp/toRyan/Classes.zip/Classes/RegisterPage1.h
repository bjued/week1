//
//  RegisterPage1.h
//  Kuipp
//
//  Created by Brandon Jue on 4/23/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterPage1 : UIViewController <UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate> {
	IBOutlet UITableView *table;
	
	IBOutlet UITextField *fName;
	IBOutlet UITextField *lName;
	IBOutlet UITextField *email;
}

- (void)back;
- (void)next;
- (void)backgroundTouched:(id)sender;
- (void)keyboardAdjust:(NSNotification*)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
