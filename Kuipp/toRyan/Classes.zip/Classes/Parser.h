//
//  Parser.h
//  Kuipp
//
//  Created by Brandon Jue on 12/19/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Parser : NSObject {
	NSMutableArray *dicts;
}

- (id)initWithDicts:(NSMutableArray*)d;
- (void)parseXML:(NSString*)s;
- (void)parseItems:(NSString*)s;
- (void)parseFields:(NSString *)s andHead:(NSString*)h;

@end
