//
//  LoginView.h
//  Kuipp
//
//  Created by Brandon Jue on 12/14/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginView : UIViewController <UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIAlertViewDelegate> {
	IBOutlet UITableView *table;
	
	IBOutlet UITextField *email;
	IBOutlet UITextField *password;
}

- (IBAction)backgroundTouched:(id)sender;
- (void)login;
- (void)createNew;
- (void)forgotPassword;
- (void)keyboardAdjust:(NSNotification*)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
