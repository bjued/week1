<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Mail Admin</title>
</head>

<body>
<center>Add Email User Form</center>
<form action="addEmailUser.php" method="post">
Admin Name: <input type="text" name="aName"><br><br>
Admin Password: <input type="password" name="aPassword"><br><br>
User Name: <input type="text" name="name"><br><br>
User Password: <input type="text" name="password"><br><br>
<input type="Submit">
</form>

<center>Add Email Domain Form</center>
<form action="addEmailDomain.php" method="post">
Admin Name: <input type="text" name="aName"><br><br>
Admin Password: <input type="password" name="aPassword"><br><br>
Domain: <input type="text" name="domain"><br><br>
Destination: <input type="text" name="dest"><br><br>
<input type="Submit">
</form>
</body>
</html>
