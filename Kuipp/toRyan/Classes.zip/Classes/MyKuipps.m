//
//  MyKuipps.m
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "MyKuipps.h"
#import "QuestionCell.h"
#import "QACell.h"
#import "UpdateCell1.h"
#import "UpdateCell2.h"
#import "UpdateCell3.h"
#import "Question.h"
#import "Answer.h"
#import "Profile.h"
#import "KuippConnect.h"
#import "Parser.h"

@implementation MyKuipps

@synthesize tab;

- (IBAction)popBack:(UIButton*)sender {
	[self.navigationController popToViewController:[[self.navigationController viewControllers]objectAtIndex:1] animated:YES];
}

- (IBAction)refresh:(UIButton*)sender {
	NSURLResponse *response;
	NSError *error;
	
	NSString *urlContents = [KuippConnect formTo:@"selectMyKuipps" WithPost:@"" AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:1]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode forView:self]) return;
	
	if (dicts!=nil) [dicts release];
	if (heads!=nil) [heads release];
	dicts = [[NSMutableArray alloc]init];
	heads = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts AndHeads:heads];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	
	switch (tab) {
		case  0:	[self asked:askedButton];break;
		case  1:	[self answered:answeredButton];break;
		case  2:	[self update:updatesButton];break;
		default:	break;
	}
}

- (IBAction)update:(UIButton*)sender {
	tab = 2;
	
	if (tabResults!=nil) [tabResults release];
	tabResults = [[NSMutableArray alloc]initWithArray:updates];
	
	[search setText:@""];
	//[self searchBar:search textDidChange:search.text];
	[self searchBarSearchButtonClicked:search];
	[table setTableHeaderView:nil];
	
	[self selectTab:sender];
}

- (IBAction)asked:(UIButton*)sender {
	tab = 0;
	
	if (tabResults!=nil) [tabResults release];
	tabResults = [[NSMutableArray alloc]initWithArray:questions];
	
	[search setText:@""];
	[search setPlaceholder:@"Search Questions You've Asked"];
	//[self searchBar:search textDidChange:search.text];
	[self searchBarSearchButtonClicked:search];
	[table setTableHeaderView:search];
	
	[self selectTab:sender];
}

- (IBAction)answered:(UIButton*)sender {
	tab = 1;
	
	if (tabResults!=nil) [tabResults release];
	tabResults = [[NSMutableArray alloc]initWithArray:answers];
	
	[search setText:@""];
	[search setPlaceholder:@"Search Answers You've Given"];
	//[self searchBar:search textDidChange:search.text];
	[self searchBarSearchButtonClicked:search];
	[table setTableHeaderView:search];
	
	[self selectTab:sender];
}

- (void)selectTab:(UIButton*)sender {
	UIColor *color = [UIColor blackColor];
	[updatesButton setTitleColor:color
						forState:UIControlStateNormal];
	[askedButton setTitleColor:color
					  forState:UIControlStateNormal];
	[answeredButton setTitleColor:color
						 forState:UIControlStateNormal];
	[sender setTitleColor:[UIColor blueColor]
				 forState:UIControlStateNormal];
}

- (IBAction)backgroundTouched:(UIControl*)sender {
	[search resignFirstResponder];
}

- (void)splitData {
	if (questions!=nil) [questions release];
	if (answers!=nil) [answers release];
	if (updates!=nil) [updates release];
	
	questions = [[NSMutableArray alloc]init];
	answers = [[NSMutableArray alloc]init];
	updates = [[NSMutableArray alloc]init];
	
	for (int i=0;i<[heads count];i++) {
		if ([[heads objectAtIndex:i] isEqualToString:@"Questions"]) {
			[questions addObject:[dicts objectAtIndex:i]];
		} else if ([[heads objectAtIndex:i] isEqualToString:@"Answers"]) {
			[answers addObject:[dicts objectAtIndex:i]];
		} else if ([[heads objectAtIndex:i] isEqualToString:@"Updates"]) {
			[updates addObject:[dicts objectAtIndex:i]];
		}
	}
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return [searchResults count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Configure the cell...
	NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
	
	// Find timeSince (choose to use year, day, hour, minute, second)
	NSString *date = [dict objectForKey:@"datetime"];
	NSTimeInterval time = [[NSDate dateWithTimeIntervalSince1970:[date intValue]]timeIntervalSinceNow] * -1;
	NSString *since = @"";
	if (((int)time)/60/60/24/365>0) {
		since = [NSString stringWithFormat:@"%d year%@ ago",((int)time)/60/60/24/365,((int)time)/60/60/24/365==1?@"":@"s"];
	} else if (((int)time)/60/60/24>0) {
		since = [NSString stringWithFormat:@"%d day%@ ago",((int)time)/60/60/24,((int)time)/60/60/24==1?@"":@"s"];
	} else if (((int)time)/60/60>0) {
		since = [NSString stringWithFormat:@"%d hour%@ ago",((int)time)/60/60,((int)time)/60/60==1?@"":@"s"];
	} else if (((int)time)/60>0) {
		since = [NSString stringWithFormat:@"%d minute%@ ago",((int)time)/60,((int)time)/60==1?@"":@"s"];
	} else {
		since = [NSString stringWithFormat:@"%d second%@ ago",((int)time),((int)time)==1?@"":@"s"];
	}
	
	switch (tab) {
		case  0: {
			QuestionCell *cell = (QuestionCell*)[tableView dequeueReusableCellWithIdentifier:@"QuestionCell"];
			if (cell==nil) {
				NSArray *top = [[NSBundle mainBundle]loadNibNamed:@"QuestionCell" owner:nil options:nil];
				for (id cur in top) {
					if ([cur isMemberOfClass:[QuestionCell class]]) {
						cell = cur;
						break;
					}
				}
			}
			
			//[cell.pic setImage:[UIImage imageNamed:@"RedPin.png"]];
			cell.pic.backgroundColor = [UIColor clearColor];
			
			cell.qOwner.text = @"";
			
			cell.qQuestion.text = [dict objectForKey:@"question"];
			cell.qQuestion.frame = CGRectMake(4,1,292,15*150);
			[cell.qQuestion sizeToFit];
			
			cell.qClass.text = @"";
			
			cell.qTime.text = [NSString stringWithFormat:@"%@ | %@ answers",since,[dict objectForKey:@"numAnswers"]];
			cell.qTime.frame = CGRectMake(cell.qTime.frame.origin.x,cell.qQuestion.frame.origin.y+cell.qQuestion.frame.size.height,cell.qTime.frame.size.width,cell.qTime.frame.size.height);
			
			cell.frame = CGRectMake(cell.frame.origin.x,cell.frame.origin.y,cell.frame.size.width,cell.qTime.frame.origin.y+cell.qTime.frame.size.height+1);
			
			return cell;
		}
		case  1: {
			QACell *cell = (QACell*)[tableView dequeueReusableCellWithIdentifier:@"QACell"];
			if (cell==nil) {
				NSArray *top = [[NSBundle mainBundle]loadNibNamed:@"QACell" owner:nil options:nil];
				for (id cur in top) {
					if ([cur isKindOfClass:[UITableViewCell class]]) {
						cell = (QACell*)cur;
						break;
					}
				}
			}

			[cell.pic setImage:[UIImage imageNamed:@"RedPin.png"]];
			
			cell.qOwner.text = [NSString stringWithFormat:@"%@ %@. asked:",[dict objectForKey:@"qfirstName"],[[dict objectForKey:@"qlastName"]substringToIndex:1]];
			
			cell.qQuestion.text = [dict objectForKey:@"qquestion"];
			cell.qQuestion.frame = CGRectMake(cell.qQuestion.frame.origin.x,cell.qQuestion.frame.origin.y,232,15*150);
			[cell.qQuestion sizeToFit];
			
			cell.qClass.text = [dict objectForKey:@"qclass"];
			
			cell.aOwner.text = @"You answered";
			cell.aOwner.frame = CGRectMake(cell.aOwner.frame.origin.x,fmax(65,cell.qQuestion.frame.origin.y+cell.qQuestion.frame.size.height)+8,cell.aOwner.frame.size.width,cell.aOwner.frame.size.height);
			
			cell.aAnswer.text = [dict objectForKey:@"answer"];
			cell.aAnswer.frame = CGRectMake(cell.aAnswer.frame.origin.x,cell.aOwner.frame.origin.y+cell.aOwner.frame.size.height,276,15*150);
			[cell.aAnswer sizeToFit];
			
			cell.aTime.text = [NSString stringWithFormat:@"%@ | %@ like | %@ dislike | %@ comments",since,[dict objectForKey:@"numLike"],[dict objectForKey:@"numDislike"],[dict objectForKey:@"numComments"]];
			cell.aTime.frame = CGRectMake(cell.aTime.frame.origin.x,cell.aAnswer.frame.origin.y+cell.aAnswer.frame.size.height,cell.aTime.frame.size.width,cell.aTime.frame.size.height);
			
			cell.frame = CGRectMake(cell.frame.origin.x,cell.frame.origin.y,cell.frame.size.width,cell.aTime.frame.origin.y+cell.aTime.frame.size.height+5);
			cell.aButton.frame = CGRectMake(cell.aButton.frame.origin.x,cell.aOwner.frame.origin.y-4,cell.aButton.frame.size.width,cell.aOwner.frame.size.height+cell.aAnswer.frame.size.height+cell.aTime.frame.size.height+5);
			
			return cell;
		}
		case  2:
			switch ([[dict objectForKey:@"type"]intValue]) {
				case  1: {
					UpdateCell1 *cell = (UpdateCell1*)[tableView dequeueReusableCellWithIdentifier:@"UpdateCell1"];
					if (cell==nil) {
						NSArray *top = [[NSBundle mainBundle]loadNibNamed:@"UpdateCell1" owner:nil options:nil];
						for (id cur in top) {
							if ([cur isMemberOfClass:[UpdateCell1 class]]) {
								cell = cur;
								break;
							}
						}
					}
					
					[cell.pic setImage:[UIImage imageNamed:@"RedPin.png"]];
					
					[cell.name setTitle:[NSString stringWithFormat:@"%@ %@.",[dict objectForKey:@"firstName"],[[dict objectForKey:@"lastName"]substringToIndex:1]]forState:UIControlStateNormal];
					[cell.name sizeToFit];
					 
					cell.primary.text = [NSString stringWithFormat:@" has achieved Level %@",[dict objectForKey:@"intValue"]];
					cell.primary.frame = CGRectMake(cell.name.frame.origin.x+cell.name.frame.size.width,cell.primary.frame.origin.y,cell.primary.frame.size.width,cell.primary.frame.size.height);
					
					cell.secondary.text = since;
					
					cell.nameID = [dict objectForKey:@"userID"];
					return cell;
				}
				case  2: {
					UpdateCell2 *cell = (UpdateCell2*)[tableView dequeueReusableCellWithIdentifier:@"UpdateCell2"];
					if (cell==nil) {
						NSArray *top = [[NSBundle mainBundle]loadNibNamed:@"UpdateCell2" owner:nil options:nil];
						for (id cur in top) {
							if ([cur isMemberOfClass:[UpdateCell2 class]]) {
								cell = cur;
								break;
							}
						}
					}
					
					[cell.picLeft setImage:[UIImage imageNamed:@"RedPin.png"]];
					
					NSString *n = [NSString stringWithFormat:@"%@ %@.",[dict objectForKey:@"firstName"],[[dict objectForKey:@"lastName"]substringToIndex:1]];
					[cell.name setTitle:n forState:UIControlStateNormal];
					[cell.name sizeToFit];
					
					[cell.primary loadHTMLString:[NSString stringWithFormat:@"<html><head><style type=\"text/css\">body {font-family:\"helvetica\"; font-size:12; color:#808080; background-color:#e6e6e6; vertical-align:text-top}name {font-family:\"helvetica\"; font-size:14; color:#e6e6e6; background-color:#e6e6e6; vertical-align:text-top}</style></head><name><b>%@</b></name><body> has achieved Level %@ and reached <b>%@</b> status.</body></html>",n,[dict objectForKey:@"intValue"],[dict objectForKey:@"stringValue"]]baseURL:nil];
					
					[cell.picRight setImage:[UIImage imageNamed:@"BluePin.png"]];
					
					cell.secondary.text = since;
					
					cell.nameID = [dict objectForKey:@"userID"];
					return cell;
				}
				case  3: {
					UpdateCell3 *cell = (UpdateCell3*)[tableView dequeueReusableCellWithIdentifier:@"UpdateCell3"];
					if (cell==nil) {
						NSArray *top = [[NSBundle mainBundle]loadNibNamed:@"UpdateCell3" owner:nil options:nil];
						for (id cur in top) {
							if ([cur isMemberOfClass:[UpdateCell3 class]]) {
								cell = cur;
								break;
							}
						}
					}
					
					[cell.picLeft setImage:[UIImage imageNamed:@"RedPin.png"]];
					
					[cell.name1 setTitle:[NSString stringWithFormat:@"%@ %@.",[dict objectForKey:@"firstName"],[[dict objectForKey:@"lastName"]substringToIndex:1]] forState:UIControlStateNormal];
					[cell.name1 sizeToFit];
					
					cell.primary1.frame = CGRectMake(cell.name1.frame.origin.x+cell.name1.frame.size.width,cell.primary1.frame.origin.y,cell.primary1.frame.size.width,cell.primary1.frame.size.height);
					
					NSString *n2 = [NSString stringWithFormat:@"%@ %@.",[dict objectForKey:@"firstName2"],[[dict objectForKey:@"lastName2"]substringToIndex:1]];
					[cell.name2 setTitle:n2 forState:UIControlStateNormal];
					[cell.name2 sizeToFit];
					
					[cell.primary2 loadHTMLString:[NSString stringWithFormat:@"<html><head><style type=\"text/css\">body {font-family:\"helvetica\"; font-size:12; color:#808080; background-color:#e6e6e6; vertical-align:text-top}name {font-family:\"helvetica\"; font-size:14; color:#e6e6e6; background-color:#e6e6e6; vertical-align:text-top}</style></head><name><b>%@</b></name><body> as a <b>%@</b></body></html>",n2,[dict objectForKey:@"stringValue"]]baseURL:nil];
					
					[cell.picRight setImage:[UIImage imageNamed:@"BluePin.png"]];
					
					cell.secondary.text = since;
					
					cell.nameID1 = [dict objectForKey:@"userID"];
					cell.nameID2 = [dict objectForKey:@"userID2"];
					return cell;
				}
				default:	break;
			}
			break;
		default:	break;
	}
	return nil;
}
/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */
/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */
/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */
/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */
#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	switch (tab) {
		case  0: {
			NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
			
			UILabel *one = [[UILabel alloc]init];
			one.text = @"1";
			one.font = [one.font fontWithSize:14];
			[one sizeToFit];
			
			UILabel *two = [[UILabel alloc]init];
			two.text = [dict objectForKey:@"question"];
			two.font = [two.font fontWithSize:12];
			two.numberOfLines = 0;
			two.frame = CGRectMake(0,1,292,15*150);
			[two sizeToFit];
			
			UILabel *three = [[UILabel alloc]init];
			three.text = @"1";
			three.font = [three.font fontWithSize:12];
			three.frame = CGRectMake(0,two.frame.origin.y+two.frame.size.height,15,15);
			[three sizeToFit];
			
			int ret = three.frame.origin.y+three.frame.size.height+1;
			
			[one release];
			[two release];
			[three release];
			
			return ret;
		}
		case  1: {
			NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
			
			UILabel *one = [[UILabel alloc]init];
			one.text = @"1";
			one.font = [one.font fontWithSize:14];
			[one sizeToFit];
			
			UILabel *two = [[UILabel alloc]init];
			two.text = [dict objectForKey:@"qquestion"];
			two.font = [two.font fontWithSize:12];
			two.numberOfLines = 0;
			two.frame = CGRectMake(0,one.frame.size.height,232,15*150);
			[two sizeToFit];
			
			UILabel *three = [[UILabel alloc]init];
			three.text = @"1";
			three.font = [three.font fontWithSize:14];
			three.frame = CGRectMake(0,fmax(65,two.frame.origin.y+two.frame.size.height)+8,15,17);
			[three sizeToFit];
			
			UILabel *four = [[UILabel alloc]init];
			four.text = [dict objectForKey:@"answer"];
			four.font = [four.font fontWithSize:12];
			four.numberOfLines = 0;
			four.frame = CGRectMake(0,three.frame.origin.y+three.frame.size.height,276,15*150);
			[four sizeToFit];
			
			UILabel *five = [[UILabel alloc]init];
			five.text = @"1";
			five.font = [five.font fontWithSize:12];
			five.frame = CGRectMake(0,four.frame.origin.y+four.frame.size.height,15,15);
			[five sizeToFit];
			
			int ret = five.frame.origin.y+five.frame.size.height+5;
			
			[one release];
			[two release];
			[three release];
			[four release];
			[five release];
			
			return ret;
		}
		case  2:
			return 56;
		default:
			return 44;
	}
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if (tab==0) {
		Question *v = [[Question alloc]init];
		v.qid = [[searchResults objectAtIndex:indexPath.row]objectForKey:@"questionID"];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	} else if (tab==1) {
		Answer *v = [[Answer alloc]init];
		v.aid = [[searchResults objectAtIndex:indexPath.row] objectForKey:@"answerID"];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	}
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	int shiftView = 80;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	if (delta==0) {
		table.frame = CGRectMake(0,shiftView,320,460-shiftView);
		self.view.frame = CGRectMake(0,0,320,460);
	} else {
		self.view.frame = CGRectMake(0,0-shiftView,320,460);
		table.frame = CGRectMake(0,shiftView,320,460-kb.size.height);
	}
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
}

- (void)keyboardWasHidden:(NSNotification*)note {
	[self keyboardAdjust:note:0];
}

#pragma mark -
#pragma mark UISearchBarDelegate

- (BOOL)searchString:(NSArray*)array inDict:(NSDictionary*)dict {
	BOOL found = YES;
	NSString *element;
	for (int i=0;i<[array count];i++) {
		element = [[[array objectAtIndex:i]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]lowercaseString];
		
		if ([element length]!=0) {
			NSRange r1 = [[[dict objectForKey:@"firstName"]lowercaseString]rangeOfString:element];
			
			NSRange r2 = [[[dict objectForKey:@"lastName"]lowercaseString]rangeOfString:element];
						
			NSRange r3 = [[[dict objectForKey:@"qfirstName"]lowercaseString]rangeOfString:element];
			
			NSRange r4 = [[[dict objectForKey:@"qlastName"]lowercaseString]rangeOfString:element];
			
			NSRange r5 = [[[dict objectForKey:@"email"]lowercaseString]rangeOfString:element];
			
			NSRange r6 = [[[dict objectForKey:@"question"]lowercaseString]rangeOfString:element];
						
			NSRange r7 = [[[dict objectForKey:@"aanswer"]lowercaseString]rangeOfString:element];
			
			found = found && (r1.length>0 || r2.length>0 || r3.length>0 || r4.length>0 || r5.length>0 || r6.length>0 || r7.length>0);
			
			if (!found) return NO;
		}
	}
	return found;
}

- (void)searchBar:(UISearchBar*)searchBar textDidChange:(NSString*)searchText {
	/*
	if (searchResults!=nil) [searchResults release];
	
	if ([searchText length]==0) {
		searchResults = [[NSMutableArray alloc]initWithArray:tabResults];
	} else {
		searchResults = [[NSMutableArray alloc]init];
		
		NSArray *explode = [searchText componentsSeparatedByString:@" "];
		for (int i=0;i<[tabResults count];i++) {
			NSDictionary *dict = [tabResults objectAtIndex:i];
			if ([self searchString:explode inDict:dict]) {
				[searchResults addObject:dict];
			}
		}
	}
	
	[table reloadData];
	 */
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	if (searchResults!=nil) [searchResults release];
	
	if ([searchBar.text length]==0) {
		searchResults = [[NSMutableArray alloc]initWithArray:tabResults];
	} else {
		searchResults = [[NSMutableArray alloc]init];
		
		NSArray *explode = [searchBar.text componentsSeparatedByString:@" "];
		for (int i=0;i<[tabResults count];i++) {
			NSDictionary *dict = [tabResults objectAtIndex:i];
			if ([self searchString:explode inDict:dict]) {
				[searchResults addObject:dict];
			}
		}
	}
	
	[table reloadData];
	
	[searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
	[searchBar resignFirstResponder];
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:YES animated:YES];
	[table setAllowsSelection:NO];
	[table setScrollEnabled:NO];
	return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:NO animated:YES];
	[table setAllowsSelection:YES];
	[table setScrollEnabled:YES];
	return YES;
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Session Error"]) {
		[self.navigationController popToRootViewControllerAnimated:YES];
	}
}

#pragma mark -
#pragma mark Initialization
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	for (UIView *v in [search subviews]) {
		if ([v conformsToProtocol:@protocol(UITextInputTraits)]) {
			@try {
				[(UITextField*)v setEnablesReturnKeyAutomatically:NO];
				[(UITextField*)v setKeyboardAppearance:UIKeyboardAppearanceAlert];
			}
			@catch (NSException *e) {
				NSLog(@"failed to change searchTextField's color and button");
			}
		}
	}
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	
	[self refresh:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	[super viewWillDisappear:animated];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}

@end
