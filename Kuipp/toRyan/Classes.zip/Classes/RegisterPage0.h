//
//  RegisterPage0.h
//  Kuipp
//
//  Created by Brandon Jue on 4/23/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Facebook.h"

@interface RegisterPage0 : UIViewController <FBSessionDelegate,FBRequestDelegate,UITableViewDelegate,UITableViewDataSource> {
	IBOutlet UITableView *table;
	
	Facebook *facebook;
}

- (void)back;
- (void)facebookAccount;
- (void)kuippAccount;

@end
