//
//  Map.h
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface Map : UIViewController <MKMapViewDelegate,CLLocationManagerDelegate,UIAlertViewDelegate> {
	NSMutableArray *dicts;
	NSMutableArray *heads;
	
	NSMutableArray *questions;
	int uid;
	
	IBOutlet MKMapView *map;
	IBOutlet UIControl *pinLeft;
	IBOutlet UIControl *pinRight;
	
	CLLocationManager *manager;
	CLLocation *userLoc;
	
	UIAlertView *alert;
	UIAlertView *rootAlert;
}

- (IBAction)popBack:(UIButton*)sender;
- (IBAction)refresh:(UIButton*)sender;
- (void)refresh;
- (void)splitData;

@end
