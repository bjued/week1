//
//  QuestionHeader.h
//  Kuipp
//
//  Created by Brandon Jue on 1/31/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuestionHeader : UITableViewCell {
	IBOutlet UIImageView *pic;
	IBOutlet UILabel *qOwner;
	IBOutlet UILabel *qQuestion;
	IBOutlet UILabel *qClass;
	IBOutlet UILabel *qTime;
	IBOutlet UIButton *flag;
	IBOutlet UIButton *catButton;
	IBOutlet UILabel *categoryKeyword;
}
@property(nonatomic,retain) UIButton *catButton;
@property(nonatomic,retain) UIImageView *pic;
@property(nonatomic,retain) UILabel *qOwner;
@property(nonatomic,retain) UILabel *qQuestion;
@property(nonatomic,retain) UILabel *qClass;
@property(nonatomic,retain) UILabel *qTime;
@property(nonatomic,retain) IBOutlet UIButton *flag;
@property(nonatomic,retain) IBOutlet UILabel *categoryKeyword;

@end
