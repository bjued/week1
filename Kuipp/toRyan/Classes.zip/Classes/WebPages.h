//
//  WebPages.h
//  Kuipp
//
//  Created by Brandon Jue on 4/24/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebPages : UIViewController <UIWebViewDelegate> {
	NSString *url;
	IBOutlet UIWebView *web;
}

@property(nonatomic,retain) NSString *url;
- (void)back;

@end
