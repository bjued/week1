//
//  FullCell.h
//  Kuipp
//
//  Created by Brandon Jue on 3/12/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FullCell : UITableViewCell {
	BOOL selectable;
	
	id item;
	id bott;
}

@property(nonatomic,assign) BOOL selectable;
@property(nonatomic,retain) id item,bott;

@end
