//
//  MapSelect.h
//  Kuipp
//
//  Created by Brandon Jue on 3/8/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface MapSelect : UIViewController <MKMapViewDelegate,UIGestureRecognizerDelegate> {
	IBOutlet MKMapView *map;
	
	IBOutlet UILabel *text;
	
	CLLocation *userLoc;
	BOOL refresh;
	int locTry;
	CLLocationCoordinate2D pickLoc;
	double span;
}

- (void)hide;
- (IBAction)refresh:(UIButton*)sender;
- (void)refresh;
- (void)reloadMap;
- (void)singleTap:(UITapGestureRecognizer *)tap;
- (IBAction)useCurrent:(UIButton*)sender;
- (IBAction)useAnother:(UIButton*)sender;

@end

