//
//  MapSelect.m
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "MapSelect.h"
#import "AskTab.h"
#import "Pin.h"

@implementation MapSelect

- (void)hide {
	self.navigationItem.leftBarButtonItem = nil;
	
	map.hidden = YES;
}

- (IBAction)refresh:(UIButton*)sender {
	map.hidden = YES;
	[self refresh];
}

- (void)refresh {
	[self reloadMap];
}

- (void)reloadMap {
	[Misc centerMapView:map onLoc:pickLoc withSpan:userLoc==nil?180:.01];
	
	[map removeAnnotations:[map annotations]];
	
	Pin *point= [[Pin alloc]init];
	[point setCoordinate:pickLoc];
	[point setTitle:@"What do you want to know?"];
	[map addAnnotation:point];
	[point release];
	
	map.hidden = NO;
}

- (void)singleTap:(UITapGestureRecognizer*)tap {
	if (tap.state == UIGestureRecognizerStateEnded) {
		CGPoint pt = [tap locationInView:map];
		CLLocationCoordinate2D coord = [map convertPoint:pt toCoordinateFromView:map];
		pickLoc = CLLocationCoordinate2DMake(coord.latitude,coord.longitude);
		[self reloadMap];
	}
}

- (IBAction)useCurrent:(UIButton*)sender {
}

- (void)currentFound {
	AskTab *v = [[AskTab alloc]init];
	v.coord = userLoc.coordinate;
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)useAnother:(UIButton*)sender {
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(hide) forControlEvents:UIControlEventTouchUpInside];
	
	map.hidden = NO;
	span = userLoc==nil?180:.01;
	pickLoc = userLoc.coordinate;
	
	[self reloadMap];
}

#pragma mark -
#pragma mark MKMapViewDelegate

- (void)mapView:(MKMapView*)mapView didAddAnnotationViews:(NSArray*)views{[mapView selectAnnotation:[[mapView annotations]objectAtIndex:0]animated:NO];}

- (MKAnnotationView*)mapView:(MKMapView*)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
	MKAnnotationView *pin = nil;
	pin = [map dequeueReusableAnnotationViewWithIdentifier:@"A"];
	if (!pin) pin = [[[MKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:@"A"]autorelease];
	
	pin.canShowCallout = YES;
	
	//pin.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
	pin.rightCalloutAccessoryView = [Misc rightPin:@"map detail"];
	pin.rightCalloutAccessoryView.tag = 2;
	
	pin.image = [UIImage imageNamed:@"map Ask"];
	
	return pin;
}

- (void)mapView:(MKMapView*)mapView annotationView:(MKAnnotationView*)annotationView calloutAccessoryControlTapped:(UIControl*)control {
	if (control.tag==2) {
		AskTab *v = [[AskTab alloc]init];
		v.coord = pickLoc;
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	}
}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	UIGestureRecognizer *rec = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(singleTap:)];
	[(UITapGestureRecognizer*)rec setNumberOfTapsRequired:1];
	[rec setDelaysTouchesBegan:NO];
	[map addGestureRecognizer:rec];
	rec.delegate = self;
	[rec release];
	
	[Misc load:self];
	self.navigationItem.leftBarButtonItem = nil;
	text.textColor = [Misc kuippOrangeColor];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	userLoc = [((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).userLoc retain];
	pickLoc = userLoc.coordinate;
	
	[self refresh:nil];
	
	[Misc firstTime:@"Ask Tab"];
}

- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:YES];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	map.delegate = nil;
	
    [super dealloc];
}

@end
