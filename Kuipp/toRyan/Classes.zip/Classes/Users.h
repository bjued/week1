//
//  Users.h
//  Kuipp
//
//  Created by Brandon Jue on 12/26/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Users : UIViewController <UISearchBarDelegate,UIAlertViewDelegate> {
	NSMutableArray *dicts;
	NSMutableArray *heads;
	
	IBOutlet UISearchBar *search;
	
	IBOutlet UITableView *table;
	
	NSMutableArray *searchResults;
	
	BOOL viewMoved;
}

- (IBAction)popBack:(id)sender;
- (IBAction)refresh:(id)sender;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;
- (BOOL)searchString:(NSArray*)array inDict:(NSDictionary*)dict;

@end
