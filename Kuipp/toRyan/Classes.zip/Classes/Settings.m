//
//  Settings.m
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "Settings.h"
#import "SettingsConnect.h"
#import "InviteFriends.h"
#import "WebPages.h"
#import "FullCell.h"
#import "TopCell.h"
#import "MidCell.h"
#import "BotCell.h"

@implementation Settings

@synthesize findFriends;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)refresh {
	NSUserDefaults *save = [NSUserDefaults standardUserDefaults];
	
	[settings release];
	settings = [[NSMutableArray alloc]init];
	
	while ([settings count]<4) [settings addObject:[NSMutableArray array]];
	// Top Card
	[[settings objectAtIndex:0]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[Misc first:[save objectForKey:@"firstName"] lastName:[save objectForKey:@"lastName"]otherText:@" Settings"],@"p",[NSString stringWithFormat:@"Kuipp %@",[[NSBundle mainBundle]objectForInfoDictionaryKey:@"CFBundleShortVersionString"]],@"s",@"1",@"!s",nil]];
	// Location & Time, Find Connections, Notifications
	[[settings objectAtIndex:1]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Preferences",@"p",@"0",@"o",nil]];
	[[settings objectAtIndex:1]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Connections",@"p",@"0",@"o",nil]];
	[[settings objectAtIndex:1]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Notifications",@"p",@"0",@"o",nil]];
	// Terms of Service, Privacy Policy
	[[settings objectAtIndex:2]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Terms of Service",@"p",@"0",@"o",nil]];
	[[settings objectAtIndex:2]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Privacy Policy",@"p",@"0",@"o",nil]];
	// Change Password, Logout
	[[settings objectAtIndex:3]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Change Password",@"p",@"0",@"o",nil]];
	[[settings objectAtIndex:3]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Logout",@"p",nil]];
	
	[locationTime release];
	locationTime = [[NSMutableArray alloc]init];
	
	NSDictionary *n = [[NSDictionary alloc]initWithDictionary:[save dictionaryForKey:@"locationTime"]copyItems:YES];
	[locationTime addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Define...",@"p",@"1",@"!s",@"1",@"i",nil]];
	[locationTime addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Local Question",@"p",@"1",@"!s",@"2",@"i",@"local",@"k",@"0",@"c",[n objectForKey:@"local"],@"t",nil]];
	[locationTime addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Yelp Results",@"p",@"1",@"!s",@"2",@"i",@"local",@"k",@"0",@"c",[n objectForKey:@"local"],@"t",nil]];
	[n release];
	
	[findConnections release];
	findConnections = [[NSMutableArray alloc]init];
	
	n = [[NSDictionary alloc]initWithDictionary:[save dictionaryForKey:@"findConnections"]copyItems:YES];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Find friends through...",@"p",@"1",@"!s",@"1",@"i",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Address Book",@"p",@"settings addressbook",@"m",@"2",@"i",@"0",@"o",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Facebook",@"p",@"settings facebook",@"m",@"2",@"i",@"0",@"o",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Twitter",@"p",@"settings twitter",@"m",@"2",@"i",@"0",@"o",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"First & Last Name",@"p",@"settings user",@"m",@"2",@"i",@"0",@"o",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Email Address",@"p",@"settings email",@"m",@"2",@"i",@"0",@"o",nil]];
	//[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Additional connection settings...",@"p",@"1",@"!s",@"1",@"i",nil]];
	//[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Forward my inbox to my email",@"p",@"2",@"i",@"forward",@"k",[n objectForKey:@"forward"],@"c",nil]];
	//[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Allow others to find me",@"p",@"2",@"i",@"visible",@"k",[n objectForKey:@"visible"],@"c",nil]];
	[n release];
	
	[notifications release];
	notifications = [[NSMutableArray alloc]init];
	
	n = [[NSDictionary alloc]initWithDictionary:[save dictionaryForKey:@"notifications"]copyItems:YES];
	// A=Answer, Q=Question, C=Comment, M=Message, I=Interests, F=Follow
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Send notifications when someone...",@"p",@"1",@"!s",@"1",@"i",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Answers my question",@"p",@"2",@"i",@"AMyQ",@"k",[n objectForKey:@"AMyQ"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Answers a question I am following",@"p",@"2",@"i",@"AFQ",@"k",[n objectForKey:@"AFQ"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Comments my answer",@"p",@"2",@"i",@"CMyA",@"k",[n objectForKey:@"CMyA"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Follows me",@"p",@"2",@"i",@"FMe",@"k",[n objectForKey:@"FMe"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Messages me",@"p",@"2",@"i",@"MMe",@"k",[n objectForKey:@"MMe"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Asks a question about my interests",@"p",@"2",@"i",@"QMyI",@"k",[n objectForKey:@"QMyI"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Asks a question around me",@"p",@"2",@"i",@"QAMe",@"k",[n objectForKey:@"QAMe"],@"c",nil]];
	//[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Asks a question related to my tracked ones",@"p",@"2",@"i",@"QFQ",@"k",[n objectForKey:@"QFQ"],@"c",nil]];
	//[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Provides me an achievement opportunity",@"p",@"2",@"i",@"Rmnd",@"k",[n objectForKey:@"Rmnd"],@"c",nil]];
	[n release];
	
	[table reloadData];
	[self settingsChanged:NO];
}

- (IBAction)saveSettings:(UIBarButtonItem*)sender {
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = NO;
	
	NSString *keys = @"";
	NSString *vals = @"";
	
	for (NSDictionary *d in locationTime) if ([d objectForKey:@"k"]!=nil) {
		keys = [keys stringByAppendingFormat:@",%@",[d objectForKey:@"k"]];
		vals = [vals stringByAppendingFormat:@",%@",[d objectForKey:@"t"]==nil?@"2":[d objectForKey:@"t"]];
	}
	for (NSDictionary *d in findConnections) if ([d objectForKey:@"k"]!=nil) {
		keys = [keys stringByAppendingFormat:@",%@",[d objectForKey:@"k"]];
		vals = [vals stringByAppendingFormat:@",%d",[d objectForKey:@"c"]==nil?0:1];
	}
	for (NSDictionary *d in notifications) if ([d objectForKey:@"k"]!=nil) {
		keys = [keys stringByAppendingFormat:@",%@",[d objectForKey:@"k"]];
		vals = [vals stringByAppendingFormat:@",%d",[d objectForKey:@"c"]==nil?0:[[d objectForKey:@"c"]intValue]];
	}
	if ([keys length]>0) {
		keys = [keys substringFromIndex:1];
		vals = [vals substringFromIndex:1];
	}
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&userID=0&keys=%@&vals=%@",
							[keys urlEncode],
							[vals urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"updateSettings" WithPost:poststring AndResponse:&response AndError:&error];
	
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	NSMutableArray *toSave = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:toSave];
	[parse parseXML:[urlContents substringFromIndex:2]];
	[parse release];
	
	[Misc updateUserSettings:[toSave objectAtIndex:0]];
	
	[toSave release];
	
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Settings Changed"
						  message:@"Your settings have been changed successfully!"
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
	[self settingsChanged:NO];
}

- (void)settingsChanged:(BOOL)itDid {
	[(UIButton*)self.navigationItem.rightBarButtonItem.customView setUserInteractionEnabled:itDid];
	
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:itDid?@"Cancel":@"Back"];
	[(UIButton*)self.navigationItem.leftBarButtonItem.customView addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
}

- (void)changePassword {
	NSString *msg = @"";
	if ([oldpwd.text length]==0) msg = @"You need to input your old password!";
	if ([newpwd.text length]==0) msg = @"You need to input a new password!";
	if (![newpwd.text isEqualToString:confirm.text]) msg = @"Your passwords don't match!";	
	if (![msg isEqualToString:@""]) {
		NSLog(@"%@ - %@",@"Oops!",msg);
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Oops!"
							  message:msg
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=0&pwd=%@&npw=%@",
							[oldpwd.text urlEncode],
							[newpwd.text urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"updatePassword" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Success"
						  message:@"Your password was changed!"
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
	
	[table reloadData];
}

- (void)cancelKB:(UIBarButtonItem*)sender {
	[local resignFirstResponder];
	[oldpwd resignFirstResponder];
	[newpwd resignFirstResponder];
	[confirm resignFirstResponder];
	[twitter resignFirstResponder];
}

- (void)inviteFriendsPage:(int)i withToken:(NSString*)s {
	InviteFriends *v = [[InviteFriends alloc]init];
	v.at = s;
	v.tab = i;
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (void)inviteFacebook {[self inviteFriendsPage:1 withToken:facebook.accessToken];}

- (void)inviteTwitter {[self inviteFriendsPage:2 withToken:nil];}

- (void)inputTwitter {[twitter becomeFirstResponder];}

- (void)submitTwitter {
	NSString *msg = @"";
	if ([twitter.text length]==0) msg = @"You forgot to input your Twitter screen name!";
	
	if (![msg isEqualToString:@""]) {
		NSLog(@"%@ - %@",@"Oops!",msg);
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Oops!"
							  message:msg
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
	
	[[NSUserDefaults standardUserDefaults]setObject:twitter.text forKey:@"twitterSN"];
	[twitter resignFirstResponder];
	[self inviteTwitter];
}

- (void)yelpPicked:(UIButton*)sender {
	[[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%d",sender.tag] forKey:@"YelpResults"];
	
	[sender setHighlighted:YES];
	
	[table reloadData];
}

- (IBAction)numberPadButtonPressed:(UIBarButtonItem*)sender {
	UITextField *t;
	if (local.editing) t=local;
	else t=recent;
	
	switch (sender.tag) {
		case 10:
			t.text = [t.text stringByAppendingString:@"."];
			period.enabled = NO;break;
		default:
			t.text = [t.text stringByAppendingString:[NSString stringWithFormat:@"%d",sender.tag]];break;
	}
}

- (IBAction)numberPadDonePressed:(UIBarButtonItem*)sender {
	UITextField *t;
	int i;
	if (local.editing) {
		t=local;i=1;
	} else {
		t=recent;i=2;
	}
	
	t.text = [t.text length]==0?[[locationTime objectAtIndex:i]objectForKey:@"t"]:[NSString stringWithFormat:@"%.2f",[t.text doubleValue]];
	[[locationTime objectAtIndex:i]setObject:t.text forKey:@"t"];
	[self settingsChanged:YES];
	[t resignFirstResponder];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return [settings count];}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return [[settings objectAtIndex:section]count];}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {return [self settingTableCell:indexPath];}

- (UITableViewCell*)settingTableCell:(NSIndexPath*)indexPath {
	NSArray *a = [settings objectAtIndex:indexPath.section];
	NSDictionary *d = [a objectAtIndex:indexPath.row];
	GroupCell *c;
	
	if (indexPath.section==0) {
		FullCell *c = (FullCell*)[table dequeueReusableCellWithIdentifier:@"F"];
		if (!c) c = [[[FullCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"F"]autorelease];
		
		UILabel *l = [[UILabel alloc]init];
		l.backgroundColor = [UIColor clearColor];
		l.textColor = [UIColor darkGrayColor];
		l.font = [UIFont systemFontOfSize:[Misc profileNameSize]];
		l.textAlignment = UITextAlignmentLeft;
		l.text = [d objectForKey:@"p"];
		c.item = l;
		[c.contentView addSubview:c.item];
		[l release];
		
		NSString *s = [d objectForKey:@"s"];
		if (s) {
			l = [[UILabel alloc]init];
			l.backgroundColor = [UIColor clearColor];
			l.textColor = [UIColor grayColor];
			l.font = [UIFont systemFontOfSize:[Misc mainSize]];
			l.textAlignment = UITextAlignmentRight;
			l.text = s;
			c.bott = l;
			[c.contentView addSubview:c.bott];
			[l release];
		}
		return c;
	} else if (indexPath.row==0) {
		c = (TopCell*)[table dequeueReusableCellWithIdentifier:@"A"];
		if (!c) c = [[[TopCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"A"]autorelease];
	} else if (indexPath.row==[a count]-1) {
		c = (BotCell*)[table dequeueReusableCellWithIdentifier:@"B"];
		if (!c) c = [[[BotCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"B"]autorelease];
	} else {
		c = (MidCell*)[table dequeueReusableCellWithIdentifier:@"C"];
		if (!c) c = [[[MidCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"C"]autorelease];
	}
	
	// Get rid of old stuff
	for (id v in [c.contentView subviews]) {
		if ([v isKindOfClass:[UITextField class]]||
			([v isKindOfClass:[UILabel class]]&&((UILabel*)v).tag!=0)) {
			[v removeFromSuperview];
		}
	}
	// Put in new stuff
	NSString *p = [d objectForKey:@"p"];
	c.label.text = p;
	if ([p isEqualToString:@"Local Question"]) {
		NSString *t = [d objectForKey:@"t"];
		[local release];
		local = [[Misc cellTextField:self]retain];
		local.text = [NSString stringWithFormat:@"%.2f",t==nil?0:[t doubleValue]];
		local.inputView = input;
		local.tag = indexPath.row;
		[c.contentView addSubview:local];
		UILabel *l = [[UILabel alloc]initWithFrame:CGRectMake(local.frame.origin.x+local.frame.size.width+4,local.frame.origin.y,40,local.frame.size.height)];
		l.text = @"miles";
		l.font = [l.font fontWithSize:12];
		l.tag = 1;
		[c.contentView addSubview:l];
		[l release];
	} else if ([p isEqualToString:@"Yelp Results"]) {
		double buf = [Misc buffer];
		
		int vx = 110;
		int vy = 1;
		int vw = (c.contentView.frame.size.width - vx)/5;
		int vh = 33;
		
		NSString *yelp = [[NSUserDefaults standardUserDefaults]objectForKey:@"YelpResults"];
		int yp = 0;
		if (yelp) yp = [yelp intValue];
		
		UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		button.frame = CGRectMake(vx, vy, vw-buf, vh);
		[button setTitle:@"1" forState:UIControlStateNormal];
		[button setTitleColor:[Misc kuippOrangeColor] forState:UIControlStateNormal];
		[button addTarget:self action:@selector(yelpPicked:) forControlEvents:UIControlEventTouchUpInside];
		button.tag = 1;
		[c.contentView addSubview:button];
		if (yp==1) [button setHighlighted:YES];
		
		vx += vw;
		button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		button.frame = CGRectMake(vx, vy, vw-buf, vh);
		[button setTitle:@"2" forState:UIControlStateNormal];
		[button setTitleColor:[Misc kuippOrangeColor] forState:UIControlStateNormal];
		[button addTarget:self action:@selector(yelpPicked:) forControlEvents:UIControlEventTouchUpInside];
		button.tag = 2;
		[c.contentView addSubview:button];
		if (yp==2) [button setHighlighted:YES];
		
		vx += vw;
		button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		button.frame = CGRectMake(vx, vy, vw-buf, vh);
		[button setTitle:@"3" forState:UIControlStateNormal];
		[button setTitleColor:[Misc kuippOrangeColor] forState:UIControlStateNormal];
		[button addTarget:self action:@selector(yelpPicked:) forControlEvents:UIControlEventTouchUpInside];
		button.tag = 3;
		[c.contentView addSubview:button];
		if (yp==3) [button setHighlighted:YES];
		
		vx += vw;
		button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		button.frame = CGRectMake(vx, vy, vw-buf, vh);
		[button setTitle:@"4" forState:UIControlStateNormal];
		[button setTitleColor:[Misc kuippOrangeColor] forState:UIControlStateNormal];
		[button addTarget:self action:@selector(yelpPicked:) forControlEvents:UIControlEventTouchUpInside];
		button.tag = 4;
		[c.contentView addSubview:button];
		if (yp==4) [button setHighlighted:YES];
		
		vx += vw;
		button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		button.frame = CGRectMake(vx, vy, vw-buf, vh);
		[button setTitle:@"5" forState:UIControlStateNormal];
		[button setTitleColor:[Misc kuippOrangeColor] forState:UIControlStateNormal];
		[button addTarget:self action:@selector(yelpPicked:) forControlEvents:UIControlEventTouchUpInside];
		button.tag = 5;
		[c.contentView addSubview:button];
		if (yp==5) [button setHighlighted:YES];
	} else if ([p isEqualToString:@"Old Password"]) {
		c.label.text = @"";
		[oldpwd release];
		oldpwd = [[Misc cellPasswordField:self]retain];
		oldpwd.placeholder = p;
		oldpwd.tag = indexPath.row;
		[c.contentView addSubview:oldpwd];
	} else if ([p isEqualToString:@"New Password"]) {
		c.label.text = @"";
		[newpwd release];
		newpwd = [[Misc cellPasswordField:self]retain];
		newpwd.placeholder = p;
		newpwd.tag = indexPath.row;
		[c.contentView addSubview:newpwd];
	} else if ([p isEqualToString:@"Confirm Password"]) {
		c.label.text = @"";
		[confirm release];
		confirm = [[Misc cellPasswordField:self]retain];
		confirm.placeholder = p;
		confirm.tag = indexPath.row;
		confirm.returnKeyType = UIReturnKeySend;
		[c.contentView addSubview:confirm];
	}
	NSString *k = [d objectForKey:@"c"];
	NSString *m = [d objectForKey:@"m"];
	c.imageView.image = m?[UIImage imageNamed:m]:(k?([k intValue]==1?[[Misc checkmark]image]:[[Misc checkmarkPlaceholder]image]):nil);
	NSString *o = [d objectForKey:@"o"];
	c.accessoryView = (!o?nil:([o intValue]==0?[Misc detailDisclosure]:[Misc detailExpanded]));
	NSString *i = [d objectForKey:@"i"];
	c.label.font = [c.textLabel.font fontWithSize:17-(!i?0:1+[i intValue]*2)];
	c.selectable = ![d objectForKey:@"!s"]?YES:NO;
	c.selectionStyle = UITableViewCellSelectionStyleNone;
	
	return c;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {return indexPath.section==0?60:((indexPath.row==0||indexPath.row==[[settings objectAtIndex:indexPath.section]count]-1)?40:40-[Misc buffer]);}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	
	NSMutableArray *a = [settings objectAtIndex:indexPath.section];
	NSMutableDictionary *d = [a objectAtIndex:indexPath.row];
	NSString *p = [d objectForKey:@"p"];
	if (![d objectForKey:@"!s"]) switch (indexPath.section) {
		case  1: if ([p isEqualToString:@"Preferences"]) {
			NSIndexSet *is = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(indexPath.row+1,[locationTime count])];
			
			NSMutableArray *ips = [[NSMutableArray alloc]init];
			for (int i=0;i<[locationTime count];i++) [ips addObject:[NSIndexPath indexPathForRow:indexPath.row+1+i inSection:indexPath.section]];
			
			[tableView beginUpdates];
			if ([[d objectForKey:@"o"]intValue]==0) { // was Closed
				[a insertObjects:locationTime atIndexes:is];
				[d setObject:@"1" forKey:@"o"];
				[tableView insertRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
			} else { // was Open
				[a removeObjectsAtIndexes:is];
				[d setObject:@"0" forKey:@"o"];
				[tableView deleteRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
			}
			[ips release];
			[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationNone];
			[tableView endUpdates];
		} else if ([p isEqualToString:@"Connections"]) {
			NSIndexSet *is = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(indexPath.row+1,[findConnections count])];
			
			NSMutableArray *ips = [[NSMutableArray alloc]init];
			for (int i=0;i<[findConnections count];i++) [ips addObject:[NSIndexPath indexPathForRow:indexPath.row+1+i inSection:indexPath.section]];
			
			[tableView beginUpdates];
			if ([[d objectForKey:@"o"]intValue]==0) { // was Closed
				[a insertObjects:findConnections atIndexes:is];
				[d setObject:@"1" forKey:@"o"];
				[tableView insertRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
			} else { // was Open
				[a removeObjectsAtIndexes:is];
				[d setObject:@"0" forKey:@"o"];
				[tableView deleteRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
			}
			[ips release];
			[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationNone];
			[tableView endUpdates];
		} else if ([p isEqualToString:@"Notifications"]) {
			NSIndexSet *is = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(indexPath.row+1,[notifications count])];
			
			NSMutableArray *ips = [[NSMutableArray alloc]init];
			for (int i=0;i<[notifications count];i++) [ips addObject:[NSIndexPath indexPathForRow:indexPath.row+1+i inSection:indexPath.section]];
			
			[tableView beginUpdates];
			if ([[d objectForKey:@"o"]intValue]==0) { // was Closed
				[a insertObjects:notifications atIndexes:is];
				[d setObject:@"1" forKey:@"o"];
				[tableView insertRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
			} else { // was Open
				[a removeObjectsAtIndexes:is];
				[d setObject:@"0" forKey:@"o"];
				[tableView deleteRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
			}
			[ips release];
			[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationFade];
			[tableView endUpdates];
		} else if ([p isEqualToString:@"Facebook"]) {
			facebook = ((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).facebook;
			if (facebook&&[facebook.expirationDate timeIntervalSinceNow]>0) {
				[self inviteFacebook];
			} else {
				NSArray *permissions = [[Misc facebookPermissions]retain];
				
				[facebook authorize:permissions delegate:self];
				
				[permissions release];
			}
		} else if ([p isEqualToString:@"Twitter"]) {
			NSString *tid = [[NSUserDefaults standardUserDefaults]objectForKey:@"twitterID"];
			if ([tid intValue]!=0) [self inviteTwitter];
			else [self inputTwitter];
		} else if ([p isEqualToString:@"Address Book"]) {
			[self inviteFriendsPage:0 withToken:nil];
		} else if ([p isEqualToString:@"Email Address"]) {
			[self inviteFriendsPage:4 withToken:nil];
		} else if ([p isEqualToString:@"First & Last Name"]) {
			[self inviteFriendsPage:3 withToken:nil];
		} else { // Checkmark Stuff
			if ([[d objectForKey:@"c"]intValue]==0) [d setObject:@"1" forKey:@"c"];
			else [d setObject:@"0" forKey:@"c"];
			[self settingsChanged:YES];
			[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationFade];
		} break;
		case  2: switch (indexPath.row) {
			case  0: { //Terms of Service
				WebPages *w = [[WebPages alloc]init];
				w.url = @"http://kuipp.com/terms.php";
				[self.navigationController pushViewController:w animated:YES];
				[w release];
				break;
			} case  1: { //Privacy Policy
				WebPages *w = [[WebPages alloc]init];
				w.url = @"http://kuipp.com/policy.php";
				[self.navigationController pushViewController:w animated:YES];
				[w release];
				break;
			} default: break;
		}
		case  3: if ([p isEqualToString:@"Change Password"]) {
			NSMutableArray *ips = [[NSMutableArray alloc]init];
			for (int i=0;i<3;i++) [ips addObject:[NSIndexPath indexPathForRow:indexPath.row+1+i inSection:indexPath.section]];
			
			[tableView beginUpdates];
			if ([[d objectForKey:@"o"]intValue]==0) { // was Closed
				[a insertObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Old Password",@"p",@"1",@"!s",@"1",@"i",nil]atIndex:indexPath.row+1];
				[a insertObject:[NSDictionary dictionaryWithObjectsAndKeys:@"New Password",@"p",@"1",@"!s",@"1",@"i",nil]atIndex:indexPath.row+2];
				[a insertObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Confirm Password",@"p",@"1",@"!s",@"1",@"i",nil]atIndex:indexPath.row+3];
				[d setObject:@"1" forKey:@"o"];
				[tableView insertRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
			} else { // was Open
				[a removeObjectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(indexPath.row+1,3)]];
				[d setObject:@"0" forKey:@"o"];
				[tableView deleteRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
			}
			[ips release];
			[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationNone];
			[tableView endUpdates];
		} else if ([p isEqualToString:@"Logout"]) {
			NSUserDefaults *save = [NSUserDefaults standardUserDefaults];
			[save setObject:@"0" forKey:@"sessionID"];
			[(KuippAppDelegate*)[UIApplication sharedApplication].delegate toLogin];
		} break;
		default: break;
	}
}

#pragma mark -
#pragma mark FBSessionDelegate

- (void)fbDidLogin {[self inviteFacebook];}

- (void)fbDidNotLogin:(BOOL)cancelled {NSLog(@"Failed to log into facebook. User canceled? %@",cancelled?@"YES":@"NO");}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	UIView *top;
	
	if (twitter.editing) top = twitterView;
	else top = nil;
	
	[self.view bringSubviewToFront:top];
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	top.frame = CGRectMake(top.frame.origin.x,-1*top.frame.size.height/2+delta*top.frame.size.height/2,top.frame.size.width,top.frame.size.height);
	bot.frame = CGRectMake(bot.frame.origin.x,self.view.frame.size.height+bot.frame.size.height/2-delta*bot.frame.size.height/2,bot.frame.size.width,bot.frame.size.height);
	table.frame = CGRectMake(0,table.frame.origin.y,table.frame.size.width,table.frame.size.height-delta*(kb.size.height-49));
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	
	self.navigationItem.leftBarButtonItem = nil;
	self.navigationItem.rightBarButtonItem = nil;
	
	if (twitter.editing) {
		self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Cancel"];
		UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
		[b addTarget:self action:@selector(cancelKB:) forControlEvents:UIControlEventTouchUpInside];
	}
	if (local.editing||recent.editing) {
		int tag;
		if (local.editing) tag=local.tag;
		else tag=recent.tag;
		[table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:tag inSection:1]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
	}
	if (oldpwd.editing||newpwd.editing||confirm.editing) {
		int tag;
		if (oldpwd.editing) tag=oldpwd.tag;
		else if (newpwd.editing) tag=newpwd.tag;
		else tag=confirm.tag;
		[table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:tag inSection:3]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
		
		self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Cancel"];
		UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
		[b addTarget:self action:@selector(cancelKB:) forControlEvents:UIControlEventTouchUpInside];
	}
}

- (void)keyboardWasHidden:(NSNotification*)note {
	[self keyboardAdjust:note:-1];
	
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Save"];
	b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(saveSettings:) forControlEvents:UIControlEventTouchUpInside];
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	if (textField==oldpwd) {
		[newpwd becomeFirstResponder];
		return NO;
	}
	if (textField==newpwd) {
		[confirm becomeFirstResponder];
		return NO;
	}
	if (textField==confirm) [self changePassword];
	if (textField==twitter) [self submitTwitter];
	[textField resignFirstResponder];
	return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
	if (textField==local||textField==recent) period.enabled = YES;
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
	if (textField==local||textField==recent) period.enabled = YES;
}

#pragma mark -
#pragma mark Initialization

- (void)viewDidLoad {
	[super viewDidLoad];
	
	[Misc load:self];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Save"];
	UIButton *b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(saveSettings:) forControlEvents:UIControlEventTouchUpInside];
	[b setUserInteractionEnabled:NO];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	
	[self refresh];
	
	if (findFriends) {
		findFriends = NO;
		[self tableView:table didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:1]];
		[table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:1]atScrollPosition:UITableViewScrollPositionTop animated:YES];
	}
	
	[Misc firstTime:@"Settings"];
}

- (void)viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return [Misc orientations:interfaceOrientation];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	table.delegate = nil;
	table.dataSource = nil;
	twitter.delegate = nil;
	
    [super dealloc];
}

@end
