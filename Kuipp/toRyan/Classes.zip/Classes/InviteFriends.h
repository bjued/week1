//
//  InviteFriends.h
//  Kuipp
//
//  Created by Brandon Jue on 2/16/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InviteFriends : UIViewController <UITableViewDelegate,UIScrollViewDelegate,UISearchBarDelegate> {
	NSString *at;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableDictionary *images;
	
	RefreshCell *refreshCell;
	
	NSMutableArray *vrfy;
	NSMutableArray *poss;
	NSMutableArray *invt;
	
	NSMutableArray *friends;
	
	NSMutableArray *searchResults;
	
	int tab;
	IBOutlet UITableView *table;
	IBOutlet UISearchBar *search;
}

@property(nonatomic,retain) NSString* at;
@property(nonatomic,assign) int tab;
- (void)back;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)splitData;
- (void)combData;
- (void)sendEmails;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
