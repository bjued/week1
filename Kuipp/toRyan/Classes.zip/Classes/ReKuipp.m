//
//  ReKuipp.m
//  Kuipp
//
//  Created by Brandon Jue on 1/4/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "ReKuipp.h"
#import "QuestionCell.h"
#import "Question.h"
#import "KuippConnect.h"
#import "Parser.h"

@implementation ReKuipp

- (IBAction)popBack:(UIButton*)sender {
	[self.navigationController popToViewController:[[self.navigationController viewControllers]objectAtIndex:1] animated:YES];
}

- (IBAction)refresh:(UIButton*)sender {
	[manager startUpdatingLocation];
}

- (void)refresh {
	[manager stopUpdatingLocation];
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=0"
							@"&rct=%@"
							@"&lat=%.8f"
							@"&lon=%.8f",
							[[NSUserDefaults standardUserDefaults]objectForKey:@"recent"],
							userLoc.coordinate.latitude,
							userLoc.coordinate.longitude];
	
	NSString *urlContents = [KuippConnect formTo:@"selectQuestions" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:1]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode forView:self]) return;
	
	if (dicts!=nil) [dicts release];
	if (heads!=nil) [heads release];
	dicts = [[NSMutableArray alloc]init];
	heads = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts AndHeads:heads];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	
	[self filter];
}

- (void)splitData {
	if (questions!=nil) [questions release];
	questions = [[NSMutableArray alloc]init];
	
	for (int i=0;i<[heads count];i++) {
		if ([[heads objectAtIndex:i]isEqualToString:@"Questions"]) {
			NSMutableDictionary *dict = [dicts objectAtIndex:i];
			if (i==0) [questions addObject:dict];
			if ([[dict objectForKey:@"questionID"]intValue]==[[[questions lastObject]objectForKey:@"questionID"]intValue]) {
				if ([[dict objectForKey:@"d"]intValue]==1) [[questions lastObject]setObject:@"1" forKey:@"d"];
				else if ([[dict objectForKey:@"f"]intValue]==1) [[questions lastObject]setObject:@"1" forKey:@"f"];
				else if ([[dict objectForKey:@"k"]intValue]==1) [[questions lastObject]setObject:@"1" forKey:@"k"];
				else if ([[dict objectForKey:@"l"]intValue]==1) [[questions lastObject]setObject:@"1" forKey:@"l"];
			} else {
				[questions addObject:dict];
			}
		}
	}
}

- (void)filter {
	if (tabResults!=nil) [tabResults release];
	tabResults = [[NSMutableArray alloc]initWithArray:questions];
	
	if (followingTapped) [self reduce:1];
	if (localTapped) [self reduce:2];
	if (recommendTapped) [self reduce:4];
	if (recentTapped) [self reduce:8];
	
	[self searchBarSearchButtonClicked:search];
}

- (void)reduce:(int)n {
	NSMutableArray *old = [[NSMutableArray alloc]initWithArray:tabResults];
	
	if (tabResults!=nil) [tabResults release];
	tabResults = [[NSMutableArray alloc]init];
	
	for (int i=0;i<[old count];i++) {
		NSDictionary* dict = [old objectAtIndex:i];
		if (n==1&&[[dict objectForKey:@"f"]intValue]==1) [tabResults addObject:[old objectAtIndex:i]];
		else if (n==2&&[[dict objectForKey:@"l"]intValue]==1) [tabResults addObject:[old objectAtIndex:i]];
		else if (n==4&&[[dict objectForKey:@"k"]intValue]==1) [tabResults addObject:[old objectAtIndex:i]];
		else if (n==8&&[[dict objectForKey:@"d"]intValue]==1) [tabResults addObject:[old objectAtIndex:i]];
	}
	
	[old release];
}

- (IBAction)following:(UIButton*)sender {
	if (followingTapped) {
		followingTapped = NO;
		[followingButton setBackgroundImage:[UIImage imageNamed:@"30x80.png"] forState:UIControlStateNormal];
		[followingButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
		[self filter];
	} else {
		followingTapped = YES;
		[followingButton setBackgroundImage:[UIImage imageNamed:@"30x80tapped.png"] forState:UIControlStateNormal];
		[followingButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		
		[self reduce:1];
		
		[self searchBarSearchButtonClicked:search];
	}
}

- (IBAction)local:(UIButton*)sender {
	if (localTapped) {
		localTapped = NO;
		[localButton setBackgroundImage:[UIImage imageNamed:@"30x80.png"] forState:UIControlStateNormal];
		[localButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
		[self filter];
	} else {
		localTapped = YES;
		[localButton setBackgroundImage:[UIImage imageNamed:@"30x80tapped.png"] forState:UIControlStateNormal];
		[localButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		
		[self reduce:2];
		
		[self searchBarSearchButtonClicked:search];
	}
}

- (IBAction)recommend:(UIButton*)sender {
	if (recommendTapped) {
		recommendTapped = NO;
		[recommendButton setBackgroundImage:[UIImage imageNamed:@"30x80.png"] forState:UIControlStateNormal];
		[recommendButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
		[self filter];
	} else {
		recommendTapped = YES;
		[recommendButton setBackgroundImage:[UIImage imageNamed:@"30x80tapped.png"] forState:UIControlStateNormal];
		[recommendButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		
		[self reduce:4];
		
		[self searchBarSearchButtonClicked:search];
	}
}

- (IBAction)recent:(UIButton*)sender {
	if (recentTapped) {
		recentTapped = NO;
		[recentButton setBackgroundImage:[UIImage imageNamed:@"30x80.png"] forState:UIControlStateNormal];
		[recentButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
		[self filter];
	} else {
		recentTapped = YES;
		[recentButton setBackgroundImage:[UIImage imageNamed:@"30x80tapped.png"] forState:UIControlStateNormal];
		[recentButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		
		[self reduce:8];
		
		[self searchBarSearchButtonClicked:search];
	}
}

- (IBAction)backgroundTouched:(UIControl*)sender {
	[search resignFirstResponder];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return [searchResults count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
    // Configure the cell...
	NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
	
	// Find timeSince (choose to use year, day, hour, minute, second)
	NSString *date = [dict objectForKey:@"datetime"];
	NSTimeInterval time = [[NSDate dateWithTimeIntervalSince1970:[date intValue]]timeIntervalSinceNow] * -1;
	NSString *since = @"";
	if (((int)time)/60/60/24/365>0) {
		since = [NSString stringWithFormat:@"%d year%@ ago",((int)time)/60/60/24/365,((int)time)/60/60/24/365==1?@"":@"s"];
	} else if (((int)time)/60/60/24>0) {
		since = [NSString stringWithFormat:@"%d day%@ ago",((int)time)/60/60/24,((int)time)/60/60/24==1?@"":@"s"];
	} else if (((int)time)/60/60>0) {
		since = [NSString stringWithFormat:@"%d hour%@ ago",((int)time)/60/60,((int)time)/60/60==1?@"":@"s"];
	} else if (((int)time)/60>0) {
		since = [NSString stringWithFormat:@"%d minute%@ ago",((int)time)/60,((int)time)/60==1?@"":@"s"];
	} else {
		since = [NSString stringWithFormat:@"%d second%@ ago",((int)time),((int)time)==1?@"":@"s"];
	}
	
	QuestionCell *cell = (QuestionCell*)[tableView dequeueReusableCellWithIdentifier:@"QuestionCell"];
	if (cell==nil) {
		NSArray *top = [[NSBundle mainBundle]loadNibNamed:@"QuestionCell" owner:nil options:nil];
		for (id cur in top) {
			if ([cur isMemberOfClass:[QuestionCell class]]) {
				cell = cur;
				break;
			}
		}
	}
	
	[cell.pic setImage:[UIImage imageNamed:@"RedPin.png"]];
	
	cell.qOwner.text = [NSString stringWithFormat:@"%@ %@. asked:",[dict objectForKey:@"firstName"],[[dict objectForKey:@"lastName"]substringToIndex:1]];
	
	cell.qQuestion.text = [dict objectForKey:@"question"];
	cell.qQuestion.frame = CGRectMake(cell.qQuestion.frame.origin.x,cell.qQuestion.frame.origin.y,232,15*150);
	[cell.qQuestion sizeToFit];
	
	cell.qClass.text = [dict objectForKey:@"class"];
	
	cell.qTime.text = [NSString stringWithFormat:@"%@ | %@ answers",since,[dict objectForKey:@"numAnswers"]];
	cell.qTime.frame = CGRectMake(cell.qTime.frame.origin.x,fmax(55,cell.qQuestion.frame.origin.y+cell.qQuestion.frame.size.height),cell.qTime.frame.size.width,cell.qTime.frame.size.height);
	
	cell.frame = CGRectMake(cell.frame.origin.x,cell.frame.origin.y,cell.frame.size.width,cell.qTime.frame.origin.y+cell.qTime.frame.size.height+1);
	
	return cell;
}
/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */
/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */
/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */
/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */
#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
	
	UILabel *one = [[UILabel alloc]init];
	one.text = @"1";
	one.font = [one.font fontWithSize:12];
	[one sizeToFit];
	
	UILabel *two = [[UILabel alloc]init];
	two.text = [dict objectForKey:@"question"];
	two.font = [two.font fontWithSize:12];
	two.numberOfLines = 0;
	two.frame = CGRectMake(0,one.frame.size.height,232,15*150);
	[two sizeToFit];
	
	UILabel *three = [[UILabel alloc]init];
	three.text = @"1";
	three.font = [three.font fontWithSize:10];
	three.frame = CGRectMake(0,fmax(55,two.frame.origin.y+two.frame.size.height),13,13);
	[three sizeToFit];
	
	int ret = three.frame.origin.y+three.frame.size.height+1;
	
	[one release];
	[two release];
	[three release];
	
	return ret;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	Question *v = [[Question alloc]init];
	v.qid = [[searchResults objectAtIndex:indexPath.row]objectForKey:@"questionID"];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	int shiftView = 80;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	if (delta==0) {
		table.frame = CGRectMake(0,shiftView,320,460-shiftView);
		self.view.frame = CGRectMake(0,0,320,460);
	} else {
		self.view.frame = CGRectMake(0,0-shiftView,320,460);
		table.frame = CGRectMake(0,shiftView,320,460-kb.size.height);
	}
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
}

- (void)keyboardWasHidden:(NSNotification*)note {
	[self keyboardAdjust:note:0];
}

#pragma mark -
#pragma mark UISearchBarDelegate

- (BOOL)searchString:(NSArray*)array inDict:(NSDictionary*)dict {
	BOOL found = YES;
	NSString *element;
	for (int i=0;i<[array count];i++) {
		element = [[[array objectAtIndex:i]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]lowercaseString];
		
		if ([element length]!=0) {
			NSRange r1 = [[[dict objectForKey:@"firstName"]lowercaseString]rangeOfString:element];
			
			NSRange r2 = [[[dict objectForKey:@"lastName"]lowercaseString]rangeOfString:element];
			
			NSRange r3 = [[[dict objectForKey:@"email"]lowercaseString]rangeOfString:element];
			
			NSRange r4 = [[[dict objectForKey:@"question"]lowercaseString]rangeOfString:element];
			
			found = found && (r1.length>0 || r2.length>0 || r3.length>0 || r4.length>0);
			
			if (!found) return NO;
		}
	}
	return found;
}

- (void)searchBar:(UISearchBar*)searchBar textDidChange:(NSString*)searchText {
	/*
	if (searchResults!=nil) [searchResults release];
	
	if ([searchText length]==0) {
		searchResults = [[NSMutableArray alloc]initWithArray:tabResults];
	} else {
		searchResults = [[NSMutableArray alloc]init];
		
		NSArray *explode = [searchText componentsSeparatedByString:@" "];
		for (int i=0;i<[tabResults count];i++) {
			NSDictionary *dict = [tabResults objectAtIndex:i];
			if ([self searchString:explode inDict:dict]) {
				[searchResults addObject:dict];
			}
		}
	}
	
	[table reloadData];
	*/
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {if (searchResults!=nil) [searchResults release];
	
	if ([searchBar.text length]==0) {
		searchResults = [[NSMutableArray alloc]initWithArray:tabResults];
	} else {
		searchResults = [[NSMutableArray alloc]init];
		
		NSArray *explode = [searchBar.text componentsSeparatedByString:@" "];
		for (int i=0;i<[tabResults count];i++) {
			NSDictionary *dict = [tabResults objectAtIndex:i];
			if ([self searchString:explode inDict:dict]) {
				[searchResults addObject:dict];
			}
		}
	}
	
	[table reloadData];
	
	[searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
	[searchBar resignFirstResponder];
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:YES animated:YES];
	[table setAllowsSelection:NO];
	[table setScrollEnabled:NO];
	return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:NO animated:YES];
	[table setAllowsSelection:YES];
	[table setScrollEnabled:YES];
	return YES;
}

#pragma mark -
#pragma mark CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager*)manager didUpdateToLocation:(CLLocation*)newLocation fromLocation:(CLLocation*)oldLocation {
	userLoc = newLocation;
	[userLoc retain];
	
	[self refresh];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
	NSLog(@"%@",error);
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Session Error"]) {
		[self.navigationController popToRootViewControllerAnimated:YES];
	}
}

#pragma mark -
#pragma mark Initialization
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	for (UIView *v in [search subviews]) {
		if ([v conformsToProtocol:@protocol(UITextInputTraits)]) {
			@try {
				[(UITextField*)v setEnablesReturnKeyAutomatically:NO];
				[(UITextField*)v setKeyboardAppearance:UIKeyboardAppearanceAlert];
			}
			@catch (NSException *e) {
				NSLog(@"failed to change searchTextField's color and button");
			}
		}
	}
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	manager = [[CLLocationManager alloc]init];
	[manager setDelegate:self];
	
	tab = 0;
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	
	[self refresh:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
	
	[manager release];
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	[super viewWillDisappear:animated];
}
/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}

@end
