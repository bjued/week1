//
//  Answer.m
//  Kuipp
//
//  Created by Brandon Jue on 12/20/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "Answer.h"
#import "Profile.h"
#import "Cell.h"
#import "ButtonCell.h"
#import "Pin.h"
#import "ASyncImageLoadDelegate.h"
#import "WebPages.h"

@implementation Answer

@synthesize aid;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)mainThreadImages {
	[images release];
	images = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images retain];
	for (NSDictionary *d in dicts) {
		NSString *url = [d objectForKey:@"picture"];
		UIImage *pic = [images objectForKey:url];
		if (pic==nil||[pic isEqual:[Misc defaultProfile]]) {
			[images setObject:[Misc defaultProfile]forKey:url];
			if (![url isEqualToString:[Misc defaultProfileURL]]) {
				ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
				[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
			}
		}
	}
}

- (void)aSyncImageLoaded {[table reloadData];}

- (void)refreshAll {
	[refreshCell refreshing];
	
	NSString *p = [NSString stringWithFormat:@"&aid=%@",[aid urlEncode]];
	
	[kuipp formTo:@"selectComments" WithPost:p];
}

- (void)refresh:(id)obj {
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	[self mainThreadImages];
	
	[refreshCell refreshed];
	
	[self reloadView];
}

- (void)splitData {
	[comments release];
	comments = [[NSMutableArray alloc]init];
	
	for (int i=0;i<[dicts count];i++) {
		NSDictionary *d = [dicts objectAtIndex:i];
		NSString *s = [d objectForKey:@"head"];
		if ([s isEqualToString:@"Answers"]) answer = d;
		if ([s isEqualToString:@"Comments"]) [comments addObject:d];
	}
}

- (void)reloadView {
	if (tab==0) {
		[self reloadMap];
		[self.view sendSubviewToBack:table];
		[map setHidden:NO];
		[table setHidden:YES];
	} else {
		[self reloadTable];
		[self.view sendSubviewToBack:map];
		[map setHidden:YES];
		[table setHidden:NO];
	}
	if (top.frame.origin.y<0) {
		self.navigationItem.rightBarButtonItem = [Misc mapList:tab];
		UIButton *b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
		[b addTarget:self action:@selector(listMap:) forControlEvents:UIControlEventTouchUpInside];
	}
}

- (void)reloadMap {
	[map removeAnnotations:[map.annotations filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"!(self isKindOfClass: %@)",[MKUserLocation class]]]];
	
	Pin *point = [[Pin alloc]init];
	point.coordinate = CLLocationCoordinate2DMake([[answer objectForKey:@"latitude"]doubleValue],[[answer objectForKey:@"longitude"]doubleValue]);
	point.title = [Misc first:[answer objectForKey:@"firstName"]lastName:[answer objectForKey:@"lastName"]];
	point.subtitle = [answer objectForKey:@"answer"];
	point.dict = answer;
	[map addAnnotation:point];
	[point release];
	
	for (NSDictionary *dict in comments) {
		Pin *point = [[Pin alloc]init];
		point.coordinate = CLLocationCoordinate2DMake([[dict objectForKey:@"latitude"]doubleValue],[[dict objectForKey:@"longitude"]doubleValue]);
		point.title = [Misc first:[dict objectForKey:@"firstName"]lastName:[dict objectForKey:@"lastName"]];
		point.subtitle = [dict objectForKey:@"comment"];
		point.dict = dict;
		[map addAnnotation:point];
		[point release];
	}
	
	if (tab==0) [Misc fitMapAnnotations:map];
}

- (void)reloadTable {
	[table reloadData];
	[table setContentOffset:CGPointMake(0,table.tableHeaderView.frame.size.height) animated:[Misc tableHideHeaderAnimated]];
}

- (void)refreshCount {[count setText:[NSString stringWithFormat:@"%d",[Misc maxCharacters]-[textbox.text length]]];}

- (IBAction)addComment {
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Cancel"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(cancelComment) forControlEvents:UIControlEventTouchUpInside];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Send"];
	b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(trySend:) forControlEvents:UIControlEventTouchUpInside];
	
	[self.view bringSubviewToFront:top];
	[self.view bringSubviewToFront:bot];
	
	[textbox becomeFirstResponder];
	textbox.text = @"";
	[self refreshCount];
}

- (IBAction)cancelComment {
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Map"];
	b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(listMap:) forControlEvents:UIControlEventTouchUpInside];
	
	[textbox resignFirstResponder];
}

- (IBAction)trySend:(UIButton*)sender {
	if ([textbox.text length]==0) {
		NSLog(@"There isn't a Comment to send.");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Oops!"
				 message:@"There isn't a comment to send."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else {
		[(UIButton*)self.navigationItem.rightBarButtonItem.customView setUserInteractionEnabled:NO];
		submitLike = NO;
		[self send];
	}
}

- (void)send {
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&aid=%@&uid=0&com=%@&lat=%.8f&lon=%.8f&loc=%@",
							[aid urlEncode],
							[textbox.text urlEncode],
							del.userLoc.coordinate.latitude,
							del.userLoc.coordinate.longitude,
							[[Misc reverseGeocode:del.userPlace]urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"insertComment" WithPost:poststring AndResponse:&response AndError:&error];
	
	[(UIButton*)self.navigationItem.rightBarButtonItem.customView setUserInteractionEnabled:YES];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	if (![kuipp fetchingData]) [self refreshAll];
	[self cancelComment];
}

- (IBAction)listMap:(UIButton*)sender {
	if (tab==1) tab=0; // Was List going to Map
	else tab=1; // Was Map going to List
	
	[self reloadView];
}

- (void)toProfile:(UIControl*)sender {
	switch (sender.tag) {
		case  500: {
			WebPages *v = [[WebPages alloc]init];
			v.url = @"http://lite.yelp.com";
			[self.navigationController pushViewController:v animated:YES];
			[v release];
			break;	
		}
		default: {
			Profile *v = [[Profile alloc]init];
			v.uid = [NSString stringWithFormat:@"%d",sender.tag];
			[self.navigationController pushViewController:v animated:YES];
			[v release];
			break;
		}
	}
}

- (IBAction)likeIt:(UIButton*)sender {
	check = YES;
	submitLike = YES;
	
	bar.userInteractionEnabled = NO;
	
	[self likeDislike];
}

- (IBAction)dislikeIt:(UIButton*)sender {
	check = NO;
	submitLike = YES;
	
	bar.userInteractionEnabled = NO;
	
	[self likeDislike];
}

- (void)likeDislike {
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	
	NSURLResponse *response;
	NSError *error;
	
	CLLocation *loc = [[CLLocation alloc]initWithLatitude:[[answer objectForKey:@"latitude"]doubleValue]longitude:[[answer objectForKey:@"longitude"]doubleValue]];
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=0&aid=%@&lat=%.8f&lon=%.8f&loc=%@&doL=%@&dist=%f",
							[aid urlEncode],
							del.userLoc.coordinate.latitude,
							del.userLoc.coordinate.longitude,
							[[Misc reverseGeocode:del.userPlace]urlEncode],
							check?@"on":@"off",
							fabs([loc distanceFromLocation:del.userLoc]/1609.344)];
	[loc release];
	
	NSString *urlContents = [KuippConnect formTo:@"insertLikeDislike" WithPost:poststring AndResponse:&response AndError:&error];
	
	bar.userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:nil]) return;
	
	NSString *message = [NSString stringWithFormat:
						 @"Now %@ %@\'s Answer",
						 check?@"liking":@"disliking",
						 [Misc first:[answer objectForKey:@"firstName"]lastName:[answer objectForKey:@"lastName"]]];
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Success"
						  message:message
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
	if (![kuipp fetchingData]) [self refreshAll];
}

- (IBAction)flag:(UIButton*)sender {
	bar.userInteractionEnabled = NO;
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&aid=%@",
							[aid urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"insertAnswerFlag" WithPost:poststring AndResponse:&response AndError:&error];
	
	bar.userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:nil]) return;
	
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Complaint Registered"
						  message:@"Thank you, this has been flagged."
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return answer?[comments count]+2:0;}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Configure the cell...	
	if (indexPath.row==1) {
		ButtonCell *c = (ButtonCell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
		if (!c) c = [[[ButtonCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"A"]autorelease];
		
		[c.button setTitle:@"Comment" forState:UIControlStateNormal];
		[c.button addTarget:self action:@selector(addComment) forControlEvents:UIControlEventTouchUpInside];
		
		return c;
	} else if (indexPath.row==0) {
		Cell *c = (Cell*)[tableView dequeueReusableCellWithIdentifier:@"B"];
		if (!c) c = [[[Cell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"B"]autorelease];
		
		NSDictionary *d = answer;
		
		c.dict = d;
		
		c.imag.image = [images objectForKey:[d objectForKey:@"picture"]];
		c.ctrl.tag = [[d objectForKey:@"userID"]intValue];
		[c.ctrl addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
		
		int cm = [[d objectForKey:@"numComments"]intValue];
		
		if ([[d objectForKey:@"type"]intValue]==1) {
			double ra = [[d objectForKey:@"yelpRating"]doubleValue];
			int rv = [[d objectForKey:@"yelpReviews"]intValue];
			
			NSString *title = [NSString stringWithFormat:@" %.1f, %d review%@",ra,rv,rv==1?@"":@"s"];
			[c.name setTitle:title forState:UIControlStateNormal];
			[c.name setImage:[images objectForKey:[d objectForKey:@"yelpRatingURL"]] forState:UIControlStateNormal];
			c.name.userInteractionEnabled = NO;
			
			//c.main.text = [[d objectForKey:@"answer"]stringByAppendingString:@"\n\nCLICK to read reviews on Yelp"];
			
			NSString *location = [d objectForKey:@"location"];
			NSString *loc = location?[NSString stringWithFormat:@"%@, ",location]:@"";
			
			c.foot.text = [NSString stringWithFormat:@"%@%d comment%@",loc,cm,cm==1?@"":@"s"];
			
			c.selectable = YES;
			
			c.accessoryView = [Misc detailDisclosure];
		} else {
			[c.name setTitle:[Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]otherText:@" answered:"]forState:UIControlStateNormal];
			[c.name setImage:nil forState:UIControlStateNormal];
			c.name.tag = [[d objectForKey:@"userID"]intValue];
			[c.name addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			c.name.userInteractionEnabled = YES;
			
			int lk = [[d objectForKey:@"numLike"]intValue];
			int dl = [[d objectForKey:@"numDislike"]intValue];
			
			c.foot.text = [NSString stringWithFormat:@"%@, %d like%@, %d dislike%@, %d comment%@",[Misc timeSinceNow:[d objectForKey:@"datetime"]],lk,lk==1?@"":@"s",dl,dl==1?@"":@"s",cm,cm==1?@"":@"s"];
			
			//c.main.text = [d objectForKey:@"answer"];
			
			c.selectable = NO;
			
			c.accessoryView = nil;
		}
		c.main.text = [d objectForKey:@"answer"];
		c.main.numberOfLines = 0;
		c.foot.numberOfLines = 0;
		//c.selectable = NO;
		
		return c;
	} else {Cell *c = (Cell*)[tableView dequeueReusableCellWithIdentifier:@"C"];
		if (!c) c = [[[Cell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"C"]autorelease];
		
		NSDictionary *d = [comments objectAtIndex:indexPath.row-2];
		
		c.dict = d;
		
		c.imag.image = [images objectForKey:[d objectForKey:@"picture"]];
		c.ctrl.tag = [[d objectForKey:@"userID"]intValue];
		[c.ctrl addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
		
		[c.name setTitle:[Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]otherText:@" commented:"]forState:UIControlStateNormal];
		c.name.tag = [[d objectForKey:@"userID"]intValue];
		[c.name addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
		
		c.main.text = [d objectForKey:@"comment"];
		c.main.numberOfLines = 0;
		
		c.foot.text = [NSString stringWithFormat:@"%@",[Misc timeSinceNow:[d objectForKey:@"datetime"]]];
		c.selectable = NO;
		
		return c;
	}
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	double buf = [Misc buffer];
	double img = [Misc imageSize];
	
	if (indexPath.row==1) {
		return buf*2+[Misc buttonCellHeight];
	} else if (indexPath.row==0) {
		NSString *s = [answer objectForKey:@"answer"];
		NSString *f = [NSString stringWithFormat:@"%@",[Misc timeSinceNow:[answer objectForKey:@"datetime"]]];
		/*if ([[answer objectForKey:@"type"]intValue]==1) {
			s = [s stringByAppendingString:@"\n\nCLICK to read reviews on Yelp\n"];
			f = [NSString stringWithFormat:@"\n%@",f];
		}*/
		Cell *cell = [[Cell alloc]init];
		double w = cell.contentView.frame.size.width-buf*6-img;
		[cell release];
		
		return buf*2+fmax(img,buf*2+[Misc heightForFontSize:[Misc nameSize]]+[Misc heightForText:s width:w size:[Misc mainSize]]+2+[Misc heightForText:f width:w size:[Misc footSize]]);
	} else {
		NSString *s = [[comments objectAtIndex:indexPath.row-2]objectForKey:@"comment"];
		Cell *cell = [[Cell alloc]init];
		double w = cell.contentView.frame.size.width-buf*6-img;
		[cell release];
		
		return buf*2+fmax(img,buf*2+[Misc heightForFontSize:[Misc nameSize]]+[Misc heightForText:s width:w size:[Misc mainSize]]+2+[Misc heightForFontSize:[Misc footSize]]);	
	}
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here. Create and push another view controller.
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	if (indexPath.row==0) {
		if ([[answer objectForKey:@"type"]intValue]==1) {
			WebPages *v = [[WebPages alloc]init];
			v.url = [answer objectForKey:@"yelpMobileURL"];
			[self.navigationController pushViewController:v animated:YES];
			[v release];
		}
	}
}

#pragma mark -
#pragma mark MKMapViewDelegate

- (MKAnnotationView*)mapView:(MKMapView*)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
	MKAnnotationView *pin = nil;
	pin = [map dequeueReusableAnnotationViewWithIdentifier:@"A"];
	if (pin==nil) pin = [[[MKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:@"A"]autorelease];
	pin.canShowCallout = YES;
	
	NSDictionary *d = ((Pin*)annotation).dict;
	
	pin.leftCalloutAccessoryView = [Misc leftPin:d];
	if ([[d objectForKey:@"type"]intValue]==1) pin.rightCalloutAccessoryView = [Misc rightPin:@"map detail"];
	
	if (annotation==map.userLocation) return pin;
	int qUserID = [[d objectForKey:@"userID"]intValue];
	NSString *imageName = @"";
	if ([((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).followingIDs objectForKey:[d objectForKey:@"userID"]]) imageName = @"map orange";
	else if (qUserID==[[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue]) imageName = @"map dark teal";
	else imageName = @"map teal";	
	pin.image = [UIImage imageNamed:[imageName stringByAppendingString:[d objectForKey:@"answer"]?@" Answer glow":@" Comment"]];
	
	return pin;
}

- (void)mapView:(MKMapView*)mapView annotationView:(MKAnnotationView*)annotationView calloutAccessoryControlTapped:(UIControl*)control {
	if (control.tag==1) {
		NSDictionary *d = ((Pin*)annotationView.annotation).dict;
		if ([[d objectForKey:@"type"]intValue]==1) {
			WebPages *v = [[WebPages alloc]init];
			v.url = @"http://lite.yelp.com";
			[self.navigationController pushViewController:v animated:YES];
			[v release];
		} else {
			Profile *v = [[Profile alloc]init];
			v.uid = [d objectForKey:@"userID"];
			[self.navigationController pushViewController:v animated:YES];
			[v release];
		}
	} else if (control.tag==2) {
		NSDictionary *d = ((Pin*)annotationView.annotation).dict;
		if ([[d objectForKey:@"type"]intValue]==1) {
			WebPages *v = [[WebPages alloc]init];
			v.url = [d objectForKey:@"yelpMobileURL"];
			[self.navigationController pushViewController:v animated:YES];
			[v release];
		}
	}
}

#pragma mark -
#pragma mark UIScrollView

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		if (!refreshCell.flipped) [refreshCell flip];
	} else {
		if (refreshCell.flipped) [refreshCell flip];
	}
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		[self refreshAll];
	}
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	top.frame = CGRectOffset(top.frame,0,delta*top.frame.size.height);
	bot.frame = CGRectOffset(bot.frame,0,delta*-bot.frame.size.height);
	[UIView commitAnimations];	
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
}

- (void)keyboardWasHidden:(NSNotification*)note {
	[self keyboardAdjust:note:-1];
}

#pragma mark -
#pragma mark UITextViewDelegate

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
	int newCount = [count.text intValue]-[text length]+range.length;
	if (newCount<0) return NO;
	return YES;
}

- (void)textViewDidChange:(UITextView *)textView {[self refreshCount];}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
	[super viewDidLoad];
	
	tab=1;
	
	[Misc load:self];
	bar.backgroundColor = [Misc barColor];
	
	[lButton setBackgroundImage:[Misc roundTeal]forState:UIControlStateNormal];
	[dButton setBackgroundImage:[Misc roundTeal]forState:UIControlStateNormal];
	[fButton setBackgroundImage:[Misc roundTeal]forState:UIControlStateNormal];
	
	self.navigationItem.rightBarButtonItem = [Misc mapList:tab];
	[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(listMap:) forControlEvents:UIControlEventTouchUpInside];
	
	double r = [Misc refreshCellHeight];
	refreshCell = [Misc refreshCellView];
	refreshCell.table = table;
	refreshCell.frame = CGRectMake(0, 0, self.view.frame.size.width, r);
	[table setTableHeaderView:refreshCell];
	
	table.contentInset = UIEdgeInsetsMake(-r,0,0,0);
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aSyncImageLoaded) name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	[self refreshAll];
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[aid release];
	map.delegate = nil;
	table.delegate = nil;
	table.dataSource = nil;
	textbox.delegate = nil;
	
    [super dealloc];
}

@end
