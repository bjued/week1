//
//  Medals.h
//  Kuipp
//
//  Created by Brandon Jue on 2/4/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Medals : UIViewController {
	NSString *uid;
	
	NSMutableArray *heads;
	NSMutableArray *dicts;
	
	IBOutlet UIScrollView *scroll;
	IBOutlet UIView *overlay;
	IBOutlet UIImageView *image;
	IBOutlet UITextView *text;
}

@property(nonatomic,retain) NSString *uid;
- (IBAction)popBack:(UIButton*)sender;
- (IBAction)refresh:(UIButton*)sender;
- (void)overlay:(id)sender;
- (IBAction)done:(UIButton*)sender;

@end
