//
//  RegisterPage1.m
//  Kuipp
//
//  Created by Brandon Jue on 4/23/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "RegisterPage1.h"
#import "RegisterPage2.h"
#import "TopCell.h"
#import "MidCell.h"
#import "BotCell.h"
#import "ButtonCell.h"

@implementation RegisterPage1

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)next {
	NSString *msg = @"";
	if(![Misc validEmail:email.text]) msg = @"You need a valid Email Address!";
	/*NSRange at = [email.text rangeOfString:@"@"];
	if (at.length!=0) {
		NSString *svr = [email.text substringFromIndex:at.location+at.length];
		NSRange per = [svr rangeOfString:@"."];
		if ([email.text length]==0||per.length==0||per.location==0||per.length+per.location==[svr length]) msg = @"You need a valid Email Address!";
	} else */
	if ([lName.text length]==0) msg = @"You need a Last Name!";
	if ([fName.text length]==0) msg = @"You need a First Name!";
	
	if (![msg isEqualToString:@""]) {
		NSLog(@"%@ - %@",@"Oops!",msg);
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Oops!"
							  message:msg
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
	
	RegisterPage2 *r = [[RegisterPage2 alloc]init];
	r.fName = fName.text;
	r.lName = lName.text;
	r.email = email.text;
	r.facebookID = @"0";
	[self.navigationController pushViewController:r animated:YES];
	[r release];
}

- (void)backgroundTouched:(id)sender {
	[fName resignFirstResponder];
	[lName resignFirstResponder];
	[email resignFirstResponder];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return 5;}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCellStyle s = UITableViewCellStyleDefault;
	
	switch (indexPath.row) {
		case  0: {
			TopCell *c = (TopCell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
			if (!c) c = [[[TopCell alloc]initWithStyle:s reuseIdentifier:@"A"]autorelease];
			
			c.item = fName;
			[c.contentView addSubview:c.item];
			
			c.selectable = NO;
			return c;
		} case  1: {
			MidCell *c = (MidCell*)[tableView dequeueReusableCellWithIdentifier:@"B"];
			if (!c) c = [[[MidCell alloc]initWithStyle:s reuseIdentifier:@"B"]autorelease];
			
			c.item = lName;
			[c.contentView addSubview:c.item];
			
			c.selectable = NO;
			return c;
		} case  2: {
			BotCell *c = (BotCell*)[tableView dequeueReusableCellWithIdentifier:@"C"];
			if (!c) c = [[[BotCell alloc]initWithStyle:s reuseIdentifier:@"C"]autorelease];
			
			c.item = email;
			[c.contentView addSubview:c.item];
			
			c.selectable = NO;
			return c;
		} case  4: {
			ButtonCell *c = (ButtonCell*)[tableView dequeueReusableCellWithIdentifier:@"D"];
			if (!c) c = [[[ButtonCell alloc]initWithStyle:s reuseIdentifier:@"D"]autorelease];
			
			[c.button setTitle:@"Next" forState:UIControlStateNormal];
			[c.button addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
			return c;
		} default: { 
			UITableViewCell *c = [tableView dequeueReusableCellWithIdentifier:@"Z"];
			if (!c) c = [[[UITableViewCell alloc]initWithStyle:s reuseIdentifier:@"Z"]autorelease];
		
			c.backgroundColor = [UIColor clearColor];
			c.selectionStyle = UITableViewCellSelectionStyleNone;
			return c;
		}
	}	
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
 
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
 
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
 
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath {
	double buf = [Misc buffer];
	double bch = [Misc buttonCellHeight];
	return buf*2+bch;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	[self backgroundTouched:nil];
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {
	if (textField==fName) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
	if (textField==lName) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
	if (textField==email) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	if (textField==fName) {
		[lName becomeFirstResponder];
		return NO;
	}
	if (textField==lName) {
		[email becomeFirstResponder];
		return NO;
	}
	if (textField==email) {
		[self next];
		[textField resignFirstResponder];
		return YES;
	}
	[textField resignFirstResponder];
	return YES;
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	CGRect frame = table.frame;
	frame.size.height -= delta*kb.size.height;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	table.frame = frame;
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	
	if (fName.editing) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
	if (lName.editing) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
	if (email.editing) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

- (void)keyboardWasHidden:(NSNotification*)note {[self keyboardAdjust:note:-1];}

#pragma mark -
#pragma mark Memory management

- (void)viewDidLoad {
	[super viewDidLoad];
	
	[Misc load:self];
	
	[table reloadData];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	[super viewWillDisappear:animated];
}

/* 
- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
}
 
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}

@end
