//
//  ProfileCard.m
//  Kuipp
//
//  Created by Brandon Jue on 2/3/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "ProfileCard.h"
#import "Profile.h"
#import "KuippAppDelegate.h"
#import "Medals.h"

@implementation ProfileCard

@synthesize nameID,bigBox,profilePic,classPic,name,points,interests,boxes,classTitle,level,medals,gold;
/*
- (IBAction)medalsPressed:(UIButton*)sender {
	Medals *v = [[Medals alloc]init];
	v.uid = nameID;
	[((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).navigationController pushViewController:v animated:YES];
	[v release];
}
 */
/*
- (IBAction)interestsPressed:(UIButton*)sender {
	if ([self.superview isKindOfClass:[UITableView class]]) {
		[(Profile*)((UITableView*)self.superview).delegate addInterests];
	}
}
*/
#pragma mark -
#pragma mark Initialization

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad {
 [super viewDidLoad];
 }
 */

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)dealloc {
	[nameID release];
	
	[bigBox release];
	[profilePic release];
	[classPic release];
	[name release];
	[points release];
	[interests release];
	[boxes release];
	[classTitle release];
	[level release];
	[medals release];
	[gold release];
	
    [super dealloc];
}

@end
