//
//  InviteFriends.m
//  Kuipp
//
//  Created by Brandon Jue on 2/16/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "InviteFriends.h"
#import "LeaderCell.h"
#import "Question.h"
#import "Answer.h"
#import "Profile.h"
#import "ASyncImageLoadDelegate.h"
#import <AddressBook/AddressBook.h>

@implementation InviteFriends

@synthesize at,tab;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)mainThreadImages {
	[images release];
	images = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images retain];
	for (NSDictionary *d in dicts) {
		NSString *head = [d objectForKey:@"head"];
		if ([head isEqualToString:@"Friends"]||
			[head isEqualToString:@"Possible"]||
			[head isEqualToString:@"Users"]) {
			NSString *url = [d objectForKey:@"picture"];
			NSString *pic = [images objectForKey:url];
			if (pic==nil||[pic isEqual:[Misc defaultProfile]]) {
				[images setObject:[Misc defaultProfile]forKey:url];
				if (![url isEqualToString:[Misc defaultProfileURL]]) {
					ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
					[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
				}
			}
		}
	}
}

- (void)aSyncImageLoaded {[table reloadData];}

- (void)refreshAll {
	switch (tab) {
		case  0: {
			[refreshCell refreshing];
			
			[invt release];
			invt = [[NSMutableArray alloc]init];
			[invt addObject:[NSDictionary dictionaryWithObject:@"Invite to Kuipp" forKey:@"e"]];
			
			NSString *emails = @"";
			NSString *firsts = @"";
			NSString *lasts = @"";
			
			ABAddressBookRef addressBook = ABAddressBookCreate();
			CFArrayRef ppl = ABAddressBookCopyArrayOfAllPeople(addressBook);
			CFIndex index = ABAddressBookGetPersonCount(addressBook);
			
			for (int i=0;i<index;i++) {
				ABRecordRef rec = CFArrayGetValueAtIndex(ppl,i);
				
				ABMultiValueRef mul = ABRecordCopyValue(rec,kABPersonEmailProperty);
				CFIndex ind = ABMultiValueGetCount(mul);
				NSString *eml = @"";
				for (int j=0;j<ind;j++) {
					NSString *em = (NSString*)ABMultiValueCopyValueAtIndex(mul,j);
					if ([Misc validEmail:em]) eml = [eml stringByAppendingFormat:@" %@",em];
					[em release];
				}
				if ([eml length]>0) eml = [eml substringFromIndex:1];
				CFRelease(mul);
				
				NSString *fnm = (NSString*)ABRecordCopyValue(rec,kABPersonFirstNameProperty);
				if (!fnm||[fnm isEqualToString:@"(null)"]) {
					[fnm release];
					fnm = @"";
				}
				NSString *lnm = (NSString*)ABRecordCopyValue(rec,kABPersonLastNameProperty);
				if (!lnm||[lnm isEqualToString:@"(null)"]) {
					[lnm release];
					lnm = @"";
				}
				
				[invt addObject:[NSDictionary dictionaryWithObjectsAndKeys:fnm,@"firstName",lnm,@"lastName",eml,@"email",@"Invite",@"head",nil]];
				emails = [emails stringByAppendingFormat:@",%@",eml];
				firsts = [firsts stringByAppendingFormat:@",%@",fnm];
				lasts = [lasts stringByAppendingFormat:@",%@",lnm];
				
				[lnm release];
				[fnm release];
			}
			if ([emails length]>0) emails = [emails substringFromIndex:1];
			if ([firsts length]>0) firsts = [firsts substringFromIndex:1];
			if ([lasts length]>0) lasts = [lasts substringFromIndex:1];
			
			CFRelease(ppl);
			CFRelease(addressBook);
			
			NSString *p = [NSString stringWithFormat:
						   @"&eml=%@&frt=%@&lst=%@",
						   [emails urlEncode],
						   [firsts urlEncode],
						   [lasts urlEncode]];
			
			[kuipp formTo:@"selectAddressBook" WithPost:p];
			break;
		}
		case  1:
			[refreshCell refreshing];
			[kuipp formTo:@"selectFacebook" WithPost:[NSString stringWithFormat:@"&at=%@&pch=1",[at urlEncode]]];break;
		case  2:
			[refreshCell refreshing];
			[kuipp formTo:@"selectTwitter" WithPost:[NSString stringWithFormat:@"&at=%@",[[[NSUserDefaults standardUserDefaults]objectForKey:@"twitterSN"]urlEncode]]];break;
		default: {
			if ([search.text length]>0) {
				[refreshCell refreshing];
				
				NSString *p = [NSString stringWithFormat:
						   @"&userID=%@&f=%@&k=%@",
						   [[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]urlEncode],
						   tab==3?@"firstName,lastName":@"email",
						   [search.text urlEncode]];
			
				[kuipp formTo:@"selectUsers" WithPost:p];
			}
		}
	}
}

- (void)refresh:(id)obj {
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	if (tab==0||tab==1||tab==2) [self splitData];
	else {
		[friends release];
		friends = [[NSMutableArray alloc]initWithArray:dicts];
	}

	[self mainThreadImages];
	
	[refreshCell refreshed];
	
	[searchResults release];
	searchResults = [[NSMutableArray alloc]initWithArray:friends];
	
	[table reloadData];
	[table setContentOffset:CGPointMake(0,table.tableHeaderView.frame.size.height) animated:[Misc tableHideHeaderAnimated]];
}

- (void)splitData {
	[vrfy release];
	[poss release];
	vrfy = [[NSMutableArray alloc]init];
	poss = [[NSMutableArray alloc]init];
	
	if (tab==0) {
		[vrfy addObject:[NSDictionary dictionaryWithObject:@"Confirmed contacts" forKey:@"e"]];
		[poss addObject:[NSDictionary dictionaryWithObject:@"Possible contacts" forKey:@"e"]];
	} else if (tab==1) {
		[vrfy addObject:[NSDictionary dictionaryWithObject:@"Facebook friends" forKey:@"e"]];
		[poss addObject:[NSDictionary dictionaryWithObject:@"Possible friends" forKey:@"e"]];
	} else if (tab==2) {
		[vrfy addObject:[NSDictionary dictionaryWithObject:@"Twitter friends" forKey:@"e"]];
	}
	
	NSString *rmv = @"Remove Me";
	
	for (int i=0;i<[dicts count];i++) {
		NSDictionary *d = [dicts objectAtIndex:i];
		NSString *s = [d objectForKey:@"head"];
		if ([s isEqualToString:@"Friends"]) [vrfy addObject:d];
		else if ([s isEqualToString:@"Possible"]) [poss addObject:d];
		else if ([s isEqualToString:@"Invite"]) [invt replaceObjectAtIndex:[[d objectForKey:@"i"]intValue]+1 withObject:rmv];
	}
	[invt removeObjectIdenticalTo:rmv];
	
	for (int i=[invt count];i>0;i--) {
		NSDictionary *d = [invt objectAtIndex:i-1];
		if ([[d objectForKey:@"email"]isEqualToString:@""]||
			(![d objectForKey:@"firstName"]&&
			 ![d objectForKey:@"lastName"]&&
			 ![d objectForKey:@"e"])) {
				[invt removeObjectAtIndex:i-1];
			}
	}
	
	[self combData];
}

- (void)combData {
	[friends release];
	friends = [[NSMutableArray alloc]init];
	if (vrfy) [friends addObjectsFromArray:vrfy];
	if (poss) [friends addObjectsFromArray:poss];
	if (invt) [friends addObjectsFromArray:invt];
}

- (void)sendEmails {
	NSMutableArray *arr = [[NSMutableArray alloc]init];
	for (NSDictionary *d in searchResults) if ([d objectForKey:@"checked"]) [arr addObject:[d objectForKey:@"email"]];
	
	NSString *emails = [arr componentsJoinedByString:@","];
	[arr release];
	NSString *url = [NSString stringWithFormat:@"mailto:?to=%@&subject=%@&body=%@",
					 [emails urlEncode],
					 [@"Join Me On Kuipp!" urlEncode],
					 [@"Download this amazing iOS app at: http://itunes.apple.com/us/app/kuipp/id436731294" urlEncode]];
	
	NSLog(@"%@ - %d",url,[url length]);
	
	[[UIApplication sharedApplication]openURL:[NSURL URLWithString:url]];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return [searchResults count];}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	NSDictionary *d = [searchResults objectAtIndex:indexPath.row];
	
	NSString *e = [d objectForKey:@"e"];
	if (e) {
		UITableViewCell *c = [tableView dequeueReusableCellWithIdentifier:@"C"];
		if (!c) c = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"C"]autorelease];
		
		c.textLabel.text = e;
		c.textLabel.textColor = [Misc kuippOrangeColor];
		c.textLabel.textAlignment = UITextAlignmentCenter;
		c.textLabel.backgroundColor = [UIColor clearColor];
		c.selectionStyle = UITableViewCellSelectionStyleNone;
		
		if ([e isEqualToString:@"Invite to Kuipp"]) {
			c.accessoryView = [Misc barButtonItemViewWithTitle:@"Write Email"].customView;
			[(UIButton*)c.accessoryView addTarget:self action:@selector(sendEmails) forControlEvents:UIControlEventTouchUpInside];
		} else {
			c.accessoryView = nil;
		}
		
		return c;
	}
	LeaderCell *c = (LeaderCell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
	if (!c) c = [[[LeaderCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"A"]autorelease];
	
	if (![d objectForKey:@"checked"]) {
		UILabel *label = [[UILabel alloc]init];
		label.font = [UIFont boldSystemFontOfSize:12];
		label.backgroundColor = [UIColor clearColor];
		label.textColor = [UIColor whiteColor];
		if ([[d objectForKey:@"head"]isEqualToString:@"Invite"]) {
			label.text = @"Email";
			c.imag.image = nil;
			c.foot.text = [d objectForKey:@"email"];
		} else {
			label.text = @"See Profile";
			c.imag.image = [images objectForKey:[d objectForKey:@"picture"]];
			c.foot.text = [NSString stringWithFormat:@"Level %@ %@",[d objectForKey:@"level"],[d objectForKey:@"class"]];
		}
		
		label.frame = CGRectMake(0,0,320,460);
		[label sizeToFit];
		c.accessoryView = label;
		[label release];
	} else {
		c.imag.image = nil;
		c.foot.text = [d objectForKey:@"email"];
		
		UIImageView *img = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"checkmark"]];
		img.frame = CGRectMake(0, 0, img.image.size.width, img.image.size.height);
		c.accessoryView = img;
		[img release];
	}
	
	c.dict = d;
	
	c.rank.text = @"";
	
	c.name.text = [Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]];
	
	c.selectable = YES;
	
	return c;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
	
	if (tab==0||tab==1||tab==2||tab==3||tab==4) {
		if ([dict objectForKey:@"e"]) return 40;
		return 56;
	}
	return 44;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	NSMutableDictionary *d = [NSMutableDictionary dictionaryWithDictionary:[searchResults objectAtIndex:indexPath.row]];
	if ([d objectForKey:@"e"]) return;
	if ([[d objectForKey:@"head"]isEqualToString:@"Invite"]) {
		NSString *chk = [d objectForKey:@"checked"];
		if (chk) [d removeObjectForKey:@"checked"];
		else [d setObject:@"1" forKey:@"checked"];
		[searchResults replaceObjectAtIndex:indexPath.row withObject:d];
		[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationNone];
	} else {
		Profile *p = [[Profile alloc]init];
		p.uid = [d objectForKey:@"userID"];
		[self.navigationController pushViewController:p animated:YES];
		[p release];
	}
}

#pragma mark -
#pragma mark UIScrollView

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		if (!refreshCell.flipped) [refreshCell flip];
	} else {
		if (refreshCell.flipped) [refreshCell flip];
	}
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		[self refreshAll];
	}
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	/*NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	int shiftView = 0;
	double w = self.view.frame.size.width;
	double h = self.view.frame.size.height;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	if (delta==0) {
		table.frame = CGRectMake(0,shiftView,w,h-shiftView);
		self.view.frame = CGRectMake(0,0,w,h);
	} else {
		self.view.frame = CGRectMake(0,-shiftView,w,h);
		table.frame = CGRectMake(0,shiftView,w,h-kb.size.height+49);
		table.contentOffset = CGPointMake(0,[Misc refreshCellHeight]);
	}
	[UIView commitAnimations];*/
}

- (void)keyboardWasShown:(NSNotification*)note {[self keyboardAdjust:note:1];}

- (void)keyboardWasHidden:(NSNotification*)note {[self keyboardAdjust:note:0];}

#pragma mark -
#pragma mark UISearchBarDelegate

/*- (BOOL)searchString:(NSArray*)array inDict:(NSDictionary*)dict {
	BOOL found = YES;
	NSString *element;
	for (int i=0;i<[array count];i++) {
		element = [[[array objectAtIndex:i]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]lowercaseString];
		
		if ([element length]!=0) {
			NSRange r1 = [[[dict objectForKey:@"firstName"]lowercaseString]rangeOfString:element];
			
			NSRange r2 = [[[dict objectForKey:@"lastName"]lowercaseString]rangeOfString:element];
			
			NSRange r3 = [[[dict objectForKey:@"email"]lowercaseString]rangeOfString:element];
			
			found = found && (r1.length>0 || r2.length>0 || r3.length>0	|| [dict objectForKey:@"e"]!=nil);
			
			if (!found) return NO;
		}
	}
	return found;
}*/

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	[self refreshAll];
	/*if (tab==3||tab==4) { // Name, Email
		NSURLResponse *r;
		NSError *e;
		
		NSString *p = [NSString stringWithFormat:
					   @"&userID=%@"
					   @"&f=%@"
					   @"&k=%@",
					   [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"],
					   tab==3?@"firstName,lastName":@"email",
					   searchBar.text];
		
		NSString *urlContents = [KuippConnect formTo:@"selectUsers" WithPost:p AndResponse:&r AndError:&e];
		
		if ([urlContents length]==0) return;
		
		if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
		
		[searchResults release];
		searchResults = [[NSMutableArray alloc]init];
		
		Parser *parse = [[Parser alloc]initWithDicts:searchResults];
		[parse parseXML:[urlContents substringFromIndex:1]];
		[parse release];
	} else { // AddressBook, Facebook, Twitter
		[searchResults release];
		
		if ([searchBar.text length]==0) {
			searchResults = [[NSMutableArray alloc]initWithArray:friends];
		} else {
			searchResults = [[NSMutableArray alloc]init];
			
			NSArray *explode = [searchBar.text componentsSeparatedByString:@" "];
			for (int i=0;i<[friends count];i++) {
				NSDictionary *dict = [friends objectAtIndex:i];
				if ([self searchString:explode inDict:dict]) {
					[searchResults addObject:dict];
				}
			}
		}
		
	}*/
	
	/*[table reloadData];
	[table setContentOffset:CGPointMake(0,table.tableHeaderView.frame.size.height) animated:[Misc tableHideHeaderAnimated]];
	*/
	[searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
	[searchBar resignFirstResponder];
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:YES animated:YES];
	[table setContentOffset:CGPointMake(0,[Misc refreshCellHeight]) animated:[Misc tableHideHeaderAnimated]];
	[table setAllowsSelection:NO];
	[table setScrollEnabled:NO];
	return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:NO animated:YES];
	[table setAllowsSelection:YES];
	[table setScrollEnabled:YES];
	return YES;
}

#pragma mark -
#pragma mark Initialization

- (void)viewDidLoad {
    [super viewDidLoad];
	
	for (UIView *v in [search subviews]) {
		if ([v conformsToProtocol:@protocol(UITextInputTraits)]) {
			@try {
				[(UITextField*)v setEnablesReturnKeyAutomatically:NO];
				[(UITextField*)v setKeyboardAppearance:UIKeyboardAppearanceAlert];
			}
			@catch (NSException *e) {
				NSLog(@"failed to change searchTextField's color and button");
			}
		}
	}
	
	[Misc load:self];
	
	double r = [Misc refreshCellHeight];
	refreshCell = [Misc refreshCellView];
	refreshCell.table = table;
	refreshCell.frame = CGRectMake(0, 0, self.view.frame.size.width, r);
	
	if (tab==3||tab==4) {
		UIView *v = [[UIView alloc]init];
		CGRect s = search.frame;
		double w = s.size.width;
		double h = s.size.height;
		v.frame = CGRectMake(0,0,w,r+h);
		search.frame = CGRectMake(0,r,w,h);
		[v addSubview:search];
		[v addSubview:refreshCell];
	
		[table setTableHeaderView:v];
		[v release];
	} else {
		[table setTableHeaderView:refreshCell];
	}
	
	table.contentInset = UIEdgeInsetsMake(-r,0,0,0);
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aSyncImageLoaded) name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	[self refreshAll];
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[at release];
	table.delegate = nil;
	table.dataSource = nil;
	search.delegate = nil;
	
    [super dealloc];
}

@end
