//
//  AnswerCell.h
//  Kuipp
//
//  Created by Brandon Jue on 1/31/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface AnswerCell : UITableViewCell <CLLocationManagerDelegate,UIAlertViewDelegate> {
	IBOutlet UIImageView *pic;
	IBOutlet UILabel *header;
	IBOutlet UILabel *primary;
	IBOutlet UILabel *classname;
	IBOutlet UILabel *time;
	IBOutlet UIButton *like;
	IBOutlet UILabel *slash;
	IBOutlet UIButton *dislike;
	IBOutlet UILabel *comments;
	IBOutlet UIButton *flag;
	
	NSDictionary *dict;
	
	BOOL check;
	
	CLLocationManager *manager;
	CLLocation *userLoc;
}

@property(nonatomic,retain) UIImageView *pic;
@property(nonatomic,retain) UILabel *header;
@property(nonatomic,retain) UILabel *primary;
@property(nonatomic,retain) UILabel *classname;
@property(nonatomic,retain) UILabel *time;
@property(nonatomic,retain) UIButton *like;
@property(nonatomic,retain) UILabel *slash;
@property(nonatomic,retain) UIButton *dislike;
@property(nonatomic,retain) UILabel *comments;
@property(nonatomic,retain) UIButton *flag;
@property(nonatomic,retain) NSDictionary *dict;
- (IBAction)likeIt:(UIButton*)sender;
- (IBAction)dislikeIt:(UIButton*)sender;
- (void)likeDislike;

@end
