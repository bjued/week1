//
//  Game.m
//  Kuipp
//
//  Created by Brandon Jue on 2/27/11.
//  Copyright 2011 bjued. All rights reserved.
//

#import "Game.h"
#import "Cell.h"
#import "DoubleCell.h"
#import "Profile.h"
#import "UrFeats.h"
#import "Leaderboard.h"
#import "ASyncImageLoadDelegate.h"
#import <QuartzCore/QuartzCore.h>

@implementation Game

@synthesize fromProfile,medDisp;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)classTest {
	NSArray *a = [NSArray arrayWithObjects:@"Rookie",@"Apprentice",@"Tutor",@"Mentor",@"Ninja",@"Wizard",@"Pirate",@"Scout",@"Master",@"Guru",@"Ultimate",nil];
	
	int userID = 44;
	for (NSString *s in a) {
		NSDictionary *d;
		d = [NSDictionary dictionaryWithObjectsAndKeys:
			 [Misc defaultProfileURL],@"picture",
			 @"0",@"picX",@"0",@"picY",@"1",@"picZ",
			 [NSString stringWithFormat:@"%d",userID],@"userID",
			 @"1",@"intValue",
			 s,@"stringValue",
			 s,@"firstName",
			 s,@"lastName",
			 @"0",@"datetime",
			 @"Updates",@"head",
			 @"2",@"type",
			 nil];
		[dicts addObject:d];
		userID++;
	}
}

- (void)medalTest {
	for (NSString *s in medNames) {
		NSDictionary *d;
		d = [NSDictionary dictionaryWithObjectsAndKeys:
			 [Misc defaultProfileURL],@"picture",
			 @"0",@"picX",@"0",@"picY",@"1",@"picZ",
			 [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"],@"userID",
			 s,@"stringValue",
			 s,@"firstName",
			 s,@"lastName",
			 @"0",@"datetime",
			 @"Updates",@"head",
			 @"5",@"type",
			 nil];
		[dicts addObject:d];
	}
}

- (void)createGhostsMedals:(NSArray*)names descriptions:(NSArray*)descs {
	if ([names count]!=[descs count]) {
		NSLog(@"Uneven number of medal names, descriptions");
		return;
	}
	for (int i=0;i<[names count];i++) {
		[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:
						  [names objectAtIndex:i],@"name",
						  [descs objectAtIndex:i],@"description",
						  @"Medals",@"head",
						  ([Misc artTest]?nil:@"medals Ghost"),@"image",
						  nil]];
	}
}

- (void)mainThreadImages {
	[images release];
	images = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images retain];
	for (NSDictionary *d in updates) {
		NSString *url = [d objectForKey:@"picture"];
		UIImage *pic = [images objectForKey:url];
		if (pic==nil||[pic isEqual:[Misc defaultProfile]]) {
			[images setObject:[Misc defaultProfile]forKey:url];
			if (![url isEqualToString:[Misc defaultProfileURL]]) {
				ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
				[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
			}
		}
		int t = [[d objectForKey:@"type"]intValue];
		if (t==3||t==4) {
			NSString *url = [d objectForKey:@"picture2"];
			NSString *pic = [images objectForKey:url];
			if (pic==nil||[pic isEqual:[Misc defaultProfile]]) {
				[images setObject:[Misc defaultProfile]forKey:url];
				if (![url isEqualToString:[Misc defaultProfileURL]]) {
					ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
					[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
				}
			}
		}
	}
}

- (void)aSyncImageLoaded {[table reloadData];}

- (void)refreshMore {
	[lastIDs release];
	lastIDs = [[NSString alloc]initWithString:@"0"];
	if (counts) {
		NSString *cnt = [NSString stringWithString:counts];
		[counts release];
		counts = [[NSString alloc]initWithFormat:@"%d",[cnt intValue]+1];
	} else {
		counts = [[NSString alloc]initWithString:@"1"];
	}
	
	[self refreshAll];
	
	[moreCell startAnimating];
}

- (void)refreshAll {
	[refreshCell refreshing];
	
	[kuipp cancel];
	if (!counts) {
		[counts release];
		counts = [[NSString alloc]initWithString:@"1"];
	}
	NSString *p = [NSString stringWithFormat:
				   @"&lid=%@&cnt=%@",
				   lastIDs?[lastIDs urlEncode]:@"0",
				   [counts urlEncode]];
	
	[kuipp formTo:@"selectMyFeats" WithPost:p];
}

- (void)refresh:(id)obj {
	if ([moreCell isAnimating]) [moreCell stopAnimating];
	
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	if ([Misc artTest]) [dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Early Adopter",@"name",@"Congratulations for signing up and referring 3 people!",@"description",@"Medals",@"head",nil]];
	
	if ([Misc artTest]) [self classTest];
	if ([Misc artTest]) [self medalTest];
	
	[self createGhostsMedals:medNames descriptions:medDescs];
	
	[self splitData];
	[self mainThreadImages];
	
	[refreshCell refreshed];
	
	[self filter:uButton.tag==1?uButton:(mButton.tag==1?mButton:lButton)];
}

- (void)splitData {
	[updates release];
	[medals release];
	updates = [[NSMutableArray alloc]init];
	medals = [[NSMutableArray alloc]init];
	NSMutableDictionary *m = [[NSMutableDictionary alloc]init];
	
	for (NSDictionary *d in dicts) {
		NSString *s = [d objectForKey:@"head"];
		if ([s isEqualToString:@"Updates"]) {
			if (!lastIDs||[[d objectForKey:@"updateID"]intValue]<[lastIDs intValue]) {
				[lastIDs release];
				lastIDs = [[NSString alloc]initWithString:[d objectForKey:@"updateID"]];
			}
			[updates addObject:d];
		} else if ([s isEqualToString:@"Medals"]) {
			NSString *name = [d objectForKey:@"name"];
			if (![m objectForKey:name]) [m setObject:d forKey:name];
		}
	}
	
	for (NSString *s in medNames) {
		NSMutableDictionary *md = [NSMutableDictionary dictionaryWithDictionary:[m objectForKey:s]];
		if (![md objectForKey:@"image"]) {
			[md setObject:[NSString stringWithFormat:@"medals %@",[md objectForKey:@"name"]]forKey:@"image"];
		}
		if (![[md objectForKey:@"name"]isEqualToString:@"Early Adopter"]||![[md objectForKey:@"image"]isEqualToString:@"medals Ghost"]) {
			[medals addObject:md];
		}
	}
	
	[m release];
}

- (IBAction)filter:(UIButton*)sender {
	[uButton setBackgroundImage:[Misc tabImage:sender==uButton]forState:UIControlStateNormal];
	uButton.tag = sender==uButton?1:0;
	[mButton setBackgroundImage:[Misc tabImage:sender==mButton]forState:UIControlStateNormal];
	mButton.tag = sender==mButton?1:0;
	
	[tabResults release];
	tabResults = [[NSMutableArray alloc]initWithArray:uButton.tag==1?updates:medals];
	
	[self reloadView];
}

- (IBAction)leaderboard:(UIButton*)sender {
	Leaderboard *v = [[Leaderboard alloc]init];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (void)reloadView {
	if (mButton.tag==1) {
		[self reloadScroll];
		[self.view sendSubviewToBack:table];
		[scrollV setHidden:NO];
		[table setHidden:YES];
	} else {
		[self reloadTable];
		[self.view sendSubviewToBack:scrollV];
		[scrollV setHidden:YES];
		[table setHidden:NO];
	}
}

- (void)reloadScroll {
	double h = scroll.frame.size.height;
	double bdr = [Misc border];
	double buf = [Misc buffer];
	double ttl = [Misc heightForFontSize:[Misc footSize]];
	double med = h-ttl-bdr*2; //[Misc medalSize];
	
	for (int i=0;i<[tabResults count];i++) {
		NSDictionary *m = [tabResults objectAtIndex:i];
		UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
		b.frame= CGRectMake(buf+i*(med+buf),0,med,med);
		b.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[b setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@ small",[m objectForKey:@"image"]]]forState:UIControlStateNormal];
		UILabel *l = [[UILabel alloc]init];
		l.font = [UIFont systemFontOfSize:[Misc footSize]];
		l.textColor = [UIColor darkGrayColor];
		l.backgroundColor = [UIColor clearColor];
		l.textAlignment = UITextAlignmentCenter;
		l.frame = CGRectMake(buf+i*(med+buf),med+bdr,med,ttl);
		l.text = [m objectForKey:@"name"];
		
		b.tag = i;
		
		[b addTarget:self action:@selector(displayMedal:) forControlEvents:UIControlEventTouchUpInside];
		
		[scroll addSubview:b];
		[scroll addSubview:l];
		[l release];
	}
	
	scroll.contentSize = CGSizeMake(buf+[tabResults count]*(med+buf),scroll.frame.size.height);
	
	if ([tabResults count]>0) {
		UIButton *dummy = [UIButton buttonWithType:UIButtonTypeCustom];
		dummy.tag = medDisp;
		[self displayMedal:dummy];
	}
}

- (void)reloadTable {
	[table reloadData];
	double rch = table.tableHeaderView.frame.size.height;
	if (table.contentOffset.y<rch) [table setContentOffset:CGPointMake(0,rch) animated:[Misc tableHideHeaderAnimated]];
}

- (void)displayMedal:(UIButton*)sender {
	medDisp = sender.tag;
	NSDictionary * m = [tabResults objectAtIndex:sender.tag];
	image.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@ large",[m objectForKey:@"image"]]];
	text.text = [m objectForKey:@"description"];
	
	double bdr = [Misc border];
	double buf = [Misc buffer];
	double svh = scrollV.frame.size.height;
	double sch = scroll.frame.size.height;
	double w = self.view.frame.size.width-buf*4;
	double txh = [Misc heightForText:text.text width:w size:[Misc mainSize]]+buf*2;
	double imh = svh-sch-txh-buf*3-bdr;
	double imy = buf*2;
	
	if ([[m objectForKey:@"image"]isEqualToString:@"medals Ghost"]) {
		double nmh = [Misc heightForFontSize:[Misc profileNameSize]];
		imy += nmh+buf;
		imh -= nmh+buf;
		mName.text = [m objectForKey:@"name"];
	} else {
		mName.text = @"";
	}
	
	text.frame = CGRectMake(buf*2,svh-sch-txh,w,txh);
	
	if (divider==nil) {
		divider = [[UIView alloc]init];
		divider.backgroundColor = [UIColor darkGrayColor];
		[scrollV insertSubview:divider belowSubview:text];
	}
	divider.frame = CGRectMake(0,svh-sch-txh-bdr,w+buf*4,bdr+txh);
	
	imageV.frame = CGRectMake(buf*2,imy,w,imh);
}

- (void)toProfile:(UIControl*)sender {
	Profile *v = [[Profile alloc]init];
	v.uid = [[NSString alloc]initWithFormat:@"%d",sender.tag];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (void)toMedals:(UIControl*)sender {
	NSDictionary *d = [tabResults objectAtIndex:sender.tag];
	if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue]==[[d objectForKey:@"userID"]intValue]) {
		medDisp = [medNames indexOfObject:[d objectForKey:@"stringValue"]];
		[self filter:mButton];
	} else {
		UrFeats *v = [[UrFeats alloc]init];
		v.uid = [[tabResults objectAtIndex:sender.tag]objectForKey:@"userID"];
		v.mid = [medNames indexOfObject:[d objectForKey:@"stringValue"]];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	}
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return [tabResults count];}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Configure the cell...
	NSDictionary *d = [tabResults objectAtIndex:indexPath.row];
	UITableViewCellStyle s = UITableViewCellStyleDefault;
	switch ([[d objectForKey:@"type"]intValue]) {
		case  2: {
			DoubleCell *c = (DoubleCell*)[tableView dequeueReusableCellWithIdentifier:@"B"];
			if (!c) c = [[[DoubleCell alloc]initWithStyle:s reuseIdentifier:@"B"]autorelease];
			
			c.dict = d;
			
			c.imag.image = [images objectForKey:[d objectForKey:@"picture"]];
			c.ctrl.tag = [[d objectForKey:@"userID"]intValue];
			[c.ctrl addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			
			c.ima2.contentMode = UIViewContentModeScaleAspectFit;
			c.ima2.image = [UIImage imageNamed:[NSString stringWithFormat:@"class %@ small",[d objectForKey:@"stringValue"]]];
			c.ctr2.tag = [[d objectForKey:@"userID"]intValue];
			[c.ctr2 addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			
			NSString *name = [Misc nameFromDict:d];
			
			[c.name setTitle:name forState:UIControlStateNormal];
			c.name.tag = [[d objectForKey:@"userID"]intValue];
			[c.name addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			
			c.main.text = [NSString stringWithFormat:@"ha%@ achieved Level %@ and reached %@ status!",[name isEqualToString:@"You"]?@"ve":@"s",[d objectForKey:@"intValue"],[d objectForKey:@"stringValue"]];
			
			c.foot.text = [Misc timeSinceNow:[d objectForKey:@"datetime"]];
			c.selectable = NO;
			
			return c;
		/*} case  3: {
			DoubleCell *c = (DoubleCell*)[tableView dequeueReusableCellWithIdentifier:@"C"];
			if (c==nil) c = [[[DoubleCell alloc]initWithStyle:s reuseIdentifier:@"C"]autorelease];
			
			c.imag.image = [images objectForKey:[d objectForKey:@"picture"]];
			c.ctrl.tag = [[d objectForKey:@"userID"]intValue];
			[c.ctrl addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			
			c.ima2.image = [images objectForKey:[d objectForKey:@"picture2"]];
			c.ctr2.tag = [[d objectForKey:@"userID2"]intValue];
			[c.ctr2 addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			
			[c.name setTitle:[Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]]forState:UIControlStateNormal];
			c.name.tag = [[d objectForKey:@"userID"]intValue];
			[c.name addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			
			c.main.text = [NSString stringWithFormat:@"has added %@ as a %@!",[Misc first:[d objectForKey:@"firstName2"]lastName:[d objectForKey:@"lastName2"]],[d objectForKey:@"stringValue"]];
			
			c.foot.text = [Misc timeSinceNow:[d objectForKey:@"datetime"]];
			c.selectable = NO;
			
			return c;
		*/} case  4: {
			DoubleCell *c = (DoubleCell*)[tableView dequeueReusableCellWithIdentifier:@"D"];
			if (!c) c = [[[DoubleCell alloc]initWithStyle:s reuseIdentifier:@"D"]autorelease];
			
			c.dict = d;
			
			c.imag.image = [images objectForKey:[d objectForKey:@"picture"]];
			c.ctrl.tag = [[d objectForKey:@"userID"]intValue];
			[c.ctrl addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			
			c.ima2.image = [images objectForKey:[d objectForKey:@"picture2"]];
			c.ctr2.tag = [[d objectForKey:@"userID2"]intValue];
			[c.ctr2 addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			
			NSString *name = [Misc nameFromDict:d];
			
			[c.name setTitle:name forState:UIControlStateNormal];
			c.name.tag = [[d objectForKey:@"userID"]intValue];
			[c.name addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			
			c.main.text = [NSString stringWithFormat:@"%@ now following %@",[name isEqualToString:@"You"]?@"are":@"is",[Misc first:[d objectForKey:@"firstName2"]lastName:[d objectForKey:@"lastName2"]]];
			
			c.foot.text = [Misc timeSinceNow:[d objectForKey:@"datetime"]];
			c.selectable = NO;
			
			return c;
		} case  5: {
			DoubleCell *c = (DoubleCell*)[tableView dequeueReusableCellWithIdentifier:@"E"];
			if (!c) c = [[[DoubleCell alloc]initWithStyle:s reuseIdentifier:@"E"]autorelease];
			
			c.dict = d;
			
			c.imag.image = [images objectForKey:[d objectForKey:@"picture"]];
			c.ctrl.tag = [[d objectForKey:@"userID"]intValue];
			[c.ctrl addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			
			c.ima2.contentMode = UIViewContentModeScaleAspectFit;
			c.ima2.image = [UIImage imageNamed:[NSString stringWithFormat:@"medals %@",[d objectForKey:@"stringValue"]]];
			c.ctr2.tag = indexPath.row;
			[c.ctr2 addTarget:self action:@selector(toMedals:) forControlEvents:UIControlEventTouchUpInside];
			
			NSString *name = [Misc nameFromDict:d];
			
			[c.name setTitle:name forState:UIControlStateNormal];
			c.name.tag = [[d objectForKey:@"userID"]intValue];
			[c.name addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
			
			c.main.text = [NSString stringWithFormat:@"ha%@ attained the %@ medal!",[name isEqualToString:@"You"]?@"ve":@"s",[d objectForKey:@"stringValue"]];
			
			c.foot.text = [Misc timeSinceNow:[d objectForKey:@"datetime"]];
			c.selectable = NO;
			
			return c;
		} default: {
			UITableViewCell *c = [tableView dequeueReusableCellWithIdentifier:@"Z"];
			if (!c) c = [[[UITableViewCell alloc]initWithStyle:s reuseIdentifier:@"Z"]autorelease];
			
			return c;
		}
	}
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	NSDictionary *d = [tabResults objectAtIndex:indexPath.row];
	NSString *s;
	switch ([[d objectForKey:@"type"]intValue]) {
		case  1: s = [NSString stringWithFormat:@"has achieved Level %@.",[d objectForKey:@"intVale"]];break;
		case  2: s = [NSString stringWithFormat:@"has achieved Level %@ and reached %@ status.",[d objectForKey:@"intValue"],[d objectForKey:@"stringValue"]];break;
		default: s = @"";break;// case  3:
			break;
	}
	double buf = [Misc buffer];
	double img = [Misc imageSize];
	DoubleCell *c = [[DoubleCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Z"];
	double w = c.contentView.frame.size.width-buf*6-img*2;
	[c release];
	return [Misc buffer]*2+fmax([Misc imageSize],[Misc heightForFontSize:[Misc nameSize]]+[Misc heightForText:s width:w size:[Misc mainSize]]+[Misc heightForFontSize:[Misc footSize]]);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {[tableView deselectRowAtIndexPath:indexPath animated:YES];}

#pragma mark -
#pragma mark UIScrollView

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	CGSize c = scrollView.contentSize;
	CGSize f = scrollView.frame.size;
	if (s.y<0&&![kuipp fetchingData]) {
		if (!refreshCell.flipped) [refreshCell flip];
	} else if (c.height-table.tableHeaderView.frame.size.height>f.height&&s.y>c.height-f.height&&![kuipp fetchingData]) {
		[self refreshMore];
	} else {
		if (refreshCell.flipped) [refreshCell flip];
	}
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		[self refreshAll];
	}
}

#pragma mark -
#pragma mark Initialization
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	[Misc load:self];
	self.navigationItem.leftBarButtonItem = nil;
	
	double r = [Misc refreshCellHeight];
	refreshCell = [Misc refreshCellView];
	refreshCell.table = table;
	refreshCell.frame = CGRectMake(0, 0, self.view.frame.size.width, r);
	[table setTableHeaderView:refreshCell];
	
	table.contentInset = UIEdgeInsetsMake(-r,0,0,0);
	
	UIView *v = [[UIView alloc]init];
	v.contentMode = UIViewContentModeCenter;
	moreCell = [Misc activityView];
	double aiw = moreCell.frame.size.width;
	double w = self.view.frame.size.width;
	double h = moreCell.frame.size.height;
	v.frame = CGRectMake((w-aiw)/2, 0, aiw, h);
	[v addSubview:moreCell];
	[table setTableFooterView:v];
	[v release];
	
	text.numberOfLines = 0;
	text.font = [UIFont systemFontOfSize:[Misc mainSize]];
	text.textColor = [Misc kuippOrangeColor];
	
	double buf = [Misc buffer];
	w = self.view.frame.size.width-buf*4;
	double nmh = [Misc heightForFontSize:[Misc profileNameSize]];
	mName.frame = CGRectMake(buf*2, buf*2, w, nmh);
	mName.font = [UIFont boldSystemFontOfSize:[Misc profileNameSize]];
	mName.backgroundColor = [UIColor clearColor];
	mName.textColor = [Misc kuippOrangeColor];
	
	uButton.tag = fromProfile==nil?1:0;
	mButton.tag = fromProfile==nil?0:1;
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aSyncImageLoaded) name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	medNames = [[[Misc medalNames]arrayByAddingObjectsFromArray:[Misc advNames]]retain];
	medDescs = [[[Misc medalDescs]arrayByAddingObjectsFromArray:[Misc advDescs]]retain];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	
	[self refreshAll];
	
	[Misc firstTime:@"Feats"];
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[lastIDs release];
	lastIDs = nil;
	[counts release];
	counts = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[medNames release];
	[medDescs release];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[fromProfile release];
	table.delegate = nil;
	table.dataSource = nil;
	scroll.delegate = nil;
	
    [super dealloc];
}

@end
