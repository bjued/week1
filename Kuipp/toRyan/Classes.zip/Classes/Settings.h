//
//  Settings.h
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "Facebook.h"

@interface Settings : UIViewController <FBSessionDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate> {
	BOOL findFriends;
	
	IBOutlet UIView *twitterView;
	IBOutlet UIView *bot;
	
	IBOutlet UITableView *table;
	
	// Settings
	NSMutableArray *settings;
	NSMutableArray *locationTime;
	UITextField *recent;
	UITextField *local;
	UITextField *oldpwd;
	UITextField *newpwd;
	UITextField *confirm;
	NSMutableArray *findConnections;
	NSMutableArray *notifications;
	Facebook *facebook;
	IBOutlet UIView *input;
	IBOutlet UIBarButtonItem *period;
	IBOutlet UIBarButtonItem *options;
	IBOutlet UIBarButtonItem *backCancelSettingsButton;
	IBOutlet UIBarButtonItem *saveSettingsButton;
	
	// Twitter SN Overlay
	IBOutlet UITextField *twitter;
}

@property(nonatomic,assign) BOOL findFriends;
- (void)refresh;
- (IBAction)saveSettings:(UIBarButtonItem*)sender;
- (void)settingsChanged:(BOOL)itDid;
- (void)changePassword;
- (void)cancelKB:(UIBarButtonItem *)sender;
- (void)inviteFriendsPage:(int)i withToken:(NSString *)s;
- (void)inviteFacebook;
- (void)inviteTwitter;
- (void)inputTwitter;
- (void)submitTwitter;
- (void)yelpPicked:(UIButton*)sender;
- (IBAction)numberPadButtonPressed:(UIBarButtonItem*)sender;
- (IBAction)numberPadDonePressed:(UIBarButtonItem*)sender;
- (UITableViewCell*)settingTableCell:(NSIndexPath *)indexPath;
- (void)keyboardAdjust:(NSNotification*)note:(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
