//
//  AnswerTab.m
//  Kuipp
//
//  Created by Brandon Jue on 2/26/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "AnswerTab.h"
#import "Cell.h"
#import "Question.h"
#import "Profile.h"
#import "Pin.h"
#import "ASyncImageLoadDelegate.h"

@implementation AnswerTab

@synthesize pageType;

- (void)hide {
	sTable.hidden = YES;
	[self.view sendSubviewToBack:sTable];
	
	self.navigationItem.leftBarButtonItem = nil;
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:tab==0?@"Map":@"List"];
	UIButton *b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(listMap:) forControlEvents:UIControlEventTouchUpInside];
	
	[self sortKeywords];
}

- (void)mainThreadImages {
	[images release];
	images = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images retain];
	for (NSDictionary *d in questions) {
		NSString *url = [d objectForKey:@"picture"];
		UIImage *pic = [images objectForKey:url];
		if (pic==nil||[pic isEqual:[Misc defaultProfile]]) {
			[images setObject:[Misc defaultProfile]forKey:url];
			if (![url isEqualToString:[Misc defaultProfileURL]]) {
				ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
				[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
			}
		}
	}
}

- (void)aSyncImageLoaded {[table reloadData];}

- (void)refreshAll {
	[refreshCell refreshing];
	
	[kuipp cancel];
	NSString *lid = [lastIDs objectForKey:pageType];
	NSString *cnt = [counts objectForKey:pageType];
	if (!cnt) [counts setObject:@"1" forKey:pageType];
	cnt = [counts objectForKey:pageType];
	NSString *p = [NSString stringWithFormat:
				   @"&uid=0&lid=%@&cnt=%@&sch=%@",
				   lid?[lid urlEncode]:@"0",
				   [cnt urlEncode],
				   [search.text urlEncode]];
	
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	
	if ([pageType isEqualToString:@"local"]) {
		p = [p stringByAppendingFormat:
			 @"&lat=%.8f&lon=%.8f",
			 del.userLoc.coordinate.latitude,
			 del.userLoc.coordinate.longitude];
		[kuipp formTo:@"selectLocalQuestions" WithPost:p];
	} else if ([pageType isEqualToString:@"following"]) {
		[kuipp formTo:@"selectFollowingQuestions" WithPost:p];
	} else {
		p = [p stringByAppendingFormat:
			 @"&int=%@&lat=%.8f&lon=%.8f",
			 [[pageType substringFromIndex:1]urlEncode],
			 del.userLoc.coordinate.latitude,
			 del.userLoc.coordinate.longitude];
		[kuipp formTo:@"selectKeywordQuestions" WithPost:p];
	}
}

- (void)refreshMore {
	[lastIDs setObject:@"0" forKey:pageType];
	NSString *cnt = [counts objectForKey:pageType];
	cnt = [NSString stringWithFormat:@"%d",cnt?[cnt intValue]+1:1];
	[counts setObject:cnt forKey:pageType];
	
	[self refreshAll];
	
	[moreCell startAnimating];
}

- (void)refresh:(id)obj {
	if ([moreCell isAnimating]) [moreCell stopAnimating];
	
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	[self mainThreadImages];
	
	[refreshCell refreshed];
	
	if (catButton.tag==1) [self sortKeywords];
	else [self filtered:folButton.tag==1?folButton:allButton];
}

- (void)splitData {
	[questions release];
	questions = [[NSMutableArray alloc]init];
	
	for (NSDictionary *di in dicts) {
		NSMutableDictionary *d = [NSMutableDictionary dictionaryWithDictionary:di];
		NSString *s = [d objectForKey:@"head"];
		if ([s isEqualToString:@"Questions"]) {
			NSString *lid = [lastIDs objectForKey:pageType];
			if (!lid||[[d objectForKey:@"questionID"]intValue]<[lid intValue]) {
				[lastIDs setObject:[d objectForKey:@"questionID"]forKey:pageType];
			}
			[questions addObject:d];
		}
	}
}

- (IBAction)filter:(UIButton*)sender {
	search.text = @"";
	
	[self filtered:sender];
}

- (void)filtered:(UIButton*)sender {
	pageType = sender==allButton?@"local":(sender==folButton?@"following":nil);
	
	if (sender.tag==0) [self refreshAll];
	
	[allButton setBackgroundImage:[Misc tabImage:sender==allButton]forState:UIControlStateNormal];
	allButton.tag = sender==allButton?1:0;
	[folButton setBackgroundImage:[Misc tabImage:sender==folButton]forState:UIControlStateNormal];
	folButton.tag = sender==folButton?1:0;
	[catButton setBackgroundImage:[Misc tabImage:NO]forState:UIControlStateNormal];
	catButton.tag = 0;
	
	[tabResults release];
	tabResults = [[NSMutableArray alloc]init];
	
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	
	for (int i=0;i<[questions count];i++) {
		NSDictionary *dict = [questions objectAtIndex:i];
		if (sender==allButton) {
			[tabResults addObject:dict];
		} else if (sender==folButton) {
			NSString *userID = [dict objectForKey:@"userID"];
			if ([del.followingIDs objectForKey:userID]) [tabResults addObject:dict];
		}
	}
	
	[search resignFirstResponder];	
	
	[self reloadView];
}

- (IBAction)filterKeyword:(UIButton*)sender {
	[allButton setBackgroundImage:[Misc tabImage:NO]forState:UIControlStateNormal];
	allButton.tag = 0;
	[folButton setBackgroundImage:[Misc tabImage:NO]forState:UIControlStateNormal];
	folButton.tag = 0;
	[catButton setBackgroundImage:[Misc tabImage:YES]forState:UIControlStateNormal];
	catButton.tag = 1;
	
	sTable.hidden = NO;
	[self.view bringSubviewToFront:sTable];
	
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(hide) forControlEvents:UIControlEventTouchUpInside];
	self.navigationItem.rightBarButtonItem = nil;
	
	[search resignFirstResponder];
	
	[sTable reloadData];
}

- (void)selectInterest:(int)i:(NSString*)interest {
	[self loadView];
	[self viewDidLoad];
	
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	
	index = i+[del.categories count]+1;
	
	pageType = [NSString stringWithString:interest];
	
	[self refreshAll];
	
	[allButton setBackgroundImage:[Misc tabImage:NO]forState:UIControlStateNormal];
	allButton.tag = 0;
	[folButton setBackgroundImage:[Misc tabImage:NO]forState:UIControlStateNormal];
	folButton.tag = 0;
	[catButton setBackgroundImage:[Misc tabImage:YES]forState:UIControlStateNormal];
	catButton.tag = 1;
	
	[self hide];
}

- (void)sortKeywords {
	[tabResults release];
	tabResults = [[NSMutableArray alloc]initWithArray:questions];
	
	if (index==-1) {
		[self reloadView];
		return;
	}
	
	if ([tabResults count]==0) {
		NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"Looks like there haven't been any questions about this topic recently, why don't you add your own?",@"empty",nil];
		[tabResults addObject:dict];
	}
	
	[self reloadView];
}

- (void)reloadView {
	if (tab==0) {
		[self reloadMap];
		[self.view sendSubviewToBack:table];
		map.hidden = NO;
		table.hidden = YES;
	} else {
		[self reloadTable];
		[self.view sendSubviewToBack:map];
		map.hidden = YES;
		table.hidden = NO;
	}
	self.navigationItem.rightBarButtonItem = [Misc mapList:tab];
	UIButton *b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(listMap:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)reloadMap {
	[map removeAnnotations:[map.annotations filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"!(self isKindOfClass: %@)",[MKUserLocation class]]]];
	
	for (NSDictionary *dict in tabResults) if ([dict objectForKey:@"empty"]==nil) {
		Pin *point = [[Pin alloc]init];
		point.coordinate = CLLocationCoordinate2DMake([[dict objectForKey:@"latitude"]doubleValue],[[dict objectForKey:@"longitude"]doubleValue]);
		point.title = [Misc first:[dict objectForKey:@"firstName"]lastName:[dict objectForKey:@"lastName"]];
		point.subtitle = [dict objectForKey:@"question"];
		point.dict = dict;
		[map addAnnotation:point];
		[point release];
	}
	
	if (tab==0) [Misc fitMapAnnotations:map];
}

- (void)reloadTable {[self applySearchField:search];}

- (IBAction)listMap:(UIButton*)sender {
	if (tab==1) tab=0; // Was List going to Map
	else tab=1; // Was Map going to List
	
	[search resignFirstResponder];
	
	[self reloadView];
}

- (void)toProfile:(UIControl*)sender {
	Profile *v = [[Profile alloc]init];
	v.uid = [[NSString alloc]initWithFormat:@"%d",sender.tag];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return tableView==table?[searchResults count]:1+[categories count]+[keywords count];}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (tableView==sTable) {
		UITableViewCell *c = [sTable dequeueReusableCellWithIdentifier:@"A"];
		if (!c) c = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"A"]autorelease];
		
		if (indexPath.row==0) c.textLabel.text = @"*ALL*";
		else if (indexPath.row<[categories count]+1) c.textLabel.text = [[categories objectAtIndex:indexPath.row-1]objectForKey:@"category"];
		else c.textLabel.text = [keywords objectAtIndex:indexPath.row-[categories count]-1];
		
		[c.imageView setImage:index==indexPath.row?[[Misc checkmark]image]:[[Misc checkmarkPlaceholder]image]];
		
		return c;
	}
	
	NSDictionary *d = [searchResults objectAtIndex:indexPath.row];
	
	if ([d objectForKey:@"empty"]) {
		UITableViewCell *c = [table dequeueReusableCellWithIdentifier:@"B"];
		if (!c) c = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"B"]autorelease];
		
		c.textLabel.text = [d objectForKey:@"empty"];
		c.textLabel.textColor = [Misc kuippOrangeColor];
		c.textLabel.textAlignment = UITextAlignmentCenter;
		c.textLabel.font = [UIFont boldSystemFontOfSize:[Misc nameSize]];
		c.textLabel.numberOfLines = 0;
		c.backgroundColor = [UIColor clearColor];
		
		c.selectionStyle = UITableViewCellSelectionStyleNone;
		
		return c;
	}
	
	Cell *c = (Cell*)[tableView dequeueReusableCellWithIdentifier:@"C"];
	if (!c) c = [[[Cell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"C"]autorelease];
	
	c.dict = d;
	
	c.imag.image = [images objectForKey:[d objectForKey:@"picture"]];
	c.ctrl.tag = [[d objectForKey:@"userID"]intValue];
	[c.ctrl addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
	
	[c.name setTitle:[Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]]forState:UIControlStateNormal];
	c.name.tag = [[d objectForKey:@"userID"]intValue];
	[c.name addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
	
	c.main.text = [d objectForKey:@"question"];
	
	c.foot.text = [NSString stringWithFormat:@"%@, %@ answer%@, %@",[Misc timeSinceNow:[d objectForKey:@"datetime"]],[d objectForKey:@"numAnswers"],[[d objectForKey:@"numAnswers"]intValue]==1?@"":@"s",[d objectForKey:@"category"]];
	
	c.selectable = YES;
	
	c.accessoryView = [Misc detailDisclosure];
	
	return c;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }

 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
}

 // Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}

// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
// Return NO if you do not want the item to be re-orderable.
	return YES;
}
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {return tableView==table?[Misc buffer]*2+[Misc imageSize]:30;}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	if (tableView==sTable) {
		index = indexPath.row;
		if (index==0) pageType = @"**";
		else if (index<[categories count]+1) pageType = [NSString stringWithFormat:@"*c%@",[[categories objectAtIndex:index-1]objectForKey:@"category"]];
		else pageType = [NSString stringWithFormat:@"*k%@",[keywords objectAtIndex:index-[categories count]-1]];
		search.text = @"";
		[self refreshAll];
		[self hide];
	}
	if (tableView==table) {
		NSDictionary *d = [searchResults objectAtIndex:indexPath.row];
		if ([d objectForKey:@"empty"]) return;
		Question *v = [[Question alloc]init];
		v.qid = [[NSString alloc]initWithString:[d objectForKey:@"questionID"]];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	}
}

#pragma mark -
#pragma mark MKMapViewDelegate

- (MKAnnotationView*)mapView:(MKMapView*)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
	MKAnnotationView *pin = nil;
	pin = [map dequeueReusableAnnotationViewWithIdentifier:@"A"];
	if (!pin) pin = [[[MKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:@"A"]autorelease];
	
	pin.canShowCallout = YES;
	
	NSDictionary *d = ((Pin*)annotation).dict;
	
	pin.leftCalloutAccessoryView = [Misc leftPin:d];
	pin.rightCalloutAccessoryView = [Misc rightPin:@"map detail"];
	
	if (annotation==map.userLocation) return pin;
	int qUserID = [[d objectForKey:@"userID"]intValue];
	NSString *imageName = @"";
	if ([((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).followingIDs objectForKey:[d objectForKey:@"userID"]]) imageName = @"map orange Question";
	else if (qUserID==[[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue]) imageName = @"map dark teal Question";
	else imageName = @"map teal Question";
	pin.image = [UIImage imageNamed:[imageName stringByAppendingString:[[d objectForKey:@"numAnswers"]intValue]==0?@" glow":@""]];
	
	return pin;
}

- (void)mapView:(MKMapView*)mapView annotationView:(MKAnnotationView*)annotationView calloutAccessoryControlTapped:(UIControl*)control {
	if (control.tag==1) {
		Profile *v = [[Profile alloc]init];
		v.uid = [[NSString alloc]initWithString:[((Pin*)annotationView.annotation).dict objectForKey:@"userID"]];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	} else if (control.tag==2) {
		Question *v = [[Question alloc]init];
		v.qid = [[NSString alloc]initWithString:[((Pin*)annotationView.annotation).dict objectForKey:@"questionID"]];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	}
}

#pragma mark -
#pragma mark UIScrollView

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	CGSize c = scrollView.contentSize;
	CGSize f = scrollView.frame.size;
	if (s.y<0&&![kuipp fetchingData]) {
		if (!refreshCell.flipped) [refreshCell flip];
	} else if (c.height-table.tableHeaderView.frame.size.height>f.height&&s.y>c.height-f.height&&![kuipp fetchingData]) {
		[self refreshMore];
	} else {
		if (refreshCell.flipped) [refreshCell flip];
	}
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		[self refreshAll];
	}
}

#pragma mark -
#pragma mark UISearchBarDelegate

/*- (BOOL)searchString:(NSArray*)array inDict:(NSDictionary*)dict {
	BOOL found = YES;
	NSString *element;
	for (int i=0;i<[array count];i++) {
		element = [[[array objectAtIndex:i]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]lowercaseString];
		
		if ([element length]!=0) {
			NSRange r1 = [[[dict objectForKey:@"firstName"]lowercaseString]rangeOfString:element];
			
			NSRange r2 = [[[dict objectForKey:@"lastName"]lowercaseString]rangeOfString:element];
			
			NSRange r3 = [[[dict objectForKey:@"email"]lowercaseString]rangeOfString:element];
			
			NSRange r4 = [[[dict objectForKey:@"question"]lowercaseString]rangeOfString:element];
			
			found = found && (r1.length>0 || r2.length>0 || r3.length>0 || r4.length>0);
			
			if (!found) return NO;
		}
	}
	return found;
}*/

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	[lastIDs setObject:@"0" forKey:pageType];
	[counts setObject:@"1" forKey:pageType];
	[self refreshAll];
	[searchBar resignFirstResponder];
	//[self applySearchField:searchBar];
}

- (void)applySearchField:(UISearchBar*)searchBar {
	[searchResults release];
	
	//if ([searchBar.text length]==0) {
		searchResults = [[NSMutableArray alloc]initWithArray:tabResults];
	/*} else {
		searchResults = [[NSMutableArray alloc]init];
		
		NSArray *explode = [searchBar.text componentsSeparatedByString:@" "];
		for (int i=0;i<[tabResults count];i++) {
			NSDictionary *dict = [tabResults objectAtIndex:i];
			if ([self searchString:explode inDict:dict]) {
				[searchResults addObject:dict];
			}
		}
	}*/
	
	[table reloadData];
	double rch = table.tableHeaderView.frame.size.height;
	if (table.contentOffset.y<rch) [table setContentOffset:CGPointMake(0,rch) animated:[Misc tableHideHeaderAnimated]];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
	[searchBar resignFirstResponder];
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:YES animated:YES];
	[table setContentOffset:CGPointMake(0,[Misc refreshCellHeight]) animated:[Misc tableHideHeaderAnimated]];
	[table setAllowsSelection:NO];
	[table setScrollEnabled:NO];
	return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:NO animated:YES];
	[table setAllowsSelection:YES];
	[table setScrollEnabled:YES];
	return YES;
}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	for (UIView *v in [search subviews]) {
		if ([v conformsToProtocol:@protocol(UITextInputTraits)]) {
			@try {
				[(UITextField*)v setEnablesReturnKeyAutomatically:NO];
				[(UITextField*)v setKeyboardAppearance:UIKeyboardAppearanceAlert];
			}
			@catch (NSException *e) {
				NSLog(@"failed to change searchTextField's color and button");
			}
		}
	}
	
	tab=1;
	
	[Misc load:self];
	self.navigationItem.leftBarButtonItem=nil;
	self.navigationItem.rightBarButtonItem = [Misc mapList:tab];
	[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(listMap:) forControlEvents:UIControlEventTouchUpInside];
	
	UIView *v = [[UIView alloc]init];
	CGRect s = search.frame;
	double w = s.size.width;
	double h = s.size.height;
	double r = [Misc refreshCellHeight];
	v.frame = CGRectMake(0,0,w,r+h);
	refreshCell = [Misc refreshCellView];
	refreshCell.table = table;
	refreshCell.frame = CGRectMake(0, 0, self.view.frame.size.width, r);
	search.frame = CGRectMake(0,r,w,h);
	[v addSubview:search];
	[v addSubview:refreshCell];
	
	[table setTableHeaderView:v];
	[v release];
	
	v = [[UIView alloc]init];
	v.contentMode = UIViewContentModeCenter;
	moreCell = [Misc activityView];
	double aiw = moreCell.frame.size.width;
	h = moreCell.frame.size.height;
	v.frame = CGRectMake((w-aiw)/2, 0, aiw, h);
	[v addSubview:moreCell];
	[table setTableFooterView:v];
	
	table.contentInset = UIEdgeInsetsMake(-r,0,0,0);
	
	lastIDs = [[NSMutableDictionary alloc]init];
	counts = [[NSMutableDictionary alloc]init];
	
	index = -1;
	allButton.tag = 1;
	if (!pageType) pageType = @"local";
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aSyncImageLoaded) name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	categories = [[NSMutableArray alloc]init];
	for (NSString *key in [del.categories allKeys]) [categories addObject:@"1"];
	for (NSString *key in [del.categories allKeys]) {
		NSString *ind = [del.categories objectForKey:key];
		NSDictionary *d = [NSDictionary dictionaryWithObjectsAndKeys:
						   key,@"category",
						   ind,@"categoryID",
						   nil];
		[categories replaceObjectAtIndex:[ind intValue]-1 withObject:d];
	}
	
	keywords = [[NSMutableArray alloc]init];
	for (NSString *key in [del.interests allKeys]) [keywords addObject:key];
	
	search.text = @"";
	[self refreshAll];
	
	[Misc firstTime:@"Answer Tab"];
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[categories release];
	[keywords release];
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[lastIDs release];
	[counts release];
	map.delegate = nil;
	table.delegate = nil;
	table.dataSource = nil;
	sTable.delegate = nil;
	sTable.dataSource = nil;
	search.delegate = nil;
	
    [super dealloc];
}

@end
