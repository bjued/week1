//
//  KuippIt.h
//  Kuipp
//
//  Created by Brandon Jue on 1/4/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface KuippIt : UIViewController <CLLocationManagerDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UITextViewDelegate,UIAlertViewDelegate> {
	
	NSMutableArray *dicts;
	NSMutableArray *heads;
	
	NSMutableArray *catArray;
	NSMutableArray *folArray;
	
	NSMutableArray *qDicts;
	NSMutableArray *qHeads;
	
	UITableView *catTable;
	UITableView *folTable;
	
	int catID;
	
	//KuippIT
	BOOL isPublic;
	IBOutlet UITextView *kuipp;
	IBOutlet UILabel *count;
	IBOutlet UIButton *category;
	IBOutlet UITextField *keywords;
	IBOutlet UIButton *directing;
	IBOutlet UIButton *pub;
	IBOutlet UIButton *pri;
	
	//CLLocation
	CLLocationManager *manager;
	CLLocation *userLoc;
	
	//Keyboard
	BOOL viewMoved;
}

- (IBAction)popBack:(UIButton*)sender;
- (void)refresh;
- (void)refreshCategory;
- (void)refreshFollowers;
- (void)refreshCount;
- (void)splitData;
- (IBAction)category:(UIButton*)sender;
- (IBAction)direct:(UIButton*)sender;
- (IBAction)pub:(UIButton*)sender;
- (IBAction)pri:(UIButton*)sender;
- (IBAction)submit:(UIButton*)sender;
- (void)submit;
- (NSString*)directToFollowerIDs;
- (IBAction)backgroundTouched:(UIControl*)sender;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
