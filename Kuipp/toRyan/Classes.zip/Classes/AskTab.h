//
//  AskTab.h
//  Kuipp
//
//  Created by Brandon Jue on 2/26/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "Facebook.h"

@interface AskTab : UIViewController <FBSessionDelegate,CLLocationManagerDelegate,MKMapViewDelegate,MKReverseGeocoderDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UITextViewDelegate> {
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	
	NSMutableArray *catArray;
	NSMutableArray *folArray;
	
	Facebook *facebook;
	
	//KuippIT
	IBOutlet UITableView *table;
	IBOutlet UITableView *sTable;
	NSMutableArray *sArray;
	UITextView *ask;
	UILabel *count;
	int catID;
	UITextField *keywords;
	UISwitch *isPublic;
	UIButton *pubFB;
	UIButton *pubTW;
	UIButton *pubYP;
	UIView *yelpView;
	
	NSMutableDictionary *kpids;
	NSMutableDictionary *fbids;
	NSMutableDictionary *twids;
	
	//CLLocation
	CLLocationCoordinate2D coord;
	MKReverseGeocoder *location;
	MKPlacemark *locationPlacemark;
}

@property(nonatomic,assign) CLLocationCoordinate2D coord;
- (void)back;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)refreshCount;
- (void)splitData;
- (void)category;
- (void)direct;
- (void)addSTable;
- (void)removeSTable;
- (IBAction)submit:(UIButton*)sender;
- (void)submit;
- (NSString*)directToFollowerIDs;
- (NSString*)stringFromMutDict:(NSMutableDictionary*)dict;
- (void)toUser:(int)sysid using:(NSString*)system;
- (void)removeUser:(int)sysid using:(NSString*)system;
- (void)removeKB;
- (void)toggleButton:(UIButton*)sender;
- (void)loginFB;
- (void)firstYelp;
- (void)createYelpPicker;
- (void)yelpPicked:(UIButton*)sender;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
