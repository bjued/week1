//
//  Answer.h
//  Kuipp
//
//  Created by Brandon Jue on 12/20/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface Answer : UIViewController <MKMapViewDelegate,UITextViewDelegate,UITableViewDelegate> {
	NSString *aid;
	int tab;

	IBOutlet UIView* bar;
	IBOutlet UIButton *lButton;
	IBOutlet UIButton *dButton;
	IBOutlet UIButton *fButton;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableDictionary *images;
	
	RefreshCell *refreshCell;
	
	NSDictionary *answer;
	NSMutableArray *comments;
	
	IBOutlet UITableView *table;
	IBOutlet MKMapView *map;
	
	UIBarButtonItem *listMap;
	
	// Reply
	IBOutlet UIView *top;
	IBOutlet UIView *bot;
	IBOutlet UITextView *textbox;
	IBOutlet UILabel *count;
		
	BOOL submitLike;
	BOOL check;
}

@property(nonatomic,retain) NSString *aid;
- (void)back;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)splitData;
- (void)reloadView;
- (void)reloadMap;
- (void)reloadTable;
- (void)refreshCount;
- (IBAction)addComment;
- (IBAction)cancelComment;
- (IBAction)trySend:(UIButton*)sender;
- (void)send;
- (void)listMap:(UIButton*)sender;
- (void)toProfile:(UIControl*)sender;
- (IBAction)likeIt:(UIButton*)sender;
- (IBAction)dislikeIt:(UIButton*)sender;
- (void)likeDislike;
- (IBAction)flag:(UIButton*)sender;
- (void)keyboardAdjust:(NSNotification *)note:(int)delta;
- (void)keyboardWasShown:(NSNotification *)note;
- (void)keyboardWasHidden:(NSNotification *)note;

@end
