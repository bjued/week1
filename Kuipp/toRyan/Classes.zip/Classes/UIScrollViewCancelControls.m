//
//  UIScrollViewCancelControls.m
//  Kuipp
//
//  Created by Brandon Jue on 3/17/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "UIScrollViewCancelControls.h"

@implementation UIScrollViewCancelControls

- (BOOL)touchesShouldCancelInContentView:(UIView *)view {return YES;}

@end
