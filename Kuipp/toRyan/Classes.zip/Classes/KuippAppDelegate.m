//
//  KuippAppDelegate.m
//  Kuipp
//
//  Created by Brandon Jue on 12/14/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "KuippAppDelegate.h"
#import "LoadingView.h"
#import "MapSelect.h"
#import "AnswerTab.h"
#import "Question.h"
#import "Answer.h"
#import "MyQA.h"
#import "Game.h"
#import "Profile.h"
#import "Party.h"
#import "SearchTable.h"
#import "Inbox.h"
#import "Message.h"
#import "Connections.h"
#import "Settings.h"
#import "InviteFriends.h"

@implementation KuippAppDelegate

@synthesize images,categories,interests,followingIDs,alert,window,loadingViewController,navigationController,tabBarController,facebook,userLoc,userPlace;

#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	application.applicationIconBadgeNumber = 0;
    
    // Override point for customization after application launch.
	images = [[NSMutableDictionary alloc]init];
	
    // Add the navigation controller's view to the window and display.
    [window addSubview:loadingViewController.view];
    [window makeKeyAndVisible];
	
	//facebook handling
	facebook = [[Facebook alloc]initWithAppId:@"192635410753372"];
	
	//location handling
	firstUpdate = YES;
	clLocMan = [[CLLocationManager alloc]init];
	clLocMan.delegate = self;
	clLocMan.desiredAccuracy = kCLLocationAccuracyHundredMeters; //default: kCLLocationAccuracyBest
	clLocMan.distanceFilter = 100; //default: kCLDistanceFilterNone
	[clLocMan startUpdatingLocation];
	
	alert = [[launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey]retain];
	
	[self rateMe];
	
    return YES;
}

- (void)rateMe {
	NSUserDefaults *s = [NSUserDefaults standardUserDefaults];
	NSString *key = [NSString stringWithFormat:@"%@rated",[s objectForKey:@"userID"]];
	if (![s objectForKey:key]&&
		[[alert objectForKey:@"kuipp"]objectForKey:@"rate"]) {
		UIAlertView *rate = [[UIAlertView alloc]
							 initWithTitle:@"Please Rate Our App!"
							 message:@"Please take a few seconds to rate and review our app so we can make it even better."
							 delegate:self
							 cancelButtonTitle:@"Not Now"
							 otherButtonTitles:@"Sure!",nil];
		[rate show];
		[rate release];
	}
}

#pragma mark -
#pragma mark Navigation

- (void)reloadTabs {
	//unload views
	
	NSArray *a;
	NSArray *vcs = [tabBarController viewControllers];
	
	MapSelect *v = [[MapSelect alloc]init];
	a = [[NSArray alloc]initWithObjects:v,nil];
	[[vcs objectAtIndex:0]setViewControllers:a];
	[a release];
	[v release];
	
	AnswerTab *t = [[AnswerTab alloc]init];
	a = [[NSArray alloc]initWithObjects:t,nil];
	[[vcs objectAtIndex:1]setViewControllers:a];
	[a release];
	[t release];
	
	MyQA *q = [[MyQA alloc]init];
	a = [[NSArray alloc]initWithObjects:q,nil];
	[[vcs objectAtIndex:2]setViewControllers:a];
	[a release];
	[q release];
	
	Game *g = [[Game alloc]init];
	a = [[NSArray alloc]initWithObjects:g,nil];
	[[vcs objectAtIndex:3]setViewControllers:a];
	[a release];
	[g release];
	
	Profile *p = [[Profile alloc]init];
	a = [[NSArray alloc]initWithObjects:p,nil];
	[[vcs objectAtIndex:4]setViewControllers:a];
	[a release];
	[p release];
}

- (void)toMainApp:(NSMutableArray*)d {
	[[UIApplication sharedApplication]registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert|UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound)];
	
	if(!kuipp) kuipp = [[KuippConnect alloc]init];
	
	NSString *p = [NSString stringWithFormat:
				   @"&lat=%.8f&lon=%.8f&loc=%@",
				   userLoc.coordinate.latitude,
				   userLoc.coordinate.longitude,
				   [[Misc reverseGeocode:userPlace]urlEncode]];
				   
	[kuipp cancel];
	[kuipp formTo:@"updateLocation" WithPost:p];
	
	[categories release];
	categories = [[NSMutableDictionary alloc]init];
	[categories setDictionary:[d objectAtIndex:0]];
	[categories removeObjectForKey:@"head"];
	
	[interests release];
	interests = [[NSMutableDictionary alloc]init];
	[interests setDictionary:[d objectAtIndex:1]];
	[interests removeObjectForKey:@"head"];
	
	[followingIDs release];
	followingIDs = [[NSMutableDictionary alloc]init];
	[followingIDs setDictionary:[d objectAtIndex:2]];
	[followingIDs removeObjectForKey:@"head"];
	
	if ([d count]==4) [Misc updateUserSettings:[d objectAtIndex:3]];
	/*
	NSUserDefaults *s = [NSUserDefaults standardUserDefaults];
	NSString *key = [NSString stringWithFormat:@"%@facebookAT",[s objectForKey:@"email"]];
	NSString *at = [s objectForKey:key];
	[s removeObjectForKey:@"regetFacebook"];
	if (![s objectForKey:@"regetFacebook"]) {
		at = @"";
		[s setObject:@"1" forKey:@"regetFacebook"];
	}
	if ([at length]>1) facebook.accessToken = at;
	*/
	if ([Misc debug]) NSLog(@"\n%@\n%@\n%@",categories,interests,followingIDs);
	
	if (alert) {
		[self toAlert];
	} else {
		NSUserDefaults *s = [NSUserDefaults standardUserDefaults];
		if (![s objectForKey:@"ABInviteReminder"]) {
			if (![s objectForKey:@"firstLogin"]) {
				UIAlertView *alt = [[UIAlertView alloc]initWithTitle:@"New Address Book!" message:@"Be sure to invite your friends to join you on Kuipp!" delegate:self cancelButtonTitle:@"Maybe Later" otherButtonTitles:@"Sure!",nil];
				[alt show];
				[alt release];
				[s setObject:@"1" forKey:@"ABInviteReminder"];
			} else {
				[s removeObjectForKey:@"firstLogin"];
			}
		}
		
		for (UIView *v in [window subviews]) [v removeFromSuperview];
		[window addSubview:tabBarController.view];
		
		[tabBarController setSelectedIndex:1];
	}
}

- (void)firstLogin:(NSMutableArray*)d {
	[[NSUserDefaults standardUserDefaults]setObject:@"1" forKey:@"firstLogin"];
	[self toMainApp:d];
	
	Profile *p = [[Profile alloc]init];
	Settings *s = [[Settings alloc]init];
	s.findFriends = YES;
	NSArray *a = [[NSArray alloc]initWithObjects:p,s,nil];
	[[[tabBarController viewControllers]objectAtIndex:4]setViewControllers:a];
	
	[tabBarController setSelectedIndex:4];
	[a release];
	[s release];
	[p release];
}

- (void)toLogin {
	if (kuipp) [kuipp cancel];
	
	//reset tabs
	[self reloadTabs];
	
	// swap to login
	for (UIView *v in [window subviews]) [v removeFromSuperview];
	[window addSubview:navigationController.view];
}

- (void)toAlert {
	NSDictionary *d = [alert objectForKey:@"kuipp"];
	NSString *direct = [d objectForKey:@"head"];
	
	NSArray *vcs = [tabBarController viewControllers];
	
	for (UIView *v in [window subviews]) [v removeFromSuperview];
	[window addSubview:tabBarController.view];
	
	if ([direct isEqualToString:@"Question"]) {
		AnswerTab *t = [[AnswerTab alloc]init];
		Question *v = [[Question alloc]init];
		v.qid = [[d objectForKey:@"questionID"]description];
		NSArray *a = [[NSArray alloc]initWithObjects:t,v,nil];
		[[vcs objectAtIndex:1]setViewControllers:a];
		[a release];
		[v release];
		[t release];
		[tabBarController setSelectedIndex:1];
	} else if ([direct isEqualToString:@"Answer"]) {
		AnswerTab *t = [[AnswerTab alloc]init];
		Question *v = [[Question alloc]init];
		v.qid = [[d objectForKey:@"questionID"]description];
		NSArray *a = [[NSArray alloc]initWithObjects:t,v,nil];
		[[vcs objectAtIndex:1]setViewControllers:a];
		[a release];
		[v release];
		[t release];
		[tabBarController setSelectedIndex:1];
	} else if ([direct isEqualToString:@"Comment"]) {
		AnswerTab *t = [[AnswerTab alloc]init];
		Question *q = [[Question alloc]init];
		q.qid = [NSString stringWithFormat:@"%@",[d objectForKey:@"questionID"]];
		Answer *v = [[Answer alloc]init];
		v.aid = [[d objectForKey:@"answerID"]description];
		NSArray *a = [[NSArray alloc]initWithObjects:t,q,v,nil];
		[[vcs objectAtIndex:1]setViewControllers:a];
		[a release];
		[v release];
		[q release];
		[t release];
		[tabBarController setSelectedIndex:1];
	} else if ([direct isEqualToString:@"Medal"]) {
		Game *g = [[Game alloc]init];
		g.fromProfile = @"1";
		NSArray *a = [[NSArray alloc]initWithObjects:g,nil];
		[[vcs objectAtIndex:3]setViewControllers:a];
		[a release];
		[g release];
		[tabBarController setSelectedIndex:3];
	} else if ([direct isEqualToString:@"Message"]) {
		Profile *p = [[Profile alloc]init];
		Inbox *i = [[Inbox alloc]init];
		i.tab = 0;
		Message *v = [[Message alloc]init];
		v.cid = [[d objectForKey:@"chainID"]description];
		v.mid = [[d objectForKey:@"messageID"]description];
		NSArray *a = [[NSArray alloc]initWithObjects:p,i,v,nil];
		[[vcs objectAtIndex:4]setViewControllers:a];
		[a release];
		[v release];
		[i release];
		[p release];
		[tabBarController setSelectedIndex:4];
	} else if ([direct isEqualToString:@"User"]) {
		Profile *p = [[Profile alloc]init];
		p.uid = [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"];
		Connections *c = [[Connections alloc]init];
		c.uid = [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"];
		Profile *v = [[Profile alloc]init];
		v.uid = [[d objectForKey:@"followerID"]description];
		NSArray *a = [[NSArray alloc]initWithObjects:p,c,v,nil];
		[[vcs objectAtIndex:4]setViewControllers:a];
		[a release];
		[v release];
		[c release];
		[p release];
		[tabBarController setSelectedIndex:4];
	} else if ([direct isEqualToString:@"Profile"]) {
		Profile *p = [[Profile alloc]init];
		p.uid = [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"];
		NSArray *a = [[NSArray alloc]initWithObjects:p,nil];
		[[vcs objectAtIndex:4]setViewControllers:a];
		[a release];
		[p release];
		[tabBarController setSelectedIndex:4];
	} else if ([direct isEqualToString:@"Party"]) {
		Profile *p = [[Profile alloc]init];
		p.uid = [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"];
		Party *y = [[Party alloc]init];
		y.uid = [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"];
		NSArray *a = [[NSArray alloc]initWithObjects:p,y,nil];
		[[vcs objectAtIndex:4]setViewControllers:a];
		[a release];
		[y release];
		[p release];
		[tabBarController setSelectedIndex:4];
	} else if ([direct isEqualToString:@"Scholarship"]) {
		Profile *p = [[Profile alloc]init];
		p.uid = [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"];
		Party *y = [[Party alloc]init];
		y.uid = [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"];
		SearchTable *v = [[SearchTable alloc]init];
		v.type = @"Scholarships";
		v.party = y;
		NSArray *a = [[NSArray alloc]initWithObjects:p,y,v,nil];
		[[vcs objectAtIndex:4]setViewControllers:a];
		[a release];
		[v release];
		[y release];
		[p release];
		[tabBarController setSelectedIndex:4];
	}
}

- (void)fromURL:(NSURL*)url {
	/*
	 url:		kuipp://[static][variable]
	 static (1x base 85):
		1 = Question
		2 = Answer
	 variable (5x base 85)
		id in base 62
	 base 85:1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@&%?,=[]_:-+.*$#!'^();~
	 size:		kuipp://15 = 5://15 = 5+3+1+5 = 14
	 ex kuipp://10001f
	 */
	
	NSString *path = [[[url host]description]stringByAppendingString:[[url path]description]];
	
	if ([path length]!=6) return;
	
	NSString *type = [Misc base85to10:[path substringToIndex:1]];
	NSString *tid = [path substringFromIndex:1];
	
	if ([type intValue]==1||[type intValue]==2) {
		AnswerTab *t = [[AnswerTab alloc]init];
		Question *v = [[Question alloc]init];
		v.qid = [Misc base85to10:tid];
		NSArray *a = [[NSArray alloc]initWithObjects:t,v,nil];
		[[[tabBarController viewControllers]objectAtIndex:1]setViewControllers:a];
		[a release];
		[v release];
		[t release];
		[tabBarController setSelectedIndex:1];
	}
}

#pragma mark -
#pragma mark Push Notifications

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
	NSString *dvt = [NSString stringWithString:[deviceToken description]];
	// concat string
	dvt = [dvt stringByReplacingOccurrencesOfString:@" " withString:@""];
	// remove '<' and '>'
	dvt = [[dvt substringToIndex:[dvt length]-1]substringFromIndex:1];
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=0&dvt=%@",
							[dvt urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"insertDeviceToken" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	[KuippConnect checkSessionCode:urlContents forView:nil];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)err {NSLog(@"Failed to register for Remote Notifications: %@",err);}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
	application.applicationIconBadgeNumber = 0;
	
	alert = [userInfo retain];
	if (application.applicationState!=UIApplicationStateActive) {
		[self toAlert];
		return;
	}
	
	NSString *msg = [[userInfo objectForKey:@"aps"]objectForKey:@"alert"];
	if (!msg) return;
	
	UIAlertView *a = [[UIAlertView alloc]
					  initWithTitle:@"Kuipp"
					  message:msg
					  delegate:self
					  cancelButtonTitle:@"OK"
					  otherButtonTitles:@"View",nil];
	[a show];
	[a release];
}

#pragma mark -
#pragma mark OpenURLDelegate

- (BOOL)application:(UIApplication*)application handleOpenURL:(NSURL*)url {
	if (!url) return NO;
	if ([[url scheme]isEqualToString:@"kuipp"]) {
		[self fromURL:url];
	}
	return [facebook handleOpenURL:url];
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	NSUserDefaults *s = [NSUserDefaults standardUserDefaults];
	NSString *key = [NSString stringWithFormat:@"%@rated",[s objectForKey:@"userID"]];
	if ([alertView.title isEqualToString:@"Please Rate Our App!"]) {
		if (buttonIndex==1) {
			NSURLResponse *r;
			NSError *e;
			
			NSString *urlContents = [KuippConnect formTo:@"appRate" WithPost:@"" AndResponse:&r AndError:&e];
			
			if ([urlContents length]==0) return;
			
			[s setObject:@"1" forKey:key];
			
			[[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlContents]];
		}
	} else if ([alertView.title isEqualToString:@"New Address Book!"]) {
		if (buttonIndex==1) {
			Profile *p = [[Profile alloc]init];
			p.uid = [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"];
			Settings *s = [[Settings alloc]init];
			InviteFriends *v = [[InviteFriends alloc]init];
			v.at = nil;
			v.tab = 0;
			
			NSArray *vcs = [tabBarController viewControllers];
			NSArray *a = [[NSArray alloc]initWithObjects:p,s,v,nil];
			[[vcs objectAtIndex:4]setViewControllers:a];
			[a release];
			[v release];
			[s release];
			[p release];
			[tabBarController setSelectedIndex:4];
		}
	} else {
		[self rateMe];
		if (buttonIndex==1) [self toAlert];
	}
}

#pragma mark -
#pragma mark UITabBarControllerDelegate

- (void)tabBarController:(UITabBarController*)tabBarC didSelectViewController:(UIViewController*)viewC {
	if ([viewC isEqual:[tabBarC.viewControllers objectAtIndex:0]]) {
		MapSelect *m = [[MapSelect alloc]init];
		NSArray *views = [NSArray arrayWithObject:m];
		[(UINavigationController*)viewC setViewControllers:views];
		[m release];
	}
}

#pragma mark -
#pragma mark CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager*)mgr didUpdateToLocation:(CLLocation*)newLoc fromLocation:(CLLocation*)oldLoc {
	if ([newLoc.timestamp timeIntervalSinceNow]>-[Misc locationWithinTime]) {
		if (userLoc.coordinate.latitude!=newLoc.coordinate.latitude||userLoc.coordinate.longitude!=newLoc.coordinate.longitude||firstUpdate) {
			if (!mkRevGeo.querying&&(!lastPlUpdate||[lastPlUpdate timeIntervalSinceNow]<-[Misc geocodeInterval])) {
				[mkRevGeo release];
				mkRevGeo = [[MKReverseGeocoder alloc]initWithCoordinate:CLLocationCoordinate2DMake(newLoc.coordinate.latitude,newLoc.coordinate.longitude)];
				mkRevGeo.delegate = self;
				[mkRevGeo start];
			} else if ([[tabBarController.view superview]isEqual:window]) {
				NSString *p = [NSString stringWithFormat:
							   @"&lat=%.8f&lon=%.8f",
							   newLoc.coordinate.latitude,
							   newLoc.coordinate.longitude];
				
				[kuipp cancel];
				[kuipp formTo:@"updateLocation" WithPost:p];
			}
		}
		[userLoc release];
		userLoc = [newLoc retain];
		
		if ([Misc debug]) NSLog(@"%@",userLoc);
	}
}

- (void)locationManager:(CLLocationManager *)mgr didFailWithError:(NSError *)error {
	NSLog(@"%@",error);
	if ([error code]==kCLErrorDenied) {
		[mgr stopUpdatingLocation];
		[Misc locationDenied];
	}
}

- (void)locationManager:(CLLocationManager *)mgr didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
	if (status==kCLAuthorizationStatusAuthorized) [mgr startUpdatingLocation];
	if (status==kCLAuthorizationStatusDenied||
		status==kCLAuthorizationStatusRestricted) {
		[mgr stopUpdatingLocation];
		[Misc locationDenied];
	}
}

#pragma mark -
#pragma mark MKReverseGeocoderDelegate

- (void)reverseGeocoder:(MKReverseGeocoder*)geocoder didFindPlacemark:(MKPlacemark*)placemark {
	[userPlace release];
	userPlace = [placemark retain];
	
	if ([Misc debug]) NSLog(@"%@",userPlace);
	
	[lastPlUpdate release];
	lastPlUpdate = [[NSDate date]retain];
	
	if ([[tabBarController.view superview]isEqual:window]) {
		NSString *p = [NSString stringWithFormat:
					   @"&lat=%.8f&lon=%.8f&loc=%@",
					   geocoder.coordinate.latitude,
					   geocoder.coordinate.longitude,
					   [[Misc reverseGeocode:userPlace]urlEncode]];
	
		[kuipp cancel];
		[kuipp formTo:@"updateLocation" WithPost:p];
		firstUpdate = NO;
	}
}

- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFailWithError:(NSError *)error {NSLog(@"%@",error);}

#pragma mark -
#pragma mark Foreground/Background

- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
	[clLocMan stopUpdatingLocation];
	//clLocMan.desiredAccuracy = kCLLocationAccuracyKilometer; //default: kCLLocationAccuracyBest
	//clLocMan.distanceFilter = 1000; //default: kCLDistanceFilterNone
	//[clLocMan startUpdatingLocation];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
	application.applicationIconBadgeNumber = 0;
	firstUpdate = YES;
	//[clLocMan stopUpdatingLocation];
	//clLocMan.desiredAccuracy = kCLLocationAccuracyHundredMeters; //default: kCLLocationAccuracyBest
	//clLocMan.distanceFilter = 100; //default: kCLDistanceFilterNone
	[clLocMan startUpdatingLocation];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
}

#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}

- (void)dealloc {
	[images release];
	[alert release];
	[facebook release];
	[userLoc release];
	[userPlace release];
	
	[loadingViewController release];
	[navigationController release];
	[tabBarController release];
	[window release];
	
	[super dealloc];
}

@end
