//
//  QACell.h
//  Kuipp
//
//  Created by Brandon Jue on 1/30/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QACell : UITableViewCell {
	IBOutlet UIImageView *pic;
	IBOutlet UILabel *qOwner;
	IBOutlet UILabel *qQuestion;
	IBOutlet UILabel *qClass;
	IBOutlet UIButton *aButton;
	IBOutlet UILabel *aOwner;
	IBOutlet UILabel *aAnswer;
	IBOutlet UILabel *aTime;
}

@property(nonatomic,retain) UIButton *aButton;
@property(nonatomic,retain) UIImageView *pic;
@property(nonatomic,retain) UILabel *qOwner;
@property(nonatomic,retain) UILabel *qQuestion;
@property(nonatomic,retain) UILabel *qClass;
@property(nonatomic,retain) UILabel *aOwner;
@property(nonatomic,retain) UILabel *aAnswer;
@property(nonatomic,retain) UILabel *aTime;

@end
