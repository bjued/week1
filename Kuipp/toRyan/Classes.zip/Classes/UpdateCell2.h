//
//  UpdateCell2.h
//  Kuipp
//
//  Created by Brandon Jue on 1/29/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UpdateCell2 : UITableViewCell {
	NSString *nameID;
	IBOutlet UIImageView *picLeft;
	IBOutlet UIButton *name;
	IBOutlet UIWebView *primary;
	IBOutlet UIImageView *picRight;
	IBOutlet UILabel *secondary;
}

@property(nonatomic,retain) NSString *nameID;
@property(nonatomic,retain) UIImageView *picLeft;
@property(nonatomic,retain) UIButton *name;
@property(nonatomic,retain) UIWebView *primary;
@property(nonatomic,retain) UIImageView *picRight;
@property(nonatomic,retain) UILabel *secondary;
- (IBAction)nameTouched:(UIButton*)sender;

@end
