//
//  UrFeats.m
//  Kuipp
//
//  Created by Brandon Jue on 3/17/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "UrFeats.h"
#import "Cell.h"
#import "DoubleCell.h"
#import "Profile.h"
#import "Leaderboard.h"
#import <QuartzCore/QuartzCore.h>

@implementation UrFeats

@synthesize uid,mid;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)createGhostsMedals:(NSArray*)names descriptions:(NSArray*)descs {
	if ([names count]!=[descs count]) {
		NSLog(@"Uneven number of medal names, descriptions");
		return;
	}
	for (int i=0;i<[names count];i++) {
		[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:
						  [names objectAtIndex:i],@"name",
						  [descs objectAtIndex:i],@"description",
						  @"Medals",@"head",
						  ([Misc artTest]?nil:@"medals Ghost"),@"image",
						  nil]];
	}
}

- (void)refreshAll {
	NSLog(@"%@",uid);
	NSString *p = [NSString stringWithFormat:
				   @"&uid=%@",
				   [uid urlEncode]];
	
	[kuipp formTo:@"selectUrFeats" WithPost:p];
}


- (void)refresh:(id)obj {
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	if ([Misc artTest]) [dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Early Adopter",@"name",@"Congratulations for signing up and referring 3 people!",@"description",@"Medals",@"head",nil]];
	
	[self createGhostsMedals:medNames descriptions:medDescs];
	
	[self splitData];
	
	[self reloadView];
}

- (void)splitData {
	[medals release];
	medals = [[NSMutableArray alloc]init];
	NSMutableDictionary *m = [[NSMutableDictionary alloc]init];

	for (NSDictionary *d in dicts) {
		NSString *s = [d objectForKey:@"head"];
		if ([s isEqualToString:@"Medals"]) {
			NSString *name = [d objectForKey:@"name"];
			if ([m objectForKey:name]==nil) [m setObject:d forKey:name];
		}
	}
	
	for (NSString *s in medNames) {
		NSMutableDictionary *md = [NSMutableDictionary dictionaryWithDictionary:[m objectForKey:s]];
		if (![md objectForKey:@"image"]) {
			[md setObject:[NSString stringWithFormat:@"medals %@",[md objectForKey:@"name"]]forKey:@"image"];
		}
		if (![[md objectForKey:@"name"]isEqualToString:@"Early Adopter"]||![[md objectForKey:@"image"]isEqualToString:@"medals Ghost"]) {
			[medals addObject:md];
		}
	}
	
	[m release];
}

- (void)reloadView {[self reloadScroll];}

- (void)reloadScroll {
	double h = scroll.frame.size.height;
	double bdr = [Misc border];
	double buf = [Misc buffer];
	double ttl = [Misc heightForFontSize:[Misc footSize]];
	double med = h-ttl-bdr*2; //[Misc medalSize];
	
	for (int i=0;i<[medals count];i++) {
		NSDictionary *m = [medals objectAtIndex:i];
		UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
		b.frame= CGRectMake(buf+i*(med+buf),0,med,med);
		b.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[b setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@ small",[m objectForKey:@"image"]]]forState:UIControlStateNormal];
		UILabel *l = [[UILabel alloc]init];
		l.font = [UIFont systemFontOfSize:[Misc footSize]];
		l.textColor = [UIColor darkGrayColor];
		l.backgroundColor = [UIColor clearColor];
		l.textAlignment = UITextAlignmentCenter;
		l.frame = CGRectMake(buf+i*(med+buf),med+bdr,med,ttl);
		l.text = [m objectForKey:@"name"];
		
		b.tag = i;
		
		[b addTarget:self action:@selector(displayMedal:) forControlEvents:UIControlEventTouchUpInside];
		
		[scroll addSubview:b];
		[scroll addSubview:l];
		[l release];
	}
	
	scroll.contentSize = CGSizeMake(buf+[medals count]*(med+buf),scroll.frame.size.height);
	
	if ([medals count]>0) {
		UIButton *dummy = [UIButton buttonWithType:UIButtonTypeCustom];
		dummy.tag = mid;
		[self displayMedal:dummy];
	}
}

- (void)displayMedal:(UIButton*)sender {
	mid = sender.tag;
	NSDictionary *m = [medals objectAtIndex:sender.tag];
	image.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@ large",[m objectForKey:@"image"]]];
	text.text = [m objectForKey:@"description"];
	
	double bdr = [Misc border];
	double buf = [Misc buffer];
	double svh = scrollV.frame.size.height;
	double sch = scroll.frame.size.height;
	double w = self.view.frame.size.width-buf*4;
	double txh = [Misc heightForText:text.text width:w size:[Misc mainSize]]+buf*2;
	double imh = svh-sch-txh-buf*3-bdr;
	double imy = buf*2;
	
	if ([[m objectForKey:@"image"]isEqualToString:@"medals Ghost"]) {
		double nmh = [Misc heightForFontSize:[Misc profileNameSize]];
		imy += nmh+buf;
		imh -= nmh+buf;
		mName.text = [m objectForKey:@"name"];
	} else {
		mName.text = @"";
	}
	
	text.frame = CGRectMake(buf*2,svh-sch-txh,w,txh);
	
	if (divider==nil) {
		divider = [[UIView alloc]init];
		divider.backgroundColor = [UIColor darkGrayColor];
		[scrollV insertSubview:divider belowSubview:text];
	}
	divider.frame = CGRectMake(0,svh-sch-txh-bdr,w+buf*4,bdr+txh);
	
	imageV.frame = CGRectMake(buf*2,imy,w,imh);
}

#pragma mark -
#pragma mark Initialization
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	[Misc load:self];
	
	text.numberOfLines = 0;
	text.font = [UIFont systemFontOfSize:[Misc mainSize]];
	text.textColor = [Misc kuippOrangeColor];
	
	double buf = [Misc buffer];
	double w = self.view.frame.size.width-buf*4;
	double nmh = [Misc heightForFontSize:[Misc profileNameSize]];
	mName.frame = CGRectMake(buf*2, buf*2, w, nmh);
	mName.font = [UIFont boldSystemFontOfSize:[Misc profileNameSize]];
	mName.backgroundColor = [UIColor clearColor];
	mName.textColor = [Misc kuippOrangeColor];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	medNames = [[[Misc medalNames]arrayByAddingObjectsFromArray:[Misc advNames]]retain];
	medDescs = [[[Misc medalDescs]arrayByAddingObjectsFromArray:[Misc advDescs]]retain];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	[self refreshAll];
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[medNames release];
	[medDescs release];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return [Misc orientations:interfaceOrientation];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[uid release];
	scroll.delegate = nil;
	
    [super dealloc];
}

@end
