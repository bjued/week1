//
//  Medals.m
//  Kuipp
//
//  Created by Brandon Jue on 2/4/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "Medals.h"
#import "KuippConnect.h"
#import "Parser.h"

@implementation Medals

@synthesize uid;

- (IBAction)popBack:(UIButton*)sender {
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)refresh:(UIButton*)sender {
	/*
	NSURLResponse *response;
	NSError *error;
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=%@",
							uid];
	
	NSString *urlContents = [KuippConnect formTo:@"selectMedals" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:1]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode forView:self]) return;
	
	if (dicts!=nil) [dicts release];
	if (heads!=nil) [heads release];
	dicts = [[NSMutableArray alloc]init];
	heads = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts AndHeads:heads];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	*/
	
	dicts = [[NSMutableArray alloc]init];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"NYI.png",@"image",@"object #1",@"description",nil]];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"profile.png",@"image",@"object #2",@"description",nil]];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"settings.png",@"image",@"object #3",@"description",nil]];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Complete.png",@"image",@"object #4",@"description",nil]];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"connections.png",@"image",@"object #5",@"description",nil]];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"RedPin.png",@"image",@"object #6",@"description",nil]];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"BluePin.png",@"image",@"object #7",@"description",nil]];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"mail.png",@"image",@"object #8",@"description",nil]];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"MyKuipps.png",@"image",@"object #9",@"description",nil]];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"kuippit.png",@"image",@"object #10",@"description",nil]];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"YellowPin.png",@"image",@"object #11",@"description",nil]];
	[dicts addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"InProgress.png",@"image",@"object #12",@"description",nil]];
	
	for (int i=0;i<[dicts count];i++) {
		NSDictionary *medal = [dicts objectAtIndex:i];
		UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
		button.frame= CGRectMake(16+(i%4)*76,16+i/4*76,60,60);
		[button setBackgroundImage:[UIImage imageNamed:[medal objectForKey:@"image"]] forState:UIControlStateNormal];
		
		[button setTitle:[NSString stringWithFormat:@"%d",i] forState:UIControlStateNormal];
		[button setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
		
		[button addTarget:self action:@selector(overlay:) forControlEvents:UIControlEventTouchUpInside];
		[scroll addSubview:button];
	}
}

- (void)overlay:(id)sender {
	NSDictionary *dict = [dicts objectAtIndex:[[sender titleForState:UIControlStateNormal]intValue]];
	
	overlay.frame = CGRectMake(8,44,overlay.frame.size.width,overlay.frame.size.height);
	image.image = [UIImage imageNamed:[dict objectForKey:@"image"]];
	text.text = [dict objectForKey:@"description"];
	
	[self.view addSubview:overlay];
}

- (IBAction)done:(UIButton*)sender {
	[overlay removeFromSuperview];
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/
/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/
- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[self refresh:nil];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[uid release];
	
    [super dealloc];
}

@end
