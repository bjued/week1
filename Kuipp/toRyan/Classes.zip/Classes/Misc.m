//
//  Misc.m
//  Kuipp
//
//  Created by Brandon Jue on 2/26/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "Misc.h"
#import "RefreshCell.h"

@implementation NSString (URLEncoding)

- (NSString*)urlEncodeUsingEncoding:(NSStringEncoding)encoding {
	return (NSString *)CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)self, NULL, (CFStringRef)@"!*'\"();:@&=+$,/?%#[]% ", CFStringConvertNSStringEncodingToEncoding(encoding));
}

- (NSString*)urlEncode {
	return [self urlEncodeUsingEncoding:NSUTF8StringEncoding];
}

- (NSString*)shortURLEncode {
	return [[self urlEncode]stringByReplacingOccurrencesOfString:@"\%20" withString:@"+"];
}

@end

@implementation Misc

#pragma mark Debug

+ (int)test {
	//return 0; //public
	//return 1; //beta
	return 2; //test
}

+ (BOOL)beta {return [Misc test]==1;}

+ (BOOL)debug {return [Misc test]==2;}

+ (BOOL)artTest {return [Misc debug]&&NO;}

+ (NSString*)url {
	/*
	if ([Misc debug]) return @"http://184.73.238.93/test";
	if ([Misc beta]) return @"http://184.73.238.93/beta";
	return @"http://184.73.238.93/pub";
	 */
	///*
	if ([Misc debug]) return @"http://kuipp.com/test";
	if ([Misc beta]) return @"http://kuipp.com/beta";
	return @"http://kuipp.com/pub";
	//*/
}

#pragma mark Constants

+ (NSString*)partyLevel:(int)i {
	switch (i) {
		case  2: return @"Class";
		case  3: return @"School";
		case  4: return @"College";
		case  5: return @"Fellowship";
		default: return @"Party";
	}
}

+ (NSString*)partyLeader:(int)i {
	switch (i) {
		case  2: return @"Teacher";
		case  3: return @"Principal";
		case  4: return @"Channcellor";
		case  5: return @"Regent";
		default: return @"Leader";
	}
}

+ (int)maxPartySize {return 5;}

+ (NSString*)profileTutorialTitle:(int)i {
	switch (i) {
		case  0: return @"Edit Your Bio!";
		case  1: return @"Adjust Your Photo!";
		case  2: return @"Add Your Interests!";
		case  3: return @"You're all set!";
		default: return @"";
	}
}

+ (NSString*)profileTutorialMessage:(int)i {
	switch (i) {
		case  0: return @"Tell everyone a little about yourself!\n\nEdit your bio now?";
		case  1: return @"Center yourself, or whatever you want!\n\nAdjust your photo now?";
		case  2: return @"Track things you are interested in!\n\nAdd your interests!";
		case  3: return @"Now it's time to ask and answer questions to raise your Influence and achieve those medals!";
		default: return @"";
	}
}

+ (double)adjustPictureRatio {return 2;}

+ (NSString*)defaultEditBio {return @"I'm a: ... (Hey! Click here to fill out the rest!)";}

+ (NSString*)defaultNoBio {return @"I'm a: ... (Hey! Bug me to find out what I am!)";}

+ (NSArray*)advNames {
	return [NSArray arrayWithObjects:
			@"Arts Advisor",
			@"Dating & Relationships Advisor",
			@"Food, Drink & Lifestyle Advisor",
			@"Life & Society Advisor",
			@"Local News & Events Advisor",
			@"Music & Performances Advisor",
			@"Night Life Advisor",
			@"Sports & Recreation Advisor",
			@"Traffic Advisor",
			@"Weather Advisor",
			@"Expert Advisor",
			@"Jack Of All Trades",nil];
}

+ (NSArray*)advDescs {
	return [NSArray arrayWithObjects:
			@"Answer 50 questions with 100 net likes in Arts",
			@"Answer 50 questions with 100 net likes in Dating & Relationships",
			@"Answer 50 questions with 100 net likes in Food, Drink & Lifestyle",
			@"Answer 50 questions with 100 net likes in Life & Society",
			@"Answer 50 questions with 100 net likes in Local News & Events",
			@"Answer 50 questions with 100 net likes in Music & Performances",
			@"Answer 50 questions with 100 net likes in Night Life",
			@"Answer 50 questions with 100 net likes in Sports & Recreation",
			@"Answer 50 questions with 100 net likes in Traffic",
			@"Answer 50 questions with 100 net likes in Weather",
			@"Obtain 4 Advisor Medals",
			@"Obtain 8 Advisor Medals",nil];
}

+ (NSArray*)medalNames {
	return [NSArray arrayWithObjects:
			@"Early Adopter",
			@"Entourage",
			@"Crew",
			@"Crowd",
			@"Popular",
			@"Celebrity",
			@"Appeal",
			@"Public Figure",
			@"Debater",
			@"Responder",
			@"Rapid Fire",
			@"Answer Fiend",
			@"Cowboy",
			@"Volleyer",
			@"Slingshot",
			@"911 Dispatcher",
			//@"Nomad",
			//@"Traveler",
			//@"Jetsetter",
			//@"Worldy",
			@"Focused",
			@"Rapid",
			@"Realtime",
			nil];
}

+ (NSArray*)medalDescs {
	return [NSArray arrayWithObjects:
			@"Sign up and refer 3 people to the Kuipp mailing list before launch",
			@"Obtain 10 Followers",
			@"Obtain 50 Followers",
			@"Obtain 100 Followers",
			@"Obtain 250 Followers",
			@"Obtain 500 Followers",
			@"Get 5 responses for 5 consecutive questions",
			@"Get 10 responses for 5 consecutive questions",
			@"Get 15 responses for 5 consecutive questions",
			@"Respond to 25 questions within 24 hours",
			@"Respond to 25 questions within 60 minutes",
			@"Respond to 25 questions within 15 minutes",
			@"Respond to 1 question within 2 minutes of posting",
			@"Respond to 5 questions within 2 minutes of posting",
			@"Respond to 10 questions within 2 minutes of posting",
			@"Respond to 15 questions within 2 minutes of posting",
			//@"Ask 3 questions at least 300 miles apart",
			//@"Ask 2 questions on different continents",
			//@"Ask 3 questions on different continents",
			//@"Ask 4 questions on different continents",
			@"Ask or Answer at least 20 questions in a day",
			@"Ask or Answer at least 50 questions in a day",
			@"Ask or Answer at least 100 questions in a day",
			nil];
}

+ (BOOL)tableHideHeaderAnimated {return YES;}

+ (NSString*)defaultProfileURL {return @"http://kuipp.com/profilepictures/default.png";}

+ (UIImage*)defaultProfile {return [UIImage imageNamed:@"profile_default"];}

+ (double)locationWithinTime {return 3.0;}

+ (int)locationTries {return 3;}

+ (UIViewContentMode)imageFitStyle {return UIViewContentModeScaleAspectFit;}

+ (UIColor*)kuippOrangeColor {return [UIColor colorWithRed:251.0/255.0 green:176.0/255.0 blue:64.0/255.0 alpha:1.0];}

+ (UIColor*)selectedColor {return [UIColor colorWithRed:121.0/255.0 green:203.0/255.0 blue:191.0/255.0 alpha:1];}

+ (int)geocodeInterval {return 60;}

+ (double)footSize {return 10;}

+ (double)mainSize {return 12;}

+ (double)nameSize {return 14;}

+ (double)profileNameSize {return 17;}

+ (double)buttonFontSize {return 12;}

+ (double)border {return 1;}

+ (double)borderCurve {return 5;}

+ (double)buffer {return 5;}

+ (double)imageSize {return 72;}

+ (double)medalSize {return 55;}

+ (double)leaderSize {return 44;}

+ (double)profileSize {return 130;}

+ (double)profMedSize {return 65;}

+ (double)buttonCellHeight {return [UIImage imageNamed:@"buttonCell"].size.height;}

+ (UIImage*)buttonCell {return [[UIImage imageNamed:@"buttonCell"]stretchableImageWithLeftCapWidth:10 topCapHeight:10];}

+ (double)refreshCellHeight {return 60;}

+ (RefreshCell*)refreshCellView {return [[[RefreshCell alloc]init]autorelease];}

+ (UIActivityIndicatorView*)activityView {return [[[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite]autorelease];}

+ (int)maxCharacters {return 150;}

+ (double)animations {return .3;}

+ (BOOL)orientations:(UIInterfaceOrientation)orient {return orient==UIDeviceOrientationPortrait;}

+ (NSArray*)facebookPermissions {return [NSArray arrayWithObjects:@"offline_access",@"email",@"publish_stream",nil];}

+ (UIImageView*)logoBar {
	UIImage *i = [UIImage imageNamed:@"Kuipp NavBarLogo"];
	UIImageView *v = [[[UIImageView alloc]initWithImage:i]autorelease];
	return v;
}

+ (UITextField*)cellPasswordField:(id)delegate {
	UITextField *f = [[[UITextField alloc]init]autorelease];
	f.delegate = delegate;
	f.clearsOnBeginEditing = YES;
	f.textAlignment = UITextAlignmentCenter;
	f.font = [f.font fontWithSize:12];
	f.borderStyle = UITextBorderStyleNone;
	f.frame = CGRectMake(20,4,260,22);
	f.clearButtonMode = UITextFieldViewModeWhileEditing;
	f.secureTextEntry = YES;
	f.keyboardAppearance = UIKeyboardAppearanceAlert;
	f.returnKeyType = UIReturnKeyNext;
	return f;
}

+ (UITextField*)cellTextField:(id)delegate {
	UITextField *f = [[[UITextField alloc]init]autorelease];
	f.delegate = delegate;
	f.clearsOnBeginEditing = YES;
	f.textAlignment = UITextAlignmentCenter;
	f.font = [f.font fontWithSize:12];
	f.borderStyle = UITextBorderStyleBezel;
	f.frame = CGRectMake(180,4,60,22);
	f.clearButtonMode = UITextFieldViewModeWhileEditing;
	return f;
}

#pragma mark -
#pragma mark Methods

static CGRect swapWidthAndHeight(CGRect rect) {
    CGFloat  swap = rect.size.width;
    
    rect.size.width  = rect.size.height;
    rect.size.height = swap;
    
    return rect;
}

+ (UIImage*)imageWithImage:(UIImage*)image scaledToSize:(CGSize)newSize fromSection:(CGRect)oldRect {
	// Rotate image
	UIImageOrientation orient = image.imageOrientation;
	CGRect             bnds = CGRectZero;
    CGContextRef       ctxt = nil;
    CGImageRef         imag = image.CGImage;
    CGRect             rect = CGRectZero;
    CGAffineTransform  tran = CGAffineTransformIdentity;
	
    rect.size.width  = CGImageGetWidth(imag);
    rect.size.height = CGImageGetHeight(imag);
    
    bnds = rect;
    
    switch (orient) {
        case UIImageOrientationUpMirrored:
			tran = CGAffineTransformMakeTranslation(rect.size.width, 0.0);
			tran = CGAffineTransformScale(tran, -1.0, 1.0);
			break;
        case UIImageOrientationDown:
			tran = CGAffineTransformMakeTranslation(rect.size.width,rect.size.height);
			tran = CGAffineTransformRotate(tran, M_PI);
			break;
        case UIImageOrientationDownMirrored:
			tran = CGAffineTransformMakeTranslation(0.0, rect.size.height);
			tran = CGAffineTransformScale(tran, 1.0, -1.0);
			break;
        case UIImageOrientationLeft:
			bnds = swapWidthAndHeight(bnds);
			tran = CGAffineTransformMakeTranslation(0.0, rect.size.width);
			tran = CGAffineTransformRotate(tran, 3.0 * M_PI / 2.0);
			break;
        case UIImageOrientationLeftMirrored:
			bnds = swapWidthAndHeight(bnds);
			tran = CGAffineTransformMakeTranslation(rect.size.height,rect.size.width);
			tran = CGAffineTransformScale(tran, -1.0, 1.0);
			tran = CGAffineTransformRotate(tran, 3.0 * M_PI / 2.0);
			break;
        case UIImageOrientationRight:
			bnds = swapWidthAndHeight(bnds);
			tran = CGAffineTransformMakeTranslation(rect.size.height, 0.0);
			tran = CGAffineTransformRotate(tran, M_PI / 2.0);
			break;
        case UIImageOrientationRightMirrored:
			bnds = swapWidthAndHeight(bnds);
			tran = CGAffineTransformMakeScale(-1.0, 1.0);
			tran = CGAffineTransformRotate(tran, M_PI / 2.0);
			break;
        default: break;
    }
	
    UIGraphicsBeginImageContext(bnds.size);
    ctxt = UIGraphicsGetCurrentContext();
	
    switch (orient){
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
			CGContextScaleCTM(ctxt, -1.0, 1.0);
			CGContextTranslateCTM(ctxt, -rect.size.height, 0.0);
			break;
        default:
			CGContextScaleCTM(ctxt, 1.0, -1.0);
			CGContextTranslateCTM(ctxt, 0.0, -rect.size.height);
			break;
    }
	
    CGContextConcatCTM(ctxt, tran);
    CGContextDrawImage(UIGraphicsGetCurrentContext(), rect, imag);
    
    image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();

	// Crop image
	CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], oldRect);
	image = [UIImage imageWithCGImage:imageRef];
	CGImageRelease(imageRef);
	
	// Resize image
	UIGraphicsBeginImageContext(newSize);
	[image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
	image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	return image;
}

+ (BOOL)validEmail:(NSString*)email {
	NSString *regEx =
    @"(?:[a-z0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[a-z0-9!#$%\\&'*+/=?\\^_`{|}"
    @"~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\"
    @"x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-"
    @"z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5"
    @"]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-"
    @"9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21"
    @"-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";
	
	NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regEx];
	return [pred evaluateWithObject:email];
}

+ (UIButton*)createToggle:(NSString*)img {
	UIButton* button = [UIButton buttonWithType:UIButtonTypeCustom];
	UIImage *i = [UIImage imageNamed:img];
	UIImage *i2 = [UIImage imageNamed:[img stringByAppendingString:@" toggled"]];
	[button setBackgroundImage:i2 forState:UIControlStateNormal];
	[button setBackgroundImage:i forState:UIControlStateSelected];
	button.frame = CGRectMake(0,0,i.size.width,i.size.height);
	button.tag = 0;
	button.selected = NO;
	return button;
}

+ (NSString*)base85to10:(NSString*)n {
	NSString* base85 = @"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@&%?,=[]_:-+.*$#!'^();~";
	int multiplier = 1;
	
	int base10 = 0;
	
	for (int i=[n length];i>0;i--) {
		NSString *ch = [[n substringToIndex:i]substringFromIndex:i-1];
		NSRange r = [base85 rangeOfString:ch];
		base10 += multiplier*r.location;
		multiplier *= 85;
	}
	
	return [[[NSString alloc]initWithFormat:@"%d",base10]autorelease];
}

+ (NSString*)newVersion:(NSString*)v WithBuild:(NSString*)b {
	NSString *one = @"You are using Kuipp ";
	NSString *two = @"The latest version is Kuipp ";
	NSString *three = @"Some features may not work until you update.";
	
	if (b) return [[NSString stringWithFormat:@"%@%@.%@.\n\n%@%@.%@.\n\n%@",one,[[NSBundle mainBundle]objectForInfoDictionaryKey:@"CFBundleShortVersionString"],[[NSBundle mainBundle]objectForInfoDictionaryKey:@"CFBundleVersion"],two,v,b,three]retain];
	else return [[NSString stringWithFormat:@"%@%@.\n\n%@%@.%@.\n\n%@",one,[[NSBundle mainBundle]objectForInfoDictionaryKey:@"CFBundleShortVersionString"],two,v,three]retain];
}

+ (void)firstTime:(NSString*)p {
	NSUserDefaults *s = [NSUserDefaults standardUserDefaults];
	NSString *u = [s objectForKey:@"userID"];
	NSString *key = [NSString stringWithFormat:@"firstTime%@%@",u,p];
	if ([s objectForKey:key]) return;
	
	NSString *ttl = [NSString stringWithFormat:@"Welcome to your %@!",p];
	NSString *msg = @"";
	if ([p isEqualToString:@"Settings"]) {
		msg = @"Find friends on Kuipp!\n\nEdit your local and push messages";
	} else if ([p isEqualToString:@"Profile"]) {
		msg = @"Edit your bio\n Adjust your photo\nAdd your interests\n\nAsk and answer away to boost your Influence!";
	} else if ([p isEqualToString:@"Feats"]) {
		msg = @"View updates, medals earned, and how you compare with others!";
	} else if ([p isEqualToString:@"Answer Tab"]) {
		msg = @"View questions filtered by location, users you're following, or keywords";
	} else if ([p isEqualToString:@"Ask Tab"]) {
		msg = @"Please select a location to ask or use your current location";
	}
	if (![msg isEqualToString:@""]) {
		[s setObject:@"1" forKey:key];
		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:ttl message:msg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
}

+ (void)locationDenied {
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Oops!"
						  message:@"This feature requires location data and it appears you haven't given Kuipp permission!\n\nPlease give Kuipp permission to use location servies at:\n\nSettings > General > Location Services"
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
}

+ (void)locationFailed {
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Oops!"
						  message:[NSString stringWithFormat:@"We failed to determine your location after %d tries, please try again later.",[Misc locationTries]]
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
}

+ (void)fitMapAnnotations:(MKMapView*)mapView {
    if([mapView.annotations count]==0) return;
	
    CLLocationCoordinate2D topLeftCoord;
    topLeftCoord.latitude = -90;
    topLeftCoord.longitude = 180;
	
	double maxLat = -90;
	double maxLon = -180;
	double minLat = 90;
	double minLon = 180;
	
    CLLocationCoordinate2D bottomRightCoord;
    bottomRightCoord.latitude = 90;
    bottomRightCoord.longitude = -180;
	
    for(id<MKAnnotation> ann in mapView.annotations) {
        minLat = fmin(minLat,ann.coordinate.latitude);
        maxLat = fmax(maxLat,ann.coordinate.latitude);
        minLon = fmin(minLon,ann.coordinate.longitude);
        maxLon = fmax(maxLon,ann.coordinate.longitude);
    }
	
    MKCoordinateRegion region;
    region.center.latitude = maxLat-(maxLat-minLat) * 0.5;
    region.center.longitude = minLon+(maxLon-minLon) * 0.5;
	
    region.span.latitudeDelta = fmax(.01,fabs(maxLat-minLat) * 1.1);
    region.span.longitudeDelta = fmax(.01,fabs(maxLon-minLon) * 1.1);
	
	[mapView regionThatFits:region];
	[mapView setRegion:region animated:YES];
}

+ (void)centerMapView:(MKMapView*)map onLoc:(CLLocationCoordinate2D)loc withSpan:(double)sp {
	MKCoordinateRegion region = map.region;
	region.span.longitudeDelta = sp;
	region.span.latitudeDelta = sp;
	
	region.center.latitude = fmin(90,fmax(-90,loc.latitude));
	region.center.longitude = fmin(180,fmax(-180,loc.longitude));
	
	[map setRegion:region animated:YES];
	[map regionThatFits:region];
}

+ (NSString*)reverseGeocode:(MKPlacemark*)placemark {
	/* administrativeArea = State (CA or California)
	 * country = Country (United States)
	 * countryCode = Country Abbreviation (US)
	 * locality = City (Cupertino)
	 * postalCode = Zip Code (95014)
	 * subAdministrativeArea = County (Santa Clara)
	 * subLocality = Neighborhood or Landmark
	 * subThoroughfare = Street Number (1)
	 * thoroughfare = Street (Infinite Loop)
	 */
	return placemark.locality;
}

+ (UIControl*)leftPin:(NSDictionary*)d {
	UIControl *ctrl = [[[UIControl alloc]init]autorelease];
	ctrl.clipsToBounds = YES;
	ctrl.backgroundColor = [UIColor clearColor];
	[ctrl addTarget:[Misc class]action:@selector(blueCover:) forControlEvents:UIControlEventTouchDown|UIControlEventTouchDragInside];
	[ctrl addTarget:[Misc class]action:@selector(noCover:) forControlEvents:UIControlEventTouchDragOutside|UIControlEventTouchUpInside];
	ctrl.tag = 1;
	
	ctrl.frame = CGRectMake(0,0,32,32);
	
	UIImageView *left = [[UIImageView alloc]init];
	left.image = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images objectForKey:[d objectForKey:@"picture"]];
	left.clipsToBounds = YES;
	left.contentMode = [Misc imageFitStyle];
	left.backgroundColor = [UIColor clearColor];
	left.userInteractionEnabled = NO;
	
	BOOL b = [left.image isEqual:[Misc defaultProfile]];
	double r = 32.0/[Misc profileSize];
	int picX = [[d objectForKey:@"picX"]intValue]*r;
	int picY = [[d objectForKey:@"picY"]intValue]*r;
	double picZ = [[d objectForKey:@"picZ"]doubleValue]*r;
	CGSize picS = left.image.size;
	left.frame = CGRectMake(b?0:picX, b?0:picY, b?32:picS.width*picZ, b?32:picS.height*picZ);
	
	[ctrl addSubview:left];
	[left release];
	
	return ctrl;
}

+ (UIControl*)rightPin:(NSString*)img {
	UIControl *ctrl = [[[UIControl alloc]init]autorelease];
	ctrl.frame = CGRectMake(0,0,30,30);
	ctrl.tag = 2;
	
	UIImageView *right = [[UIImageView alloc]init];
	right.image = [UIImage imageNamed:img];
	right.frame = ctrl.frame;
	
	[ctrl addSubview:right];
	[right release];
	
	return ctrl;
}

+ (void)load:(UIViewController*)delegate {
	delegate.view.backgroundColor = [Misc bgColor];
	
	delegate.navigationItem.titleView = [Misc logoBar];
	
	if (delegate!=[[delegate.navigationController viewControllers]objectAtIndex:0]) {
		delegate.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
		[(UIButton*)delegate.navigationItem.leftBarButtonItem.customView addTarget:delegate action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	}
	
	delegate.navigationItem.hidesBackButton = YES;
}

+ (UIImageView*)detailDisclosure {return [[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"detail"]]autorelease];}

+ (UIImageView*)detailExpanded {return [[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"detail expanded"]]autorelease];}

+ (UIImageView*)checkmark {return [[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"checkmark"]]autorelease];}

+ (UIImageView*)checkmarkPlaceholder {return [[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"checkmark placeholder"]]autorelease];}

+ (UIColor*)barColor {return [UIColor colorWithPatternImage:[UIImage imageNamed:@"tertiary"]];}

+ (UIColor*)bgColor {return [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg"]];}

+ (UIBarButtonItem*)mapList:(int)tab {return [Misc barButtonItemViewWithTitle:tab==0?@"List":@"Map"];}

+ (UIBarButtonItem*)pointBarButtonItem:(NSString*)title {
	UIImage *i = [[UIImage imageNamed:@"point icon"]stretchableImageWithLeftCapWidth:15 topCapHeight:10];
	
	UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
	[b setBackgroundImage:i forState:UIControlStateNormal];
	[b setTitle:[NSString stringWithFormat:@" %@",title]forState:UIControlStateNormal];
	[b setTitleColor:[UIColor darkGrayColor]forState:UIControlStateNormal];
	b.titleLabel.font = [UIFont boldSystemFontOfSize:[Misc buttonFontSize]];
	
	CGSize s = [title sizeWithFont:b.titleLabel.font];
	double w = s.width;
	
	b.frame = CGRectMake(0,0,w+[Misc buffer]*5,29);
	
	UIBarButtonItem *button = [[[UIBarButtonItem alloc]initWithCustomView:b]autorelease];
	
	return button;
}

+ (UIBarButtonItem*)barButtonItemViewWithTitle:(NSString*)title {
	UIImage *i = [[UIImage imageNamed:@"plain icon"]stretchableImageWithLeftCapWidth:10 topCapHeight:10];
	
	UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
	[b setBackgroundImage:i forState:UIControlStateNormal];
	[b setTitle:title forState:UIControlStateNormal];
	[b setTitleColor:[UIColor darkGrayColor]forState:UIControlStateNormal];
	b.titleLabel.font = [UIFont boldSystemFontOfSize:[Misc buttonFontSize]];
	
	CGSize s = [title sizeWithFont:b.titleLabel.font];
	double w = s.width;
	
	b.frame = CGRectMake(0,0,w+[Misc buffer]*4,29);
	
	UIBarButtonItem *button = [[[UIBarButtonItem alloc]initWithCustomView:b]autorelease];
	
	return button;
}

+ (UIBarButtonItem*)barButtonItemViewWithImage:(NSString*)img {
	UIImage *i = [UIImage imageNamed:img];
	
	UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
	[b setImage:i forState:UIControlStateNormal];
	
	b.frame = CGRectMake(0,0,i.size.width,i.size.height);
	
	UIBarButtonItem *button = [[[UIBarButtonItem alloc]initWithCustomView:b]autorelease];
	
	return button;
}

+ (UIImage*)roundTeal {return [[UIImage imageNamed:@"tealbutton"]stretchableImageWithLeftCapWidth:10 topCapHeight:10];}

+ (UIImage*)wideTabImage:(BOOL)b {return [UIImage imageNamed:b?@"tertiary selected wide":@"tertiary"];}

+ (UIImage*)tabImage:(BOOL)b {return [UIImage imageNamed:b?@"tertiary selected":@"tertiary"];}

+ (double)heightForFontSize:(double)i {
	UILabel *l = [[[UILabel alloc]init]autorelease];
	l.text = @"1";
	l.font = [UIFont systemFontOfSize:i];
	[l sizeToFit];
	return l.frame.size.height;
}

+ (double)heightForText:(NSString*)s width:(double)w size:(double)i {
	// count newlines
	NSArray *newlines = [s componentsSeparatedByString:@"\n"];
	
	// variables
	double ht = [Misc heightForFontSize:i];
	
	UILabel *l = [[[UILabel alloc]init]autorelease];
	l.text = s;
	l.font = [UIFont systemFontOfSize:i];
	l.numberOfLines = 0;
	l.lineBreakMode = UILineBreakModeWordWrap;
	l.frame = CGRectMake(0,0,w,ht*[Misc maxCharacters]);
	[l sizeToFit];
	
	return fmax(ht*[newlines count],l.frame.size.height);
}

+ (void)noCover:(UIControl*)sender {
	sender.backgroundColor = [UIColor clearColor];
	sender.alpha = 1;
}

+ (void)blueCover:(UIControl*)sender {
	sender.backgroundColor = [UIColor blueColor];
	sender.alpha = .25;
}

+ (void)whiteCover:(UIControl*)sender {
	sender.backgroundColor = [UIColor whiteColor];
	sender.alpha = 1;
}

+ (NSString*)nameFromDict:(NSDictionary*)d {
	if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue]==[[d objectForKey:@"userID"]intValue]) return @"You";
	NSString* first = [d objectForKey:@"firstName"];
	NSString* last = [d objectForKey:@"lastName"];
	return [Misc first:first lastName:last];
}

+ (NSString*)first:(NSString*)first lastName:(NSString*)last {
	first = (first&&[first length]>0)?[[[first substringToIndex:1]uppercaseString]stringByAppendingString:[first substringFromIndex:1]]:@"";
	last = (last&&[last length]>0)?[[[last substringToIndex:1]uppercaseString]stringByAppendingString:@"."]:@"";
	return [NSString stringWithFormat:@"%@ %@",first,last];
}

+ (NSString*)first:(NSString*)first lastName:(NSString*)last otherText:(NSString*)text {return [NSString stringWithFormat:@"%@%@",[Misc first:first lastName:last],text?text:@""];}

+ (NSString*)timeSinceNow:(NSString*)date {
	// Find timeSince (choose to use year, day, hour, minute, second)
	NSTimeInterval seconds = [[NSDate dateWithTimeIntervalSince1970:[date intValue]]timeIntervalSinceNow] * -1;
	int time = fmax(0,(int)seconds);
	if (time/60/60/24/365>0) {
		int t = time/60/60/24/365;
		return [NSString stringWithFormat:@"%d year%@ ago",t,t==1?@"":@"s"];
	} else if (time/60/60/24>0) {
		int t = time/60/60/24;
		return [NSString stringWithFormat:@"%d day%@ ago",t,t==1?@"":@"s"];
	} else if (time/60/60>0) {
		int t = time/60/60;
		return [NSString stringWithFormat:@"%d hour%@ ago",t,t==1?@"":@"s"];
	} else if (time/60>0) {
		int t = time/60;
		return [NSString stringWithFormat:@"%d minute%@ ago",t,t==1?@"":@"s"];
	} else {
		return [NSString stringWithFormat:@"%d second%@ ago",time,time==1?@"":@"s"];
	}
}

+ (void)updateUserSettings:(NSDictionary*)d {
	NSUserDefaults *save = [NSUserDefaults standardUserDefaults];
	NSMutableDictionary *md;
	
	for (NSString *key in [d allKeys]) {
		if ([key isEqualToString:@"local"]||
			[key isEqualToString:@"recent"]) {
			md = [NSMutableDictionary dictionaryWithDictionary:[save objectForKey:@"locationTime"]];
			[md setObject:[d objectForKey:key]forKey:key];
			[save setObject:md forKey:@"locationTime"];
		} else if ([key isEqualToString:@"forward"]||
				   [key isEqualToString:@"visible"]) {
			md = [NSMutableDictionary dictionaryWithDictionary:[save objectForKey:@"findConnections"]];
			[md setObject:[d objectForKey:key]forKey:key];
			[save setObject:md forKey:@"findConnections"];
		} else if ([key isEqualToString:@"AMyQ"]||
				   [key isEqualToString:@"AFQ"]||
				   [key isEqualToString:@"CMyA"]||
				   [key isEqualToString:@"FMe"]||
				   [key isEqualToString:@"MMe"]||
				   [key isEqualToString:@"QMyI"]||
				   [key isEqualToString:@"QAMe"]||
				   [key isEqualToString:@"QFQ"]||
				   [key isEqualToString:@"Rmnd"]) {
			md = [NSMutableDictionary dictionaryWithDictionary:[save objectForKey:@"notifications"]];
			[md setObject:[d objectForKey:key]forKey:key];
			[save setObject:md forKey:@"notifications"];
		} else {
			[save setObject:[d objectForKey:key]forKey:key];
		}
	}
}

#pragma mark -

@end
