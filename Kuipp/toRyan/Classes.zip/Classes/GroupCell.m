//
//  GroupCell.m
//  Kuipp
//
//  Created by Brandon Jue on 4/8/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "GroupCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation GroupCell

@synthesize selectable,item,label;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
		self.backgroundView = [[UIView alloc]init];
		self.backgroundView.backgroundColor = [UIColor clearColor];
		self.backgroundView.layer.masksToBounds = YES;
		
		bkgd = [[UIView alloc]init];
		bkgd.layer.masksToBounds = YES;
		bkgd.layer.cornerRadius = [Misc borderCurve];
		bkgd.layer.borderColor = [[Misc kuippOrangeColor]CGColor];
		bkgd.layer.borderWidth = [Misc border];
		
		label = [[UILabel alloc]init];
		label.backgroundColor = [UIColor clearColor];
		label.font = [UIFont systemFontOfSize:14];
		label.textColor = [UIColor darkGrayColor];
		
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		
		[self.backgroundView addSubview:bkgd];
		[self.contentView addSubview:label];
    }
    return self;
}


- (void)layoutSubviews {
	[super layoutSubviews];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}


- (void)dealloc {
	[item release];
	[label release];
	
    [super dealloc];
}


@end
