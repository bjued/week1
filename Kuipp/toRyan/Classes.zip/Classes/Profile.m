//
//  Profile.m
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "Profile.h"
#import "ProfileCell.h"
#import "LineCell.h"
#import "Inbox.h"
#import	"Connections.h"
#import "Settings.h"
#import "Interests.h"
#import "Party.h"
#import "MyQA.h"
#import "UrQA.h"
#import "Game.h"
#import "UrFeats.h"
#import "ASyncImageLoadDelegate.h"
#import <QuartzCore/QuartzCore.h>

@implementation Profile

@synthesize uid,firstTime;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)mainThreadImages {
	[images release];
	images = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images retain];
	NSString *url = [user objectForKey:@"picture"];
	NSString *pic = [images objectForKey:url];
	if (pic==nil||[pic isEqual:[Misc defaultProfile]]) {
		[images setObject:[Misc defaultProfile]forKey:url];
		if (![url isEqualToString:[Misc defaultProfileURL]]) {
			ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
			[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
		}
	}
}

- (void)aSyncImageLoaded {if(![bio isFirstResponder]) [table reloadData];}

- (void)refreshAll {
	[refreshCell refreshing];
	
	NSString *p = [NSString stringWithFormat:
				   @"&userID=%@",
				   [uid urlEncode]];
	
	[kuipp formTo:@"selectProfile" WithPost:p];
}

- (void)refresh:(id)obj {
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	[self mainThreadImages];
	
	[refreshCell refreshed];
	
	if (top.frame.origin.y<0) switch ([[user objectForKey:@"followNumber"]intValue]) {
		case 0:
			self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Follow"];
			[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(follow) forControlEvents:UIControlEventTouchUpInside];
			break;
		case 1:
			self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"UnFollow"];
			[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(unfollow) forControlEvents:UIControlEventTouchUpInside];
			break;
		default:
			break;
	}
	
	[table reloadData];
}

- (void)refreshCount {count.text = [NSString stringWithFormat:@"%d",[Misc maxCharacters]-[body.text length]];}

- (void)splitData {
	[catArray release];
	catArray = [[NSMutableArray alloc]init];
	
	for (int i=0;i<[dicts count];i++) {
		NSDictionary *d = [dicts objectAtIndex:i];
		NSString *s = [d objectForKey:@"head"];
		if ([s isEqualToString:@"Users"]) user = [[NSDictionary alloc]initWithDictionary:d];
		else if ([s isEqualToString:@"Questions"]) question = [[NSDictionary alloc]initWithDictionary:d];
		else if ([s isEqualToString:@"Answers"]) answer = [[NSDictionary alloc]initWithDictionary:d];
		else if ([s isEqualToString:@"Level"]) level = [[NSDictionary alloc]initWithDictionary:d];
		else  if ([s isEqualToString:@"Medals"]) medal = [[NSDictionary alloc]initWithDictionary:d];
		else if ([s isEqualToString:@"Categories"]) [catArray addObject:d];
	}
}

- (void)follow {
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=0&fid=%@",
							[uid urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"insertFollower" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	[del.followingIDs setObject:uid forKey:uid];
	NSLog(@"%@",del.followingIDs);
	
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Success"
						  message:[NSString stringWithFormat:@"Now following %@",[Misc first:[user objectForKey:@"firstName"]lastName:[user objectForKey:@"lastName"]]]
						  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];
	[alert release];
	[self refreshAll];
}

- (void)unfollow {
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=0&fid=%@",
							[uid urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"deleteFollowing" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	[del.followingIDs removeObjectForKey:uid];
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Success"
						  message:[NSString stringWithFormat:@"You are no longer following %@",[Misc first:[user objectForKey:@"firstName"]lastName:[user objectForKey:@"lastName"]]]
						  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];
	[alert release];
	[self refreshAll];
}

- (IBAction)sendMsg:(UIButton*)sender {
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Cancel"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Send"];
	b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(send:) forControlEvents:UIControlEventTouchUpInside];
	
	[self.view bringSubviewToFront:top];
	[self.view bringSubviewToFront:bot];
	
	to.text = [Misc first:[user objectForKey:@"firstName"]lastName:[user objectForKey:@"lastName"]];
	subject.text = @"";
	body.text = @"";
	[self refreshCount];
	
	[subject becomeFirstResponder];
}

- (IBAction)messages:(UIButton*)sender {
	Inbox *v = [[Inbox alloc]init];
	v.tab = 0;
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)connections:(UIButton*)sender {
	Connections *v = [[Connections alloc]init];
	v.tab = 0;
	//Party *v = [[Party alloc]init];
	v.uid = [[NSString alloc]initWithString:uid];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)interests:(UIButton*)sender {
	Interests *v = [[Interests alloc]init];
	v.uid = [[NSString alloc]initWithString:uid];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)activity:(UIButton*)sender {
	if ([uid intValue]==0||[uid intValue]==[[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue]) {
		MyQA *v = [[MyQA alloc]init];
		NSArray *array = [NSArray arrayWithObject:v];
		[[[self.tabBarController viewControllers]objectAtIndex:2]setViewControllers:array];
		[self.tabBarController setSelectedIndex:2];
		[v release];
	} else {
		UrQA *v = [[UrQA alloc]init];
		v.uid = [[NSString alloc]initWithString:uid];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	}
}

- (void)medals {
	if ([uid intValue]==0||[uid intValue]==[[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue]) {
		Game *v = [[Game alloc]init];
		v.fromProfile = [[NSString alloc]initWithString:@"1"];
		NSArray *array = [NSArray arrayWithObject:v];
		[[[self.tabBarController viewControllers]objectAtIndex:3]setViewControllers:array];
		[self.tabBarController setSelectedIndex:3];
		[v release];
	} else {
		UrFeats *v = [[UrFeats alloc]init];
		v.uid = [[NSString alloc]initWithString:uid];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	}
}

- (void)settings {
	Settings *v = [[Settings alloc]init];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (void)cancel {
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	
	switch ([[user objectForKey:@"followNumber"]intValue]) {
		case 0:
			self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Follow"];
			[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(follow) forControlEvents:UIControlEventTouchUpInside];
			break;
		case 1:
			self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"UnFollow"];
			[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(unfollow) forControlEvents:UIControlEventTouchUpInside];
			break;
		default:
			break;
	}
	
	[subject resignFirstResponder];
	[body resignFirstResponder];
}

- (IBAction)send:(UIBarButtonItem*)sender {
	if ([body.text length]==0) {
		NSLog(@"There isn't a message to send.");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Oops!"
				 message:@"There isn't a message to send."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else if ([subject.text length]==0) {
		NSLog(@"There is no subject!");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Oops!"
				 message:@"There isn't a message to send."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else {
		((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = NO;
		[self send];
	}
}

- (void)send {
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	
	NSURLResponse *r;
	NSError *e;
	
	NSString *p = [NSString stringWithFormat:
				   @"&cid=0&tid=%@&fid=0&sub=%@&msg=%@&lat=%.8f&lon=%.8f&loc=%@",
				   [uid urlEncode],
				   [subject.text urlEncode],
				   [body.text urlEncode],
				   del.userLoc.coordinate.latitude,
				   del.userLoc.coordinate.longitude,
				   [[Misc reverseGeocode:del.userPlace]urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"insertMessage" WithPost:p AndResponse:&r AndError:&e];
	
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[self cancel];
}

- (void)editBio {
	if (![bio.text isEqualToString:[user objectForKey:@"bio"]]) {
		NSURLResponse *r;
		NSError *e;
		
		NSString *p = [NSString stringWithFormat:
					   @"&uid=0&bio=%@",
					   [bio.text urlEncode]];
		
		NSString *urlContents = [KuippConnect formTo:@"insertBio" WithPost:p AndResponse:&r AndError:&e];
		
		if ([urlContents length]==0) return;
		
		if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
		
		NSMutableDictionary *md = [[NSMutableDictionary alloc]initWithDictionary:user];
		[md setObject:bio.text forKey:@"bio"];
		[user release];
		user = md;
	}
	[table reloadData];
}

- (void)adjustPicture {
	// Animate
	[self picturePopout:YES];
	
	// Change Button
	storedLeftBarButtonItem = [self.navigationItem.leftBarButtonItem retain];
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Cancel"];
	[(UIButton*)self.navigationItem.leftBarButtonItem.customView addTarget:self action:@selector(cancelPicture) forControlEvents:UIControlEventTouchUpInside];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Done"];
	[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(commitPicture) forControlEvents:UIControlEventTouchUpInside];
}

- (void)picturePopout:(BOOL)b {
	table.userInteractionEnabled = !b;
	
	if (b) {
		if (!picFrame) {
			picFrame = [[UIControl alloc]init];
			picFrame.layer.masksToBounds = YES;
			picFrame.layer.cornerRadius = [Misc borderCurve];
			picFrame.layer.borderColor = [[Misc kuippOrangeColor]CGColor];
			picFrame.layer.borderWidth = [Misc border];
			picFrame.backgroundColor = [UIColor clearColor];
			picFrame.autoresizesSubviews = NO;
			
			double buf = [Misc buffer];
			double img = [Misc profileSize];
			double ns = [Misc heightForFontSize:[Misc profileNameSize]];
			double ms = [Misc heightForFontSize:[Misc mainSize]];
			picFrame.frame = CGRectMake(buf*2, buf*6+ns+ms*2+bar.frame.size.height, img, img);
			
			UIGestureRecognizer *recognizer;
			
			recognizer = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(pan:)];
			[(UIPanGestureRecognizer*)recognizer setMinimumNumberOfTouches:1];
			[(UIPanGestureRecognizer*)recognizer setMaximumNumberOfTouches:1];
			[picFrame addGestureRecognizer:recognizer];
			[recognizer setDelaysTouchesBegan:YES];
			recognizer.delegate = self;
			[recognizer release];
			
			recognizer = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinch:)];
			[recognizer setDelegate:self];
			[picFrame addGestureRecognizer:recognizer];
			recognizer.delegate = self;
			[recognizer release];
		}
		if (!picView) {
			double w = self.view.frame.size.width;
			double h = self.view.frame.size.height;
			
			picView = [[UIView alloc]init];
			picView.backgroundColor = [UIColor colorWithWhite:0 alpha:.75];
			picView.frame = CGRectMake(0, -h, w, h);
			picView.userInteractionEnabled = NO;
			[self.view addSubview:picView];
			
			double buf = [Misc buffer];
			
			picFB = [[Misc createToggle:@"settings facebook"]retain];
			double x = (self.view.frame.size.width-picFB.frame.size.width*3-buf*4*2)/2;
			double y = h-buf*6-picFB.frame.size.height;
			
			[picFB addTarget:self action:@selector(pickFB:) forControlEvents:UIControlEventTouchUpInside];
			picFB.frame = CGRectMake(x, y, picFB.frame.size.width, picFB.frame.size.height);
			picFB.selected = YES;
			
			// Add Image Picker
			x += picFB.frame.size.width+buf*4;
			picFile = [[Misc createToggle:@"settings photo"]retain];
			[picFile addTarget:self action:@selector(pickFile:) forControlEvents:UIControlEventTouchUpInside];
			picFile.frame = CGRectMake(x, y, picFile.frame.size.width, picFile.frame.size.height);
			picFile.selected = YES;
			
			// Add Camera
			x += picFile.frame.size.width+buf*4;
			picTake = [[Misc createToggle:@"settings camera"]retain];
			[picTake addTarget:self action:@selector(pickTake:) forControlEvents:UIControlEventTouchUpInside];
			picTake.frame = CGRectMake(x, y, picTake.frame.size.width, picTake.frame.size.height);
			picTake.selected = YES;
		}
		[picImage release];
		picImage = [[UIImageView alloc]init];
		picImage.clipsToBounds = YES;
		picImage.contentMode = [Misc imageFitStyle];
		picImage.backgroundColor = [UIColor clearColor];
		picImage.userInteractionEnabled = NO;
		
		UIImage *i = [images objectForKey:[user objectForKey:@"picture"]];
		picImage.image = [i retain];
		
		BOOL d = [picImage.image isEqual:[Misc defaultProfile]];
		double img = [Misc profileSize];
		int picX = [[user objectForKey:@"picX"]intValue];
		int picY = [[user objectForKey:@"picY"]intValue];
		double picZ = [[user objectForKey:@"picZ"]doubleValue];
		picImage.frame = CGRectMake(d?0:picX, d?0:picY, d?img:i.size.width*picZ, d?img:i.size.height*picZ);
			
		[picFrame addSubview:picImage];
		[self.view addSubview:picFrame];
		[self.view addSubview:activity];
		[self.view addSubview:picFB];
		[self.view addSubview:picFile];
		[self.view addSubview:picTake];
	}

	[UIView beginAnimations:@"adjustPicture" context:nil];
	[UIView setAnimationDuration:0.3];
	if (b) {
		double w = self.view.frame.size.width;
		double h = self.view.frame.size.height;
		picView.frame = CGRectMake(0, 0, w, h);
		
		double r = [Misc adjustPictureRatio];
		double p = [Misc profileSize]*r;
		picFrame.frame = CGRectMake((w-p)/2, (w-p)/2, p, p);
		
		BOOL d = [picImage.image isEqual:[Misc defaultProfile]];
		CGSize s = picImage.image.size;
		int picX = [[user objectForKey:@"picX"]intValue];
		int picY = [[user objectForKey:@"picY"]intValue];
		double picZ = [[user objectForKey:@"picZ"]doubleValue];
		picImage.frame = CGRectMake(d?0:picX*r, d?0:picY*r, d?p:s.width*picZ*r, d?p:s.height*picZ*r);
	} else {
		double w = self.view.frame.size.width;
		double h = self.view.frame.size.height;
		picView.frame = CGRectMake(0, -h, w, h);
		
		double buf = [Misc buffer];
		double img = [Misc profileSize];
		double ns = [Misc heightForFontSize:[Misc profileNameSize]];
		double ms = [Misc heightForFontSize:[Misc mainSize]];
		picFrame.frame = CGRectMake(buf*2, buf*6+ns+ms*2+bar.frame.size.height, img, img);
		
		BOOL d = [picImage.image isEqual:[Misc defaultProfile]];
		int picX = [[user objectForKey:@"picX"]intValue];
		int picY = [[user objectForKey:@"picY"]intValue];
		double picZ = [[user objectForKey:@"picZ"]doubleValue];
		picImage.frame = CGRectMake(d?0:picX, d?0:picY, d?img:picImage.image.size.width*picZ, d?img:picImage.image.size.height*picZ);
		
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDidStopSelector:@selector(pictureReturned:finished:context:)];
	}
	[UIView commitAnimations];
}

- (void)pictureReturned:(NSString*)animationID finished:(BOOL)finished context:(void*)context {
	[picTake removeFromSuperview];
	[picFile removeFromSuperview];
	[picFB removeFromSuperview];
	[picImage removeFromSuperview];
	[activity removeFromSuperview];
	[picFrame removeFromSuperview];
}

- (void)pickFB:(UIButton*)sender {
	facebook = ((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).facebook;
	[activity startAnimating];
	if (facebook&&[facebook.expirationDate timeIntervalSinceNow]>0) {
		[self toggleButton:sender];
		
		[self getFBPic];
	} else {
		NSArray *permissions = [[Misc facebookPermissions]retain];
		
		[facebook authorize:permissions delegate:self];
		
		[permissions release];
	}
}

- (void)getFBPic {
	NSUserDefaults *s = [NSUserDefaults standardUserDefaults];
	NSString* facebookID = [s objectForKey:[NSString stringWithFormat:@"%@facebookID",[s objectForKey:@"email"]]];
	
	[picURL release];
	picURL = [[NSString alloc]initWithFormat:@"http://graph.facebook.com/%@/picture?type=large",facebookID];
	if ([Misc debug]) NSLog(@"%@",picURL);
	NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:picURL]];
	
	picImage.image = [[UIImage imageWithData:data] retain];
	picImage.frame = CGRectMake(0, 0, picImage.image.size.width, picImage.image.size.height);
	local = NO;
	
	[activity stopAnimating];
}

- (void)pickFile:(UIButton*)sender {
	picker = [[UIImagePickerController alloc]init];
	picker.delegate = self;
	
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
		[self toggleButton:sender];
		
		picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
		
		[self presentModalViewController:picker animated:YES];
	} else {
		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Oops!" message:@"Your device doesn't have a Photo Library to choose a picture from!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
}

- (void)pickTake:(UIButton*)sender {
	picker = [[UIImagePickerController alloc]init];
	picker.delegate = self;
	
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		[self toggleButton:sender];
		
		picker.sourceType = UIImagePickerControllerSourceTypeCamera;
		
		[self presentModalViewController:picker animated:YES];
	} else {
		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Oops!" message:@"Your device doesn't have a Camera to take a picture with!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
}

- (void)toggleButton:(UIButton*)sender {
	picFB.selected = YES;
	picFile.selected = YES;
	picTake.selected = YES;
	sender.selected = NO;
}

- (void)pan:(UIPanGestureRecognizer*)pan {
	CGPoint p = [pan translationInView:picFrame];
	CGRect f = picFrame.frame;
	CGRect i = picImage.frame;
	if ([pan state]==UIGestureRecognizerStateBegan) {
		picPoint = picImage.frame.origin;
	}
	if (picPoint.x+p.x+i.size.width>=f.size.width&&
		picPoint.y+p.y+i.size.height>=f.size.height&&
		picPoint.x+p.x<=0&&
		picPoint.y+p.y<=0) {
		picImage.frame = CGRectMake(picPoint.x+p.x, picPoint.y+p.y, i.size.width, i.size.height);
	}
}

- (void)pinch:(UIPinchGestureRecognizer*)pinch {
	double p = [pinch scale];
	CGRect f = picFrame.frame;
	
	if ([pinch state]==UIGestureRecognizerStateBegan) {
		picPoint = picImage.frame.origin;
		picZoom = picImage.frame.size.width/picImage.image.size.width;
	}
	
	double s = picZoom*p;
	NSLog(@"%f * %f = %f",picZoom,p,s);
	
	double width = picImage.image.size.width*s;
	double height = picImage.image.size.height*s;
	
	double widthMid = -picPoint.x+picFrame.center.x;
	double heightMid = -picPoint.y+picFrame.center.y;
	
	double widthCntr = widthMid*p;
	double heightCntr = heightMid*p;
	
	double xPoint = fmax(fmin(-widthCntr+picFrame.center.x,0),f.size.width-width);
	double yPoint = fmax(fmin(-heightCntr+picFrame.center.y,0),f.size.height-height);
	
	if (xPoint<=0&&yPoint<=0&&xPoint+width>=f.size.width&&yPoint+height>=f.size.height) {
		picImage.frame = CGRectMake(xPoint, yPoint, width, height);
	}
}

- (void)cancelPicture {
	[self picturePopout:NO];
	
	// Revert Right Button
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithImage:@"settings icon"];
	[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(settings) forControlEvents:UIControlEventTouchUpInside];
	
	// Revert Left Button
	self.navigationItem.leftBarButtonItem = storedLeftBarButtonItem;
	[storedLeftBarButtonItem release];
	storedLeftBarButtonItem = nil;
}

- (void)commitPicture {
	if (firstTime) [self profileTutorial:2];
	
	// Save to server
	double r = [Misc adjustPictureRatio];
	NSString *x = [NSString stringWithFormat:@"%d",(int)(picImage.frame.origin.x/r)];
	NSString *y = [NSString stringWithFormat:@"%d",(int)(picImage.frame.origin.y/r)];
	NSString *z = [NSString stringWithFormat:@"%.8f",picImage.frame.size.width/picImage.image.size.width/r];
	
	if (!picURL) picURL = [user objectForKey:@"picture"];
	
	if (local||
		![picURL isEqualToString:[user objectForKey:@"picture"]]||
		![x isEqualToString:[user objectForKey:@"picX"]]||
		![y isEqualToString:[user objectForKey:@"picY"]]||
		![z isEqualToString:[user objectForKey:@"picZ"]]) {
		NSURLResponse *resp;
		NSError *e;
		
		if (local) {
			/*
			 Set the new Frame to crop out
			 Rotate,Crop,Resize image
			 */
			double zoom = [z doubleValue];
			CGRect crop = CGRectMake(-[x intValue]/zoom, -[y intValue]/zoom, 130/zoom, 130/zoom);
			picImage.image = [Misc imageWithImage:picImage.image scaledToSize:CGSizeMake(130, 130) fromSection:crop];
			picImage.frame = CGRectMake(0, 0, 130*r, 130*r);
			x = @"0";
			y = @"0";
			z = @"1";
			
			/*
			 turning the image into a NSData object
			 getting the image back out of the UIImageView
			 setting the quality to 90
			 */
			NSData *imageData = UIImageJPEGRepresentation(picImage.image, 90);
			// setting up the URL to post to
			NSString *urlString = [KuippConnect urlString:@"profilepictures/uploadImage"];
			urlString = [urlString stringByReplacingOccurrencesOfString:@"/test" withString:@""];
			urlString = [urlString stringByReplacingOccurrencesOfString:@"/beta" withString:@""];
			urlString = [urlString stringByReplacingOccurrencesOfString:@"/pub" withString:@""];
			
			// setting up the request object now
			NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
			[request setURL:[NSURL URLWithString:urlString]];
			[request setHTTPMethod:@"POST"];
			/*
			 add some header info now
			 we always need a boundary when we post a file
			 also we need to set the content type
			 */
			NSString *boundary = [NSString stringWithString:@"---------------------------14737809831466499882746641449"];
			NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
			[request addValue:contentType forHTTPHeaderField: @"Content-Type"];
			
			/*
			 now lets create the body of the post
			 */
			NSMutableData *postbody = [NSMutableData data];
			[postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
			[postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"userfile\"; filename=\"%@\"\r\n",[picURL lastPathComponent]] dataUsingEncoding:NSUTF8StringEncoding]];
			[postbody appendData:[[NSString stringWithString:@"Content-Type: application/octet-stream\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
			[postbody appendData:[NSData dataWithData:imageData]];
			[postbody appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
			// setting the body of the post to the reqeust
			[request setHTTPBody:postbody];
			
			// now lets make the connection to the web
			NSData *returnData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
			NSString *returnString = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
			
			NSLog(@"%@",returnString);
			
			[returnString release];
		}
		
		NSString *p = [NSString stringWithFormat:
					   @"&uid=0&url=%@&pcx=%@&pcy=%@&pcz=%@",
					   [picURL urlEncode],
					   [x urlEncode],
					   [y urlEncode],
					   [z urlEncode]];
		
		NSString *urlContents = [KuippConnect formTo:@"updatePicture" WithPost:p AndResponse:&resp AndError:&e];
		
		if ([urlContents length]==0) return;
		
		if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
		
		if (picImage.image) [images setObject:picImage.image forKey:picURL];
		
		NSMutableDictionary *md = [[NSMutableDictionary alloc]initWithDictionary:user];
		[md setObject:picURL forKey:@"picture"];
		[md setObject:x forKey:@"picX"];
		[md setObject:y forKey:@"picY"];
		[md setObject:z forKey:@"picZ"];
		[user release];
		user = md;
		
		[table reloadData];
	}
	
	[self cancelPicture];
}

- (void)profileTutorial:(int)i {
	UIAlertView *alert;
	if (i==4) {
		alert = [[UIAlertView alloc]
				 initWithTitle:[Misc profileTutorialTitle:i]
				 message:[Misc profileTutorialMessage:i]
				 delegate:self
				 cancelButtonTitle:@"OK" 
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
	alert = [[UIAlertView alloc]
			 initWithTitle:[Misc profileTutorialTitle:i]
			 message:[Misc profileTutorialMessage:i]
			 delegate:self
			 cancelButtonTitle:@"No Thanks" 
			 otherButtonTitles:@"Yes!",nil];
	[alert show];
	[alert release];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return user?1:0;}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	ProfileCell *c = (ProfileCell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
	if (!c) c = [[[ProfileCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"A"]autorelease];
	
	// Configure the cell...
	c.dict = user;
	
	c.picW.image = [images objectForKey:[user objectForKey:@"picture"]];
	if ([[user objectForKey:@"followNumber"]intValue]==2) {
		[c.picC addTarget:self action:@selector(adjustPicture) forControlEvents:UIControlEventTouchUpInside];
		[c.picC addTarget:[Misc class]action:@selector(blueCover:) forControlEvents:UIControlEventTouchDown|UIControlEventTouchDragInside];
		[c.picC addTarget:[Misc class]action:@selector(noCover:) forControlEvents:UIControlEventTouchDragOutside|UIControlEventTouchUpInside];
	}
	
	c.name.text = [Misc first:[user objectForKey:@"firstName"]lastName:[user objectForKey:@"lastName"]];
	c.txt1.text = [NSString stringWithFormat:@"Influence: %.0f%%",[[user objectForKey:@"influence"]doubleValue]*100];
	c.txt1.textColor = [Misc kuippOrangeColor];
	c.txt2.text = [NSString stringWithFormat:@"Pts: %@, Next Level in: %d",[user objectForKey:@"points"],[[level objectForKey:@"maxPoints"]intValue]-[[user objectForKey:@"points"]intValue]];
	c.txt3.text = [NSString stringWithFormat:@"Asked/Answered: %@/%@",[user objectForKey:@"qCount"],[user objectForKey:@"aCount"]];
	c.txt4.text = [NSString stringWithFormat:@"Following/Followers: %@/%@",[user objectForKey:@"numFollowing"],[user objectForKey:@"numFollowers"]];
	c.txt5.text = [NSString stringWithFormat:@"Like/Dislike: %@/%@",[user objectForKey:@"likeCount"],[user objectForKey:@"dislikeCount"]];
	
	c.blck.delegate = self;
	c.blck.editable = [[user objectForKey:@"followNumber"]intValue]==2;
	if ([[user objectForKey:@"bio"]length]==0) {
		c.blck.text = c.blck.editable?[Misc defaultEditBio]:[Misc defaultNoBio];
	} else {
		NSString *b = [user objectForKey:@"bio"];
		c.blck.text = [NSString stringWithFormat:@"I'm a%@: %@",[[NSCharacterSet characterSetWithCharactersInString:@"aAeEiIoOuU"]characterIsMember:[b characterAtIndex:0]]?@"n":@"",b];
	}
	bio = c.blck;
	
	[c.medC addTarget:self action:@selector(medals) forControlEvents:UIControlEventTouchUpInside];
	c.medL.text = [user objectForKey:@"numMedals"];
	
	[c.intC addTarget:self action:@selector(interests:) forControlEvents:UIControlEventTouchUpInside];
	c.intL.text = [user objectForKey:@"numInterests"];
	
	c.lvlI.image = [UIImage imageNamed:[NSString stringWithFormat:@"class %@ large",[user objectForKey:@"class"]]];
	c.lvlC.text = [NSString stringWithFormat:@"Level %@ %@",[user objectForKey:@"level"],[user objectForKey:@"class"]];
	
	return c;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {return table.frame.size.height;}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {[tableView deselectRowAtIndexPath:indexPath animated:YES];}


#pragma mark -
#pragma mark UIScrollView

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		if (!refreshCell.flipped) [refreshCell flip];
	} else {
		if (refreshCell.flipped) [refreshCell flip];
	}
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		[self refreshAll];
	}
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	CGRect t = top.frame;
	double tx = t.origin.x;
	double tw = t.size.width;
	double th = t.size.height;
	CGRect b = bot.frame;
	double bx = b.origin.x;
	double bw = b.size.width;
	double bh = b.size.height;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	if (![bio isFirstResponder]) top.frame = CGRectMake(tx,-200+delta*200,tw,th);
	bot.frame = CGRectMake(bx,367-delta*(kb.size.height-49),bw,bh);
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {[self keyboardAdjust:note:1];}

- (void)keyboardWasHidden:(NSNotification*)note {[self keyboardAdjust:note:0];}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	if (textField==subject) [body becomeFirstResponder];
	return NO;
}

#pragma mark -
#pragma mark UITextViewDelegate

- (void)textViewDidBeginEditing:(UITextView *)textView {
	if (textView==bio) {
		textView.contentOffset = CGPointMake(0,0);
		if ([textView.text isEqualToString:[Misc defaultEditBio]]) {
			textView.text = @"";
		} else {
			NSRange r = [textView.text rangeOfString:@":"];
			textView.text = [textView.text substringFromIndex:r.location+r.length];
		}
	}
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
	if (textView==bio) {
		if ([text isEqualToString:@"\n"]) [self editBio];
		else if ([Misc heightForText:[NSString stringWithFormat:@"I'm an: %@",[bio.text stringByReplacingCharactersInRange:range withString:text]]width:textView.frame.size.width-16 size:[Misc mainSize]]>textView.frame.size.height) return NO;
	} else {
		int newCount = [count.text intValue]-[text length]+range.length;
		if (newCount<0) return NO;
	}
	return YES;
}

- (void)textViewDidChange:(UITextView *)textView {[self refreshCount];}

- (void)textViewDidEndEditing:(UITextView *)textView {
	if (textView==bio) {
		textView.contentOffset = CGPointMake(0,0);
		if ([textView.text length]==0) textView.text = [Misc defaultEditBio];
		else textView.text = [[NSString stringWithFormat:@"I'm a%@: ",[[NSCharacterSet characterSetWithCharactersInString:@"aAeEiIoOuU"]characterIsMember:[textView.text characterAtIndex:0]]?@"n":@""]stringByAppendingString:textView.text];
		if (firstTime) [self profileTutorial:1];
	}
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:[Misc profileTutorialTitle:0]]) {
		if (buttonIndex==1) [bio becomeFirstResponder];
		else if (![[[NSUserDefaults standardUserDefaults]objectForKey:@"picture"]isEqualToString:[Misc defaultProfileURL]]) [self profileTutorial:1];
		else [self profileTutorial:2];
	}
	if ([alertView.title isEqualToString:[Misc profileTutorialTitle:1]]) {
		if (buttonIndex==1) [self adjustPicture];
		else [self profileTutorial:2];
	}
	if ([alertView.title isEqualToString:[Misc profileTutorialTitle:2]]) {
		if (buttonIndex==1) [self interests:nil];
		else [self profileTutorial:3];
	}
	if ([alertView.title isEqualToString:[Misc profileTutorialTitle:3]]) {
		NSUserDefaults *s = [NSUserDefaults standardUserDefaults];
		NSString *u = [s objectForKey:@"userID"];
		NSString *key = [NSString stringWithFormat:@"firstTime%@Profile",u];
		[s setObject:@"1" forKey:key];
		firstTime = NO;
	}
}

#pragma mark -
#pragma mark FBSessionDelegate

- (void)fbDidLogin {
	[self toggleButton:picFB];
	
	[facebook requestWithGraphPath:@"me" andDelegate:self];
}

- (void)fbDidNotLogin:(BOOL)cancelled {NSLog(@"Failed to log into facebook. User canceled? %@",cancelled?@"YES":@"NO");}

#pragma mark -
#pragma mark FBRequestDelegate

- (void)request:(FBRequest *)request didLoad:(id)result {
	if ([result isKindOfClass:[NSDictionary class]]) {
		NSUserDefaults *s = [NSUserDefaults standardUserDefaults];
		[s setObject:[result objectForKey:@"id"] forKey:@"facebookID"];
		
		[self getFBPic];
	}
}

- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {NSLog(@"%@",error);}

#pragma mark -
#pragma mark UIImagePickerControllerDelegate

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)imgpkr {
	[[imgpkr parentViewController]dismissModalViewControllerAnimated:YES];
	imgpkr.delegate = nil;
	[imgpkr release];
}

- (void)imagePickerController:(UIImagePickerController *)imgpkr didFinishPickingMediaWithInfo:(NSDictionary *)info {
	local = YES;
	
	[picURL release];
	picURL = [[NSString alloc]initWithFormat:@"http://kuipp.com/profilepictures/%@.jpg",
			  [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]];
		
	picImage.image = [info objectForKey:UIImagePickerControllerOriginalImage];
	picImage.frame = CGRectMake(0, 0, picImage.image.size.width, picImage.image.size.height);
	
	[[imgpkr parentViewController]dismissModalViewControllerAnimated:YES];
	imgpkr.delegate = nil;
	[imgpkr release];
}

#pragma mark -
#pragma mark Initialization
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	[Misc load:self];
	
	if (self==[[self.navigationController viewControllers]objectAtIndex:0]) self.navigationItem.leftBarButtonItem = nil;
	
	bar.backgroundColor = [Misc barColor];
	
	[mButton setBackgroundImage:[Misc roundTeal]forState:UIControlStateNormal];
	[cButton setBackgroundImage:[Misc roundTeal]forState:UIControlStateNormal];
	[aButton setBackgroundImage:[Misc roundTeal]forState:UIControlStateNormal];
	
	double r = [Misc refreshCellHeight];
	refreshCell = [Misc refreshCellView];
	refreshCell.table = table;
	refreshCell.frame = CGRectMake(0, 0, self.view.frame.size.width, r);
	[table setTableHeaderView:refreshCell];
	
	table.contentInset = UIEdgeInsetsMake(-r,0,0,0);
	
	NSString *s = [[NSUserDefaults standardUserDefaults]objectForKey:@"userID"];
	if (!uid||[uid intValue]==0) uid = s;
	if ([uid intValue]==[s intValue]) {
		self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithImage:@"settings icon"];
		[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(settings) forControlEvents:UIControlEventTouchUpInside];
	} else {
		[mButton setTitle:@"Message" forState:UIControlStateNormal];
		[mButton removeTarget:self action:@selector(messages:) forControlEvents:UIControlEventTouchUpInside];
		[mButton addTarget:self action:@selector(sendMsg:) forControlEvents:UIControlEventTouchUpInside];
	}
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aSyncImageLoaded) name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	[self refreshAll];
	
	if ([uid intValue]==[[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue]) {
		NSUserDefaults *s = [NSUserDefaults standardUserDefaults];
		NSString *u = [s objectForKey:@"userID"];
		NSString *key = [NSString stringWithFormat:@"firstTime%@Profile",u];
		
		firstTime = ![s objectForKey:key];
		
		if (firstTime) [self profileTutorial:0];
	}
	
	activity = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
	activity.hidesWhenStopped = YES;
	activity.frame = CGRectMake((self.view.frame.size.height-activity.frame.size.height)/2,
								(self.view.frame.size.width-activity.frame.size.width)/2,
								activity.frame.size.width, activity.frame.size.height);
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[activity release];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[uid release];
	table.delegate = nil;
	table.dataSource = nil;
	subject.delegate = nil;
	body.delegate = nil;
	
    [super dealloc];
}

@end
