//
//  Questions.h
//  Kuipp
//
//  Created by Brandon Jue on 12/26/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Questions : UIViewController <UISearchBarDelegate,UIAlertViewDelegate> {
	NSMutableArray *dicts;
	NSMutableArray *heads;
	
	IBOutlet UILabel *funnel1;
	IBOutlet UILabel *funnel2;
	IBOutlet UIButton *subCategory;
	IBOutlet UIButton *subSubCategory;
	
	IBOutlet UISearchBar *search;
	NSMutableArray *searchResults;
	
	IBOutlet UITableView *table;
	
	BOOL viewMoved;
	
	int category1;
	int category2;
	int category3;
}

- (IBAction)popBack:(id)sender;
- (IBAction)refresh:(id)sender;
- (IBAction)generalCategory:(id)sender;
- (IBAction)subCategory:(id)sender;
- (IBAction)subSubCategory:(id)sender;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;
- (BOOL)searchString:(NSArray *)array inDict:(NSDictionary *)dict;

@end
