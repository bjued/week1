//
//  SendMessage.h
//  Kuipp
//
//  Created by Brandon Jue on 12/21/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface SendMessage : UIViewController <CLLocationManagerDelegate,UITextFieldDelegate,UITextViewDelegate,UIAlertViewDelegate> {
	NSDictionary *dict;
	
	IBOutlet UITextField *to;
	IBOutlet UITextView *body;
	IBOutlet UILabel *count;
	
	IBOutlet UIView *keyboardBar;
	
	BOOL viewMoved;
	
	CLLocationManager *manager;
	CLLocation *userLoc;
}

@property(nonatomic,retain) NSDictionary *dict;
- (IBAction)popBack:(id)sender;
- (void)refresh;
- (void)refreshCount;
- (IBAction)send:(id)sender;
- (void)send;
- (IBAction)backgroundTouched:(id)sender;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification *)note;
- (void)keyboardWasHidden:(NSNotification *)note;
- (IBAction)done:(id)sender;
- (IBAction)clear:(id)sender;

@end
