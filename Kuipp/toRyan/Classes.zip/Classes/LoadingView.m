//
//  LoadingView.m
//  Kuipp
//
//  Created by Brandon Jue on 3/26/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "LoadingView.h"

@implementation LoadingView

- (void)threadedCheckSession {
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];
	[self retain];
	[self checkSession];
	[self release];
	[pool release];
}

- (void)checkSession {
	KuippAppDelegate *delegate = (KuippAppDelegate*)[UIApplication sharedApplication].delegate;
	
	//determining if user is logged in
	NSString *sid = [[NSUserDefaults standardUserDefaults]objectForKey:@"sessionID"];
	if (!sid||[sid intValue]==0) {
		[delegate performSelectorOnMainThread:@selector(toLogin) withObject:nil waitUntilDone:YES];
		return;
	}
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *urlContents = [KuippConnect formTo:@"continue" WithPost:@"" AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) {
		[delegate performSelectorOnMainThread:@selector(toLogin) withObject:nil waitUntilDone:YES];
		return;
	}
	
	if (![KuippConnect checkSessionCode:urlContents forView:nil]) {
		[delegate performSelectorOnMainThread:@selector(toLogin) withObject:nil waitUntilDone:YES];
		return;
	}
	
	NSMutableArray *d = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:d];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[delegate performSelectorOnMainThread:@selector(toMainApp:) withObject:d waitUntilDone:YES];
	[d release];
}	

#pragma mark -
#pragma mark Initialization

/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad {
 [super viewDidLoad];
 }
 */

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return NO;
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[activity startAnimating];
	[self performSelectorInBackground:@selector(threadedCheckSession) withObject:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
	[activity stopAnimating];
	
	[super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}

@end
