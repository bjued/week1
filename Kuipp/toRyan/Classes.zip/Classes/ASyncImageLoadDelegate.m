//
//  ASyncImageLoadDelegate.m
//  Kuipp
//
//  Created by Brandon Jue on 3/23/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "ASyncImageLoadDelegate.h"

@implementation ASyncImageLoadDelegate

- (id)loadURLString:(NSString*)s intoDictionary:(NSMutableDictionary*)d {
	url = [s retain];
	dic = [d retain];
	dat = [[NSMutableData alloc]initWithCapacity:2048];
	return self;
}

- (void)connection:(NSURLConnection*)c didReceiveData:(NSData*)d {[dat appendData:d];}

- (void)connectionDidFinishLoading:(NSURLConnection*)c {
	UIImage *i = [UIImage imageWithData:dat];
	if (i) {
		[dic setObject:i forKey:url];
		[[NSNotificationCenter defaultCenter]postNotificationName:@"aSyncImageLoaded" object:nil];
	}
}

- (void)connection:(NSURLConnection*)c didFailWithError:(NSError*)e {NSLog(@"%@",e);}

- (void)dealloc {
	[url release];
	[dic release];
	[dat release];
	
	[super dealloc];
}

@end
