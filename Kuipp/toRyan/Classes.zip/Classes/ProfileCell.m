//
//  ProfileCell.m
//  Kuipp
//
//  Created by Brandon Jue on 3/14/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "ProfileCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation ProfileCell

@synthesize dict,picC,medC,intC,picW,lvlI,name,txt1,txt2,txt3,txt4,txt5,blck,medL,intL,lvlC;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
	if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        // Initialization code.
		
		nmVw = [[UIView alloc]init];
		
		name = [[UILabel alloc]init];
		name.backgroundColor = [UIColor clearColor];
		name.font = [UIFont boldSystemFontOfSize:[Misc profileNameSize]];
		name.textColor = [Misc kuippOrangeColor];
		name.textAlignment = UITextAlignmentCenter;
		
		blkV = [[UIView alloc]init];
		blkV.layer.masksToBounds = YES;
		blkV.layer.cornerRadius = [Misc borderCurve];
		blkV.layer.borderColor = [[Misc kuippOrangeColor]CGColor];
		blkV.layer.borderWidth = [Misc border];
		blkV.backgroundColor = [UIColor whiteColor];
		
		blck = [[UITextView alloc]init];
		blck.backgroundColor = [UIColor clearColor];
		blck.font = [UIFont systemFontOfSize:[Misc mainSize]];
		blck.textColor = [UIColor darkGrayColor];
		blck.scrollEnabled = NO;
		blck.keyboardType = UIKeyboardTypeASCIICapable;
		blck.keyboardAppearance = UIKeyboardAppearanceAlert;
		blck.returnKeyType = UIReturnKeyDone;
		blck.contentInset = UIEdgeInsetsMake(-10,0,0,0);
		
		picV = [[UIView alloc]init];
		
		picC = [[UIControl alloc]init];
		picC.layer.masksToBounds = YES;
		picC.layer.cornerRadius = [Misc borderCurve];
		picC.layer.borderColor = [[Misc kuippOrangeColor]CGColor];
		picC.layer.borderWidth = [Misc border];
		picC.backgroundColor = [UIColor clearColor];
		
		picW = [[UIImageView alloc]init];
		picW.clipsToBounds = YES;
		picW.contentMode = [Misc imageFitStyle];
		picW.backgroundColor = [UIColor clearColor];
		picW.userInteractionEnabled = NO;
		
		txtV = [[UIView alloc]init];
		
		txt1 = [[UILabel alloc]init];
		txt1.backgroundColor = [UIColor clearColor];
		txt1.font = [UIFont systemFontOfSize:[Misc mainSize]];
		txt1.textColor = [UIColor whiteColor];
		
		txt2 = [[UILabel alloc]init];
		txt2.backgroundColor = [UIColor clearColor];
		txt2.font = [UIFont systemFontOfSize:[Misc mainSize]];
		txt2.textColor = [UIColor whiteColor];
		
		txt3 = [[UILabel alloc]init];
		txt3.backgroundColor = [UIColor clearColor];
		txt3.font = [UIFont systemFontOfSize:[Misc mainSize]];
		txt3.textColor = [UIColor whiteColor];
		
		txt4 = [[UILabel alloc]init];
		txt4.backgroundColor = [UIColor clearColor];
		txt4.font = [UIFont systemFontOfSize:[Misc mainSize]];
		txt4.textColor = [UIColor whiteColor];
		
		txt5 = [[UILabel alloc]init];
		txt5.backgroundColor = [UIColor clearColor];
		txt5.font = [UIFont systemFontOfSize:[Misc mainSize]];
		txt5.textColor = [UIColor whiteColor];
		
		medV = [[UIView alloc]init];
		
		medC = [[UIControl alloc]init];
		medC.layer.masksToBounds = YES;
		medC.layer.cornerRadius = [Misc borderCurve];
		medC.layer.borderColor = [[Misc kuippOrangeColor]CGColor];
		medC.layer.borderWidth = [Misc border];
		medC.backgroundColor = [UIColor whiteColor];
		[medC addTarget:[Misc class]action:@selector(blueCover:) forControlEvents:UIControlEventTouchDown|UIControlEventTouchDragInside];
		[medC addTarget:[Misc class]action:@selector(whiteCover:) forControlEvents:UIControlEventTouchDragOutside|UIControlEventTouchUpInside];
		
		medI = [[UIImageView alloc]init];
		medI.backgroundColor = [UIColor clearColor];
		medI.contentMode = UIViewContentModeScaleAspectFit;
		medI.image = [UIImage imageNamed:@"medals Ghost profile"];
		medI.userInteractionEnabled = NO;

		medT = [[UILabel alloc]init];
		medT.backgroundColor = [UIColor clearColor];
		medT.font = [UIFont italicSystemFontOfSize:[Misc mainSize]];
		medT.textColor = [UIColor darkGrayColor];
		medT.textAlignment = UITextAlignmentCenter;
		medT.text = @"Medals";
		medT.userInteractionEnabled = NO;
		
		medL = [[UILabel alloc]init];
		medL.backgroundColor = [UIColor clearColor];
		medL.font = [UIFont systemFontOfSize:[Misc profileNameSize]];
		medL.textColor = [Misc kuippOrangeColor];
		medL.textAlignment = UITextAlignmentCenter;
		medL.userInteractionEnabled = NO;
		
		medA = [Misc detailDisclosure];
		medA.backgroundColor = [UIColor clearColor];
		medA.userInteractionEnabled = NO;
		
		intV = [[UIView alloc]init];
		
		intC = [[UIControl alloc]init];
		intC.layer.masksToBounds = YES;
		intC.layer.cornerRadius = [Misc borderCurve];
		intC.layer.borderColor = [[Misc kuippOrangeColor]CGColor];
		intC.layer.borderWidth = [Misc border];
		intC.backgroundColor = [UIColor whiteColor];
		[intC addTarget:[Misc class]action:@selector(blueCover:) forControlEvents:UIControlEventTouchDown|UIControlEventTouchDragInside];
		[intC addTarget:[Misc class]action:@selector(whiteCover:) forControlEvents:UIControlEventTouchDragOutside|UIControlEventTouchUpInside];
		
		intI = [[UIImageView alloc]init];
		intI.backgroundColor = [UIColor clearColor];
		intI.contentMode = UIViewContentModeScaleAspectFit;
		intI.image = [UIImage imageNamed:@"interests Ghost"];
		intI.userInteractionEnabled = NO;
		
		intT = [[UILabel alloc]init];
		intT.backgroundColor = [UIColor clearColor];
		intT.font = [UIFont italicSystemFontOfSize:[Misc mainSize]];
		intT.textColor = [UIColor darkGrayColor];
		intT.textAlignment = UITextAlignmentCenter;
		intT.text = @"Interests";
		intT.userInteractionEnabled = NO;
		
		intL = [[UILabel alloc]init];
		intL.backgroundColor = [UIColor clearColor];
		intL.font = [UIFont systemFontOfSize:[Misc profileNameSize]];
		intL.textColor = [Misc kuippOrangeColor];
		intL.textAlignment = UITextAlignmentCenter;
		intL.userInteractionEnabled = NO;
		
		intA = [Misc detailDisclosure];
		intA.backgroundColor = [UIColor clearColor];
		intA.userInteractionEnabled = NO;
		
		lvlV = [[UIView alloc]init];
		
		lvlI = [[UIImageView alloc]init];
		lvlI.backgroundColor = [UIColor clearColor];
		lvlI.contentMode = UIViewContentModeScaleAspectFit;
		lvlI.userInteractionEnabled = NO;
		
		lvlC = [[UILabel alloc]init];
		lvlC.backgroundColor = [UIColor clearColor];
		lvlC.font = [UIFont systemFontOfSize:[Misc mainSize]];
		lvlC.textColor = [Misc kuippOrangeColor];
		lvlC.textAlignment = UITextAlignmentCenter;
		lvlC.userInteractionEnabled = NO;
		
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		
		[self.contentView addSubview:nmVw];
		[nmVw addSubview:name];
		[nmVw addSubview:blkV];
		[blkV addSubview:blck];
		
		[self.contentView addSubview:picV];
		[picV addSubview:picC];
		[picC addSubview:picW];
		
		[self.contentView addSubview:txtV];
		[txtV addSubview:txt1];
		[txtV addSubview:txt2];
		[txtV addSubview:txt3];
		[txtV addSubview:txt4];
		[txtV addSubview:txt5];
		
		[self.contentView addSubview:medV];
		[medV addSubview:medC];
		[medC addSubview:medI];
		[medC addSubview:medT];
		[medC addSubview:medL];
		[medC addSubview:medA];
		
		[self.contentView addSubview:intV];
		[intV addSubview:intC];
		[intC addSubview:intI];
		[intC addSubview:intT];
		[intC addSubview:intL];
		[intC addSubview:intA];
		
		[self.contentView addSubview:lvlV];
		[lvlV addSubview:lvlI];
		[lvlV addSubview:lvlC];
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect c = self.contentView.bounds;
	double w = c.size.width;
	double h = c.size.height;
	
	double buf = [Misc buffer];
	double img = [Misc profileSize];
	double ns = [Misc heightForFontSize:[Misc profileNameSize]];
	double ms = [Misc heightForFontSize:[Misc mainSize]];
	
	// Macro Management
	
	nmVw.frame = CGRectMake(buf*2, buf*2, w-buf*4, ns+ms*2+buf*3);
	
	c = nmVw.frame;
	double nvx = c.origin.x;
	double nvy = c.origin.y;
	double nvw = c.size.width;
	double nvh = c.size.height;
	picV.frame = CGRectMake(nvx, buf+nvy+nvh, img,img);
	
	c = picV.frame;
	double pvx = c.origin.x;
	double pvy = c.origin.y;
	double pvw = c.size.width;
	double pvh = c.size.height;
	txtV.frame = CGRectMake(buf+pvx+pvw, pvy, nvw-buf*2-pvw, ms*5);
	
	medV.frame = CGRectMake(pvx, buf+pvy+pvh, pvw, (h-pvy-pvh-buf*4)/2);
	
	c = medV.frame;
	double mvx = c.origin.x;
	double mvy = c.origin.y;
	double mvw = c.size.width;
	double mvh = c.size.height;
	intV.frame = CGRectMake(mvx, buf+mvy+mvh, mvw, (h-pvy-pvh-buf*4)/2);
	
	c = txtV.frame;
	double tvx = c.origin.x;
	double tvy = c.origin.y;
	double tvw = c.size.width;
	double tvh = c.size.height;
	lvlV.frame = CGRectMake(tvx, buf+tvy+tvh, tvw, h-buf*3-tvy-tvh);
	
	// Micro Management
	
	name.frame = CGRectMake(0, 0, nvw, ns);
	blkV.frame = CGRectMake(0, ns+buf, nvw, ms*2+buf*2);
	blck.frame = CGRectMake(0, buf, nvw, ms*2);
	
	picC.frame = CGRectMake(0, 0, pvw, pvh);
	
	BOOL b = [picW.image isEqual:[Misc defaultProfile]];
	int picX = [[dict objectForKey:@"picX"]intValue];
	int picY = [[dict objectForKey:@"picY"]intValue];
	double picZ = [[dict objectForKey:@"picZ"]doubleValue];
	CGSize picS = picW.image.size;
	picW.frame = CGRectMake(b?0:picX, b?0:picY, b?img:picS.width*picZ, b?img:picS.height*picZ);
	
	txt1.frame = CGRectMake(0, 0, tvw, ms);
	txt2.frame = CGRectMake(0, ms, tvw, ms);
	txt3.frame = CGRectMake(0, ms*2, tvw, ms);
	txt4.frame = CGRectMake(0, ms*3, tvw, ms);
	txt5.frame = CGRectMake(0, ms*4, tvw, ms);
	
	medC.frame = CGRectMake(0, 0, mvw, mvh);
	medI.frame = CGRectMake(buf, 0, mvh-buf*2, mvh-buf);
	medT.frame = CGRectMake(mvh, buf, mvw-mvh-buf*3, mvh/2-buf);
	medL.frame = CGRectMake(mvh, mvh/2, mvw-mvh-buf*3, mvh/2-buf);
	medA.frame = CGRectMake(mvw-buf*3, (mvh-ms)/2, buf*3, ms);
	
	c = intV.frame;
	double ivw = c.size.width;
	double ivh = c.size.height;
	intC.frame = CGRectMake(0, 0, ivw, ivh);
	intI.frame = CGRectMake(buf, 0, ivh-buf*2, ivh-buf);
	intT.frame = CGRectMake(ivh, buf, ivw-ivh-buf*3, ivh/2-buf);
	intL.frame = CGRectMake(ivh, ivh/2, ivw-ivh-buf*3, ivh/2-buf);
	intA.frame = CGRectMake(ivw-buf*3, (ivh-ms)/2, buf*3, ms);
	
	c = lvlV.frame;
	double lvw = c.size.width;
	double lvh = c.size.height;
	lvlI.frame = CGRectMake(0, 0, lvw, lvh-ms);
	lvlC.frame = CGRectMake(0, lvh-ms, lvw, ms);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}

- (void)setHighlighted:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}

- (void)dealloc {
	[dict release];
	[picC release];
	[medC release];
	[intC release];
	[picW release];
	[lvlI release];
	[name release];
	[txt1 release];
	[txt2 release];
	[txt3 release];
	[txt4 release];
	[txt5 release];
	[blck release];
	[medL release];
	[intL release];
	[lvlC release];
	
    [super dealloc];
}

@end
