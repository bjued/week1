//
//  RegisterView.h
//  Kuipp
//
//  Created by Brandon Jue on 12/14/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Facebook.h"

@interface RegisterView : UIViewController <FBSessionDelegate,FBRequestDelegate,UITextFieldDelegate,UIAlertViewDelegate> {
	
	BOOL viewMoved;
	
	IBOutlet UITextField *fName;
	IBOutlet UITextField *lName;
	IBOutlet UITextField *email;
	IBOutlet UITextField *password;
	IBOutlet UITextField *confirm;
	
	Facebook *facebook;
	NSString *facebookID;
}

- (void)back;
- (IBAction)facebookPressed:(UIButton*)sender;
- (IBAction)registerPressed:(UIButton*)sender;
- (IBAction)backgroundTouched:(UIControl*)sender;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification *)note;
- (void)keyboardWasHidden:(NSNotification *)note;

@end
