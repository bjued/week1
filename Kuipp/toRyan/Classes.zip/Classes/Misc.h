//
//  Misc.h
//  Kuipp
//
//  Created by Brandon Jue on 2/26/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@class RefreshCell;

@interface NSString (URLEncoding)

- (NSString*)urlEncodeUsingEncoding:(NSStringEncoding)encoding;
- (NSString*)urlEncode;
- (NSString*)shortURLEncode;

@end

@interface Misc : NSObject {
}

// Debug
+ (int)test;
+ (BOOL)beta;
+ (BOOL)debug;
+ (BOOL)artTest;
+ (NSString*)url;

// Global Constants
+ (NSString*)partyLevel:(int)i;
+ (NSString*)partyLeader:(int)i;
+ (int)maxPartySize;
+ (NSString*)profileTutorialTitle:(int)i;
+ (NSString*)profileTutorialMessage:(int)i;
+ (double)adjustPictureRatio;
+ (NSString*)defaultEditBio;
+ (NSString*)defaultNoBio;
+ (NSArray*)advNames;
+ (NSArray*)advDescs;
+ (NSArray*)medalNames;
+ (NSArray*)medalDescs;
+ (BOOL)tableHideHeaderAnimated;
+ (NSString*)defaultProfileURL;
+ (UIImage*)defaultProfile;
+ (double)locationWithinTime;
+ (int)locationTries;
+ (UIViewContentMode)imageFitStyle;
+ (UIColor*)kuippOrangeColor;
+ (UIColor*)selectedColor;
+ (int)geocodeInterval;
+ (double)footSize;
+ (double)mainSize;
+ (double)nameSize;
+ (double)profileNameSize;
+ (double)buttonFontSize;
+ (double)border;
+ (double)borderCurve;
+ (double)buffer;
+ (double)imageSize;
+ (double)medalSize;
+ (double)leaderSize;
+ (double)profileSize;
+ (double)profMedSize;
+ (double)buttonCellHeight;
+ (UIImage*)buttonCell;
+ (double)refreshCellHeight;
+ (RefreshCell*)refreshCellView;
+ (UIActivityIndicatorView*)activityView;
+ (int)maxCharacters;
+ (double)animations;
+ (BOOL)orientations:(UIInterfaceOrientation)orient;
+ (NSArray*)facebookPermissions;
+ (UIImageView*)logoBar;
+ (UITextField*)cellPasswordField:(id)delegate;
+ (UITextField*)cellTextField:(id)delegate;

// Global Methods
+ (UIImage*)imageWithImage:(UIImage*)image scaledToSize:(CGSize)newSize fromSection:(CGRect)oldRect;
+ (BOOL)validEmail:(NSString*)email;
+ (UIButton*)createToggle:(NSString*)img;
+ (NSString*)base85to10:(NSString*)n;
+ (NSString*)newVersion:(NSString *)v WithBuild:(NSString *)b;
+ (void)firstTime:(NSString *)p;
+ (void)locationDenied;
+ (void)locationFailed;
+ (void)fitMapAnnotations:(MKMapView *)mapView;
+ (void)centerMapView:(MKMapView*)map onLoc:(CLLocationCoordinate2D)loc withSpan:(double)sp;
+ (NSString*)reverseGeocode:(MKPlacemark*)placemark;
+ (UIControl*)leftPin:(NSDictionary*)d;
+ (UIControl*)rightPin:(NSString*)img;
+ (void)load:(UIViewController*)delegate;
+ (UIImageView*)detailDisclosure;
+ (UIImageView*)detailExpanded;
+ (UIImageView*)checkmark;
+ (UIImageView*)checkmarkPlaceholder;
+ (UIColor*)barColor;
+ (UIColor*)bgColor;
+ (UIBarButtonItem*)mapList:(int)tab;
+ (UIBarButtonItem*)pointBarButtonItem:(NSString*)title;
+ (UIBarButtonItem*)barButtonItemViewWithTitle:(NSString*)title;
+ (UIBarButtonItem*)barButtonItemViewWithImage:(NSString*)img;
+ (UIImage*)roundTeal;
+ (UIImage*)wideTabImage:(BOOL)b;
+ (UIImage*)tabImage:(BOOL)b;
+ (double)heightForFontSize:(double)i;
+ (double)heightForText:(NSString *)s width:(double)w size:(double)i;
+ (void)noCover:(UIControl*)sender;
+ (void)blueCover:(UIControl*)sender;
+ (void)whiteCover:(UIControl*)sender;
+ (NSString*)nameFromDict:(NSDictionary *)d;
+ (NSString*)first:(NSString*)first lastName:(NSString*)last;
+ (NSString*)first:(NSString*)first lastName:(NSString*)last otherText:(NSString*)text;
+ (NSString*)timeSinceNow:(NSString*)date;
+ (void)updateUserSettings:(NSDictionary*)d;

@end
