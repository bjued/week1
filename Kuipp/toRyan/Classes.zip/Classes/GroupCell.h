//
//  GroupCell.h
//  Kuipp
//
//  Created by Brandon Jue on 4/8/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GroupCell : UITableViewCell {
	BOOL selectable;
	
	UIView *bkgd;
	
	id item;
	UILabel *label;
	
	UIView *tLine;
	
	UIView *bLine;
}

@property(nonatomic,assign) BOOL selectable;
@property(nonatomic,retain) id item;
@property(nonatomic,retain) UILabel *label;

@end
