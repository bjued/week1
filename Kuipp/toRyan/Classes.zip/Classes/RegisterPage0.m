//
//  RegisterPage0.m
//  Kuipp
//
//  Created by Brandon Jue on 4/23/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "RegisterPage0.h"
#import "RegisterPage1.h"
#import "RegisterPage2.h"
#import "ButtonCell.h"

@implementation RegisterPage0

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)facebookAccount {
	facebook = ((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).facebook;
	
	NSArray *permissions = [[Misc facebookPermissions]retain];
	
	[facebook authorize:permissions delegate:self];
	
	[permissions release];
}

- (void)kuippAccount {
	RegisterPage1 *r = [[RegisterPage1 alloc]init];
	[self.navigationController pushViewController:r animated:YES];
	[r release];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return 4;}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCellStyle s = UITableViewCellStyleDefault;
	
	switch (indexPath.row) {
		case  1: {
			ButtonCell *c = (ButtonCell*)[tableView dequeueReusableCellWithIdentifier:@"B"];
			if (!c) c = [[[ButtonCell alloc]initWithStyle:s reuseIdentifier:@"B"]autorelease];
			
			[c.button setTitle:@"" forState:UIControlStateNormal];
			[c.button addTarget:self action:@selector(facebookAccount) forControlEvents:UIControlEventTouchUpInside];
			[c.button setBackgroundImage:[UIImage imageNamed:@"X-Large_278x44"]forState:UIControlStateNormal];
			[c.button setBackgroundImage:[UIImage imageNamed:@"X-Large_278x44_glowy"]forState:UIControlStateSelected|UIControlStateHighlighted];
			
			c.noStretch = YES;
			return c;
		} case  2: {
			UITableViewCell *c = [tableView dequeueReusableCellWithIdentifier:@"or"];
			if (!c) c = [[[UITableViewCell alloc]initWithStyle:s reuseIdentifier:@"or"]autorelease];
			
			c.textLabel.text = @"or";
			c.textLabel.textAlignment = UITextAlignmentCenter;
			c.textLabel.textColor = [UIColor whiteColor];
			c.textLabel.font = [UIFont boldSystemFontOfSize:[Misc nameSize]];
			
			c.selectionStyle = UITableViewCellSelectionStyleNone;
			return c;
		} case  3: {
			ButtonCell *c = (ButtonCell*)[tableView dequeueReusableCellWithIdentifier:@"B"];
			if (!c) c = [[[ButtonCell alloc]initWithStyle:s reuseIdentifier:@"B"]autorelease];
			
			[c.button setTitle:@"Kuipp Account" forState:UIControlStateNormal];
			[c.button addTarget:self action:@selector(kuippAccount) forControlEvents:UIControlEventTouchUpInside];
			return c;
		} default: {
			UITableViewCell *c = [tableView dequeueReusableCellWithIdentifier:@"or"];
			if (!c) c = [[[UITableViewCell alloc]initWithStyle:s reuseIdentifier:@"or"]autorelease];
			
			c.textLabel.text = @"Register through";
			c.textLabel.textAlignment = UITextAlignmentCenter;
			c.textLabel.textColor = [UIColor whiteColor];
			c.textLabel.font = [UIFont boldSystemFontOfSize:[Misc profileNameSize]];
			
			c.selectionStyle = UITableViewCellSelectionStyleNone;
			return c;
		}
	}
}
								
#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath {
	double buf = [Misc buffer];
	double bch = [Misc buttonCellHeight];
	if (indexPath.row==1) return buf*2+44;
	if (indexPath.row==3) return buf*2+bch;
	return 44;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {[tableView deselectRowAtIndexPath:indexPath animated:YES];}

#pragma mark -
#pragma mark FBRequestDelegate

- (void)request:(FBRequest *)request didLoad:(id)result {
	if ([result isKindOfClass:[NSDictionary class]]) {
		RegisterPage2 *r = [[RegisterPage2 alloc]init];
		r.fName = [NSString stringWithString:[result objectForKey:@"first_name"]];
		r.lName = [NSString stringWithString:[result objectForKey:@"last_name"]];
		r.email = [NSString stringWithString:[result objectForKey:@"email"]];
		r.facebookID = [NSString stringWithString:[result objectForKey:@"id"]];
		
		[self.navigationController pushViewController:r animated:YES];
		[r release];
	}	
}

- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {NSLog(@"%@",error);}

#pragma mark -
#pragma mark FBSessionDelegate

- (void)fbDidLogin {[facebook requestWithGraphPath:@"me" andDelegate:self];}

- (void)fbDidNotLogin:(BOOL)cancelled {NSLog(@"Failed to log into facebook. User canceled? %@",cancelled?@"YES":@"NO");}

#pragma mark -
#pragma mark Memory management

- (void)viewDidLoad {
	[super viewDidLoad];
	
	[Misc load:self];
	
	[table reloadData];
}

/*
 - (void)viewWillAppear:(BOOL)animated {
 [super viewWillAppear:animated];
 }
 
 - (void)viewDidAppear:(BOOL)animated {
 [super viewDidAppear:animated];
 }
 
 - (void)viewWillDisappear:(BOOL)animated {
 [super viewWillDisappear:animated];
 }
 
 - (void)viewDidDisappear:(BOOL)animated {
 [super viewDidDisappear:animated];
 }
 */

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}

@end
