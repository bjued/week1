//
//  SettingsConnect.h
//  Kuipp
//
//  Created by Brandon Jue on 2/10/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Facebook.h"

@interface SettingsConnect : UIViewController <FBSessionDelegate> {
	IBOutlet UITableView *table;
	
	Facebook *facebook;
}

- (IBAction)popBack:(UIButton*)sender;
- (void)inviteFacebook;

@end
