//
//  UrQA.h
//  Kuipp
//
//  Created by Brandon Jue on 3/17/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

@interface UrQA : UIViewController <MKMapViewDelegate,UISearchBarDelegate,UIScrollViewDelegate,UITableViewDelegate> {
	NSString *uid;
	
	int tab;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	
	RefreshCell *refreshCell;
	UIActivityIndicatorView *moreCell;
	
	NSString *lastIDs;
	NSString *counts;
	
	NSMutableArray *questions;
	NSMutableArray *answers;
	
	NSMutableArray *tabResults;
	NSMutableArray *searchResults;
	
	IBOutlet UIButton *qButton;
	IBOutlet UIButton *aButton;
	
	IBOutlet UISearchBar *search;
	IBOutlet UITableView *table;
	IBOutlet MKMapView *map;
}

@property(nonatomic,retain) NSString *uid;
- (void)back;
- (void)refreshMore;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)splitData;
- (IBAction)filter:(UIButton*)sender;
- (void)filtered:(UIButton *)sender;
- (void)reloadView;
- (void)reloadMap;
- (void)reloadTable;
- (void)listMap:(UIButton *)sender;
- (void)toProfile:(UIControl *)sender;
- (void)applySearchField:(UISearchBar *)searchBar;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
