//
//  TextCell.h
//  Kuipp
//
//  Created by Brandon Jue on 3/13/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TextCell : UITableViewCell {
	BOOL selectable;
	
	UIView *cell;
	
	UILabel *main;
	UILabel *foot;
}

@property(nonatomic,assign) BOOL selectable;
@property(nonatomic,retain) UILabel *main,*foot;

@end
