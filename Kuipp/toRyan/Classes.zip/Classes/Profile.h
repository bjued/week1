//
//  Profile.h
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Facebook.h"

@interface Profile : UIViewController <FBRequestDelegate,FBSessionDelegate,UIAlertViewDelegate,UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,UITextFieldDelegate,UITextViewDelegate,UIGestureRecognizerDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate> {
	NSString *uid;
	BOOL firstTime;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableArray *catArray;
	NSMutableDictionary *images;
	
	RefreshCell *refreshCell;
	
	Facebook *facebook;
	
	NSDictionary *user;
	NSDictionary *question;
	NSDictionary *answer;
	NSDictionary *level;
	NSDictionary *medal;
	
	IBOutlet UIView *bar;
	IBOutlet UIButton *mButton;
	IBOutlet UIButton *cButton;
	IBOutlet UIButton *aButton;
	
	IBOutlet UIView *top;
	IBOutlet UIView *bot;
	IBOutlet UITableView *table;
	UITextView *bio;
	
	// Message Overlay
	IBOutlet UITextField *subject;
	IBOutlet UITextView *body;
	IBOutlet UILabel *to;
	int toID;
	IBOutlet UILabel *count;
	
	// Picture Adjusting
	UIView *picView;
	CGPoint picPoint;
	double picZoom;
	UIControl *picFrame;
	UIImageView *picImage;
	UIImagePickerController *picker;
	UIButton *picFB,*picFile,*picTake;
	NSString *picURL;
	UIActivityIndicatorView *activity;
	BOOL local;
	
	UIBarButtonItem *storedLeftBarButtonItem;
}

@property(nonatomic,retain) NSString *uid;
@property(nonatomic,readonly) BOOL firstTime;
- (void)back;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)refreshCount;
- (void)splitData;
- (void)follow;
- (void)unfollow;
- (IBAction)sendMsg:(UIButton*)sender;
- (IBAction)messages:(UIButton*)sender;
- (IBAction)connections:(UIButton*)sender;
- (IBAction)interests:(UIButton*)sender;
- (IBAction)activity:(UIButton*)sender;
- (void)medals;
- (void)settings;
- (void)cancel;
- (void)send:(UIBarButtonItem*)sender;
- (void)send;
- (void)editBio;
- (void)adjustPicture;
- (void)picturePopout:(BOOL)b;
- (void)pictureReturned:(NSString*)animationID finished:(BOOL)finished context:(void*)context;
- (void)pickFB:(UIButton*)sender;
- (void)getFBPic;
- (void)pickFile:(UIButton*)sender;
- (void)pickTake:(UIButton*)sender;
- (void)toggleButton:(UIButton*)sender;
- (void)pan:(UIPanGestureRecognizer *)pan;
- (void)pinch:(UIPinchGestureRecognizer *)pinch;
- (void)commitPicture;
- (void)profileTutorial:(int)i;
- (void)keyboardAdjust:(NSNotification*)note:(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
