//
//  KuippAppDelegate.h
//  Kuipp
//
//  Created by Brandon Jue on 12/14/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import "Facebook.h"
#import "KuippConnect.h"

@interface KuippAppDelegate : NSObject <UIApplicationDelegate,UIAlertViewDelegate,UITabBarControllerDelegate,CLLocationManagerDelegate,MKReverseGeocoderDelegate> {
    UIWindow *window;
	UIViewController *loadingViewController;
    UINavigationController *navigationController;
	UITabBarController *tabBarController;
	Facebook *facebook;
	
	NSMutableDictionary *images;
	NSMutableDictionary *categories;
	NSMutableDictionary *interests;
	NSMutableDictionary *followingIDs;
	
	NSDictionary *alert;
	
	BOOL firstUpdate;
	NSDate *lastPlUpdate;
	CLLocationManager *clLocMan;
	CLLocation *userLoc;
	MKReverseGeocoder *mkRevGeo;
	MKPlacemark *userPlace;
	
	KuippConnect *kuipp;
}

@property(nonatomic,retain) NSMutableDictionary *images;
@property(nonatomic,retain) NSMutableDictionary *categories;
@property(nonatomic,retain) NSMutableDictionary *interests;
@property(nonatomic,retain) NSMutableDictionary *followingIDs;
@property(nonatomic,retain) NSDictionary *alert;
@property(nonatomic,retain) IBOutlet UIWindow *window;
@property(nonatomic,retain) IBOutlet UIViewController *loadingViewController;
@property(nonatomic,retain) IBOutlet UINavigationController *navigationController;
@property(nonatomic,retain) IBOutlet UITabBarController *tabBarController;
@property(nonatomic,retain) Facebook *facebook;
@property(nonatomic,retain) CLLocation *userLoc;
@property(nonatomic,retain) MKPlacemark *userPlace;
- (void)rateMe;
- (void)reloadTabs;
- (void)toMainApp:(NSMutableArray*)d;
- (void)firstLogin:(NSMutableArray*)d;
- (void)toLogin;
- (void)toAlert;

@end
