//
//  Friends.h
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Friends : UIViewController <UITableViewDelegate,UITextFieldDelegate,UISearchBarDelegate,UIAlertViewDelegate> {
	NSMutableArray *dicts;
	NSMutableArray *heads;
	NSString *uid;
	
	NSMutableArray *following;
	NSMutableArray *followers;
	
	IBOutlet UISearchBar *search;
	IBOutlet UITableView *table;
	IBOutlet UITextField *friends;
	
	UITextField *activeField;
	BOOL viewMoved;
	
	NSMutableArray *searchFollowing;
	NSMutableArray *searchFollowers;
}

@property(nonatomic,retain) NSString *uid;
- (IBAction)popBack:(id)sender;
- (IBAction)refresh:(id)sender;
- (void)splitData;
- (IBAction)add:(id)sender;
- (IBAction)backgroundTouched:(id)sender;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;
- (BOOL)searchString:(NSArray *)array inDict:(NSDictionary *)dict;

@end
