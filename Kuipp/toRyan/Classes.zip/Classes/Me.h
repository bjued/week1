//
//  Me.h
//  Kuipp
//
//  Created by Brandon Jue on 2/27/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "Facebook.h"

@interface Me : UIViewController <FBSessionDelegate,CLLocationManagerDelegate,UIScrollViewDelegate,UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UITextViewDelegate,UIAlertViewDelegate> {
	NSString *uid;
	int tab;
	
	NSMutableArray *catArray;
	NSMutableArray *dicts;
	
	NSMutableArray *toUser;
	NSMutableArray *fromUser;
	NSMutableArray *followers;
	NSMutableArray *following;
	
	NSMutableArray *tabResults;
	NSMutableArray *searchResults;
	
	BOOL userSet;
	BOOL questionSet;
	BOOL answerSet;
	BOOL levelSet;
	
	NSDictionary *user;
	NSDictionary *question;
	NSDictionary *answer;
	NSDictionary *level;
	
	IBOutlet UIButton *follow;
	IBOutlet UIButton *sendMsg;
	
	IBOutlet UIView *messageView;
	IBOutlet UIView *interestsView;
	IBOutlet UIView *twitterView;
	IBOutlet UIView *bot;
	IBOutlet UITableView *table;
	
	IBOutlet UIView *bars;
	IBOutlet UIToolbar *profileBar;
	IBOutlet UIToolbar *messageBar;
	IBOutlet UIToolbar *connectionsBar;
	IBOutlet UIToolbar *settingsBar;
	
	IBOutlet UIBarButtonItem *profileButton;
	IBOutlet UIBarButtonItem *messageButton;
	IBOutlet UIBarButtonItem *inboxButton;
	IBOutlet UIBarButtonItem *outboxButton;
	IBOutlet UIBarButtonItem *connectionButton;
	IBOutlet UIBarButtonItem *followingButton;
	IBOutlet UIBarButtonItem *followersButton;
	IBOutlet UIBarButtonItem *settingsButton;
	IBOutlet UISearchBar *search;
	
	// Settings
	IBOutlet UITableView *setTable;
	NSMutableArray *settings;
	NSMutableArray *locationTime;
	UITextField *recent;
	UITextField *local;
	UITextField *oldpwd;
	UITextField *newpwd;
	UITextField *confirm;
	NSMutableArray *findConnections;
	NSMutableArray *notifications;
	Facebook *facebook;
	IBOutlet UIView *input;
	IBOutlet UIBarButtonItem *period;
	IBOutlet UIBarButtonItem *options;
	IBOutlet UIBarButtonItem *backCancelSettingsButton;
	IBOutlet UIBarButtonItem *saveSettingsButton;
	
	// Twitter SN Overlay
	IBOutlet UITextField *twitter;
	
	// Interests Overlay
	IBOutlet UIButton *category;
	IBOutlet UITextField *interest;
	int catID;
	UITableView *catTable;
	
	// Message Overlay
	IBOutlet UITextField *subject;
	IBOutlet UITextView *body;
	IBOutlet UILabel *to;
	int toID;
	IBOutlet UILabel *count;
	UITableView *folTable;
	
	// Location Handling
	CLLocationManager *manager;
	CLLocation *userLoc;
	
}

@property(nonatomic,assign) int toID;
@property(nonatomic,assign) int tab;
@property(nonatomic,retain) NSString *uid;
- (IBAction)refresh:(UIBarButtonItem*)sender;
- (void)refreshCount;
- (void)refreshTo;
- (void)refreshCategory;
- (void)splitData;
- (void)filter:(UIBarButtonItem *)sender;
- (IBAction)to:(UIButton*)sender;
- (IBAction)compose:(UIBarButtonItem*)sender;
- (IBAction)cancel:(UIBarButtonItem*)sender;
- (IBAction)send:(UIBarButtonItem*)sender;
- (void)send;
- (IBAction)addInterests:(UIBarButtonItem*)sender;
- (IBAction)categoryTable:(UIButton*)sender;
- (IBAction)add:(UIBarButtonItem*)sender;
- (void)add;
- (void)toggleBars;
- (IBAction)toggleFilter:(UIBarButtonItem*)sender;
- (IBAction)toggleSearch:(UIBarButtonItem*)sender;
- (IBAction)toggleSettings:(UIButton*)sender;
- (IBAction)backSettings:(UIBarButtonItem*)sender;
- (IBAction)cancelSettings:(UIBarButtonItem*)sender;
- (IBAction)saveSettings:(UIBarButtonItem*)sender;
- (void)settingsChanged:(BOOL)itDid;
- (void)cancelKB:(UIBarButtonItem *)sender;
- (IBAction)numberPadButtonPressed:(UIBarButtonItem*)sender;
- (void)inviteFacebook;
- (void)inviteTwitter;
- (void)inputTwitter;
- (void)submitTwitter;
- (UITableViewCell*)profileTableCell:(NSIndexPath *)indexPath;
- (UITableViewCell*)settingTableCell:(NSIndexPath *)indexPath;
- (UITableViewCell*)messageTableCell:(NSIndexPath *)indexPath;
- (UITableViewCell*)connectionTableCell:(NSIndexPath *)indexPath;
- (void)keyboardAdjust:(NSNotification*)note:(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;
- (BOOL)searchString:(NSArray *)array inDict:(NSDictionary *)dict;
- (void)applySearchField:(UISearchBar *)searchBar;

@end
