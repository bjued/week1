//
//  LogoCell.m
//  Kuipp
//
//  Created by Brandon Jue on 4/23/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "LogoCell.h"


@implementation LogoCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        // Initialization code.
		logo = [[UIImageView alloc]init];
		logo.contentMode = UIViewContentModeScaleAspectFit;
		logo.image = [UIImage imageNamed:@"Kuipp LoginLogo"];
		logo.backgroundColor = [UIColor clearColor];
		
		
		text = [[UILabel alloc]init];
		text.text = @"What do you want to know?";
		text.textColor = [Misc kuippOrangeColor];
		text.font = [UIFont boldSystemFontOfSize:[Misc profileNameSize]];
		text.backgroundColor = [UIColor clearColor];
		text.textAlignment = UITextAlignmentCenter;
		
		[self.contentView addSubview:logo];
		[self.contentView addSubview:text];
		
		self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect c = self.contentView.bounds;
	double w = c.size.width;
	double h = c.size.height;
	
	double ns = [Misc profileNameSize];
	double buf = [Misc buffer];
	
	logo.frame = CGRectMake(buf*2, buf*2, w-buf*4, h-buf*4-ns);
	text.frame = CGRectMake(buf*2, h-buf*2-ns, w-buf*4, ns);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}


- (void)dealloc {
    [super dealloc];
}


@end
