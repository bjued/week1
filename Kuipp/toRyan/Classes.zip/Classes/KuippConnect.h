//
//  KuippConnect.h
//  Kuipp
//
//  Created by Brandon Jue on 12/26/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KuippConnect : NSObject <UIAlertViewDelegate> {
	NSURLConnection *connection;
	NSMutableData *data;
	UIViewController *owner;
}

@property(nonatomic,retain) UIViewController *owner;
@property(nonatomic,retain) NSMutableData *data;
+ (NSString*)urlString:(NSString *)page;
- (void)formTo:(NSString*)page;
- (void)formTo:(NSString*)page WithPost:(NSString*)poststring;
- (void)cancel;
- (BOOL)fetchingData;
+ (NSString*)formTo:(NSString*)page WithPost:(NSString*)poststring AndResponse:(NSURLResponse**)response AndError:(NSError**)error;
+ (NSString*)connectionData:(NSData*)d;
+ (BOOL)checkSessionCode:(NSString*)code forView:(UIViewController*)view;
+ (BOOL)errorCode:(NSString *)err;

@end
