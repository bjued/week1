//
//  LineCell.h
//  Kuipp
//
//  Created by Brandon Jue on 3/14/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LineCell : UITableViewCell {
	BOOL selectable;
	
	UIView *cell;
	
	UILabel *main;
}

@property(nonatomic,assign) BOOL selectable;
@property(nonatomic,retain) UILabel *main;

@end
