//
//  Map.m
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "Map.h"
#import "Profile.h"
#import "Question.h"
#import "Pin.h"
#import "KuippConnect.h"
#import "Parser.h"

@implementation Map

- (IBAction)popBack:(UIButton*)sender {
	[self.navigationController popToViewController:[[self.navigationController viewControllers]objectAtIndex:1] animated:YES];
}

- (IBAction)refresh:(UIButton*)sender {
	[manager startUpdatingLocation];
}

- (void)refresh {
	if (userLoc==nil) return;
	[manager stopUpdatingLocation];
	
	MKCoordinateRegion region = map.region;
	region.span.longitudeDelta = .01;
	region.span.latitudeDelta = .01;
	
	region.center.latitude = userLoc.coordinate.latitude;
	region.center.longitude = userLoc.coordinate.longitude;
	
	[map setRegion:region animated:YES];
	[map regionThatFits:region];
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=0"
							@"&rct=%@"
							@"&lat=%.8f"
							@"&lon=%.8f",
							[[NSUserDefaults standardUserDefaults]objectForKey:@"recent"],
							userLoc.coordinate.latitude,
							userLoc.coordinate.longitude];
	
	NSString *urlContents = [KuippConnect formTo:@"selectQuestions" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:1]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode forView:self]) return;
	
	if (dicts!=nil) [dicts release];
	if (heads!=nil) [heads release];
	dicts = [[NSMutableArray alloc]init];
	heads = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts AndHeads:heads];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	
	for (int i=0;i<[questions count];i++) {
		NSDictionary *dict = [questions objectAtIndex:i];
		
		Pin *point= [[Pin alloc]init];
		[point setCoordinate:CLLocationCoordinate2DMake([[dict objectForKey:@"latitude"]doubleValue],[[dict objectForKey:@"longitude"]doubleValue])];
		[point setTitle:[NSString stringWithFormat:@"%@ %@.",[dict objectForKey:@"firstName"],[[dict objectForKey:@"lastName"]substringToIndex:1]]];
		[point setSubtitle:[dict objectForKey:@"question"]];
		point.dict = dict;
		[map addAnnotation:point];
		[point release];
	}
}

- (void)splitData {
	if (questions!=nil) [questions release];
	questions = [[NSMutableArray alloc]init];
	
	for (int i=0;i<[heads count];i++) {
		if ([[heads objectAtIndex:i]isEqualToString:@"Questions"]) {
			NSMutableDictionary *dict = [dicts objectAtIndex:i];
			if (i==0) [questions addObject:dict];
			if ([[dict objectForKey:@"questionID"]intValue]==[[[questions lastObject]objectForKey:@"questionID"]intValue]) {
				if ([[dict objectForKey:@"d"]intValue]==1) [[questions lastObject]setObject:@"1" forKey:@"d"];
				else if ([[dict objectForKey:@"f"]intValue]==1) [[questions lastObject]setObject:@"1" forKey:@"f"];
				else if ([[dict objectForKey:@"k"]intValue]==1) [[questions lastObject]setObject:@"1" forKey:@"k"];
				else if ([[dict objectForKey:@"l"]intValue]==1) [[questions lastObject]setObject:@"1" forKey:@"l"];
			} else {
				[questions addObject:dict];
			}
		}
	}
}

#pragma mark -
#pragma mark MKMapViewDelegate

- (MKAnnotationView*)mapView:(MKMapView*)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
	MKPinAnnotationView *pin = nil;
	pin = (MKPinAnnotationView*)[map dequeueReusableAnnotationViewWithIdentifier:@"mapPin"];
	if (pin==nil) {
		pin = [[[MKPinAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:@"mapPin"]autorelease];
	}
	pin.canShowCallout = YES;
	pin.animatesDrop = YES;
	pin.leftCalloutAccessoryView = pinLeft;
	pin.rightCalloutAccessoryView = pinRight;
	
	if (annotation==map.userLocation) return pin;
	int qUserID = [[((Pin*)annotation).dict objectForKey:@"userID"]intValue];
	if ([[((Pin*)annotation).dict objectForKey:@"f"]intValue]==1) pin.pinColor = MKPinAnnotationColorRed;
	else if (qUserID==uid) pin.pinColor = MKPinAnnotationColorPurple;
	else pin.pinColor = MKPinAnnotationColorGreen;
	
	return pin;
}
						 
- (void)mapView:(MKMapView*)mapView annotationView:(MKAnnotationView*)annotationView calloutAccessoryControlTapped:(UIControl*)control {
	if (control==pinLeft) {
		Profile *v = [[Profile alloc]init];
		v.uid = [((Pin*)annotationView.annotation).dict objectForKey:@"userID"];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	} else if (control==pinRight) {
		Question *v = [[Question alloc]init];
		v.qid = [((Pin*)annotationView.annotation).dict objectForKey:@"questionID"];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	}
}

#pragma mark -
#pragma mark CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager*)manager didUpdateToLocation:(CLLocation*)newLocation fromLocation:(CLLocation*)oldLocation {
	userLoc = newLocation;
		
	[self refresh];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
	NSLog(@"%@",error);
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Session Error"]) {
		[self.navigationController popToRootViewControllerAnimated:YES];
	}
}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	manager = [[CLLocationManager alloc]init];
	[manager setDelegate:self];
	
	[self refresh:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
	[manager release];
	
	[super viewWillDisappear:YES];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
