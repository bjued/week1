//
//  ASyncImageLoadDelegate.h
//  Kuipp
//
//  Created by Brandon Jue on 3/23/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASyncImageLoadDelegate : NSObject {
	NSString *url;
	NSMutableDictionary *dic;
	NSMutableData *dat;
}

- (id)loadURLString:(NSString*)s intoDictionary:(NSMutableDictionary*)d;

@end
