//
//  ForgotPassword.h
//  Kuipp
//
//  Created by Brandon Jue on 1/29/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgotPassword : UIViewController <UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate,UITextFieldDelegate> {
	IBOutlet UITextField *email;
	
	IBOutlet UITableView *table;
}

- (void)back;
- (void)sendPassword;
- (void)backgroundTouched;

@end
