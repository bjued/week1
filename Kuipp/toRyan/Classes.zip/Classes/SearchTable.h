//
//  SearchTable.h
//  Kuipp
//
//  Created by Brandon Jue on 5/26/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Facebook.h"

@interface SearchTable : UIViewController <UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate>{
	NSString *type;
	UIViewController *askTab;
	UIViewController *compose;
	NSDictionary *checks;
    
	IBOutlet UITableView *table;
	IBOutlet UISearchBar *search;
	
	Facebook *facebook;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableArray *searchArray;
	NSMutableDictionary *images;
}

@property(nonatomic,retain) NSString *type;
@property(nonatomic,retain) UIViewController *askTab,*compose,*party;
@property(nonatomic,retain) NSDictionary *checks;
- (void)back;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)insertChecks;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
