//
//  Cell.m
//  Kuipp
//
//  Created by Brandon Jue on 3/9/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "Cell.h"
#import <QuartzCore/QuartzCore.h>

@implementation Cell

@synthesize cell,dict,back,selectable,ctrl,imag,name,main,foot;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        // Initialization code.
		pict = [[UIView alloc]init];
		pict.layer.masksToBounds = YES;
		pict.layer.cornerRadius = [Misc borderCurve];
		pict.layer.borderColor = [[Misc kuippOrangeColor]CGColor];
		pict.layer.borderWidth = [Misc border];
		
		cell = [[UIView alloc]init];
		cell.layer.masksToBounds = NO;
		cell.layer.cornerRadius = [Misc borderCurve];
		cell.layer.borderColor = [[Misc kuippOrangeColor]CGColor];
		cell.layer.borderWidth = [Misc border];
		
		back = [[UIView alloc]init];
		back.layer.masksToBounds = NO;
		back.layer.cornerRadius = [Misc borderCurve];
		back.layer.borderColor = [[UIColor clearColor]CGColor];
		back.layer.borderWidth = [Misc border];
		
		ctrl = [[UIControl alloc]init];
		ctrl.clipsToBounds = YES;
		ctrl.backgroundColor = [UIColor clearColor];
		[ctrl addTarget:[Misc class]action:@selector(blueCover:) forControlEvents:UIControlEventTouchDown|UIControlEventTouchDragInside];
		[ctrl addTarget:[Misc class]action:@selector(noCover:) forControlEvents:UIControlEventTouchDragOutside|UIControlEventTouchUpInside];
		
		imag = [[UIImageView alloc]init];
		imag.clipsToBounds = YES;
		imag.contentMode = [Misc imageFitStyle];
		imag.backgroundColor = [UIColor clearColor];
		imag.userInteractionEnabled = NO;
		
		name = [[UIButton buttonWithType:UIButtonTypeCustom]retain];
		name.backgroundColor = [UIColor clearColor];
		name.titleLabel.font = [UIFont boldSystemFontOfSize:[Misc nameSize]];
		[name setTitleColor:[Misc kuippOrangeColor]forState:UIControlStateNormal];
		[name setTitleColor:[UIColor blueColor]forState:UIControlStateHighlighted];
		name.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
		[name addTarget:[Misc class]action:@selector(blueCover:) forControlEvents:UIControlEventTouchDown|UIControlEventTouchDragInside];
		[name addTarget:[Misc class]action:@selector(noCover:) forControlEvents:UIControlEventTouchDragOutside|UIControlEventTouchUpInside];
		
		main = [[UILabel alloc]init];
		main.backgroundColor = [UIColor clearColor];
		main.font = [main.font fontWithSize:[Misc mainSize]];
		main.textColor = [UIColor grayColor];
		main.numberOfLines = 2;
		main.lineBreakMode = UILineBreakModeTailTruncation;
		
		foot = [[UILabel alloc]init];
		foot.backgroundColor = [UIColor clearColor];
		foot.font = [foot.font fontWithSize:[Misc footSize]];
		foot.textColor = [UIColor lightGrayColor];
		
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		
		[self.contentView addSubview:cell];
		[self.contentView addSubview:pict];
		[self.contentView addSubview:back];
		[pict addSubview:ctrl];
		[ctrl addSubview:imag];
		[back addSubview:name];
		[back addSubview:main];
		[back addSubview:foot];
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect c = self.contentView.bounds;
	double w = c.size.width;
	double h = c.size.height;
	
	double bdr = [Misc border];
	double buf = [Misc buffer];
	double img = [Misc imageSize];
	
	CGRect a = self.accessoryView.frame;
	double aw = (self.accessoryView==nil?0:(a.size.width+10));
	
	cell.frame = CGRectMake(buf*2+img,buf,w-img-buf*4+aw,h-buf*2);
	
	pict.frame = CGRectMake(buf*2    ,buf,w    -buf*4   ,h-buf*2);  //,,,img
	ctrl.frame = CGRectMake(0        ,  0,  img         ,  img  );
	
	BOOL b = [imag.image isEqual:[Misc defaultProfile]];
	double r = img/[Misc profileSize];
	int picX = [[dict objectForKey:@"picX"]intValue]*r;
	int picY = [[dict objectForKey:@"picY"]intValue]*r;
	double picZ = [[dict objectForKey:@"picZ"]doubleValue]*r;
	CGSize picS = imag.image.size;
	imag.frame = CGRectMake(b?0:picX, b?0:picY, b?img:picS.width*picZ, b?img:picS.height*picZ);
	
	c = cell.frame;
	w = c.size.width;
	h = c.size.height;
	double x = c.origin.x;
	double y = c.origin.y;
	
	back.frame = CGRectMake(x+bdr,y+bdr,w-bdr*2,h-bdr*2);
	
	c = back.bounds;
	w = c.size.width+bdr*2-(self.accessoryView==nil?0:a.size.width);
	h = c.size.height+bdr*2;
	double nh = [Misc heightForFontSize:[Misc nameSize]];
	double mh = fmin(main.numberOfLines==0?9999:[Misc heightForFontSize:[Misc mainSize]]*2,[Misc heightForText:main.text width:w-buf*2 size:[Misc mainSize]]);
	double fh = foot.numberOfLines==0?[Misc heightForText:foot.text width:w-buf*2 size:[Misc footSize]]:[Misc heightForFontSize:[Misc footSize]];
	
	name.frame = CGRectMake(buf-bdr,     buf-bdr,w-buf*2,nh);
	main.frame = CGRectMake(buf-bdr,  nh+buf-bdr,w-buf*2,mh);
	foot.frame = CGRectMake(buf-bdr,h-fh-buf-bdr,w-buf*2,fh);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	cell.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
	pict.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
	back.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)setHighlighted:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	cell.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
	pict.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
	back.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)dealloc {
	[dict release];
	[cell release];
	[back release];
	[ctrl release];
	[imag release];
	[name release];
	[main release];
	[foot release];
	
    [super dealloc];
}

@end
