//
//  AnswerTab.h
//  Kuipp
//
//  Created by Brandon Jue on 2/26/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface AnswerTab : UIViewController <MKMapViewDelegate,UIScrollViewDelegate,UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource> {
	int tab;	// the view Map/List
	int index;
	NSString *pageType;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableDictionary *images;
	
	RefreshCell *refreshCell;
	UIActivityIndicatorView *moreCell;
	
	NSMutableArray *questions;
	NSMutableArray *categories;
	NSMutableArray *keywords;
	
	NSMutableDictionary *lastIDs;
	NSMutableDictionary *counts;
	
	NSMutableArray *tabResults;
	NSMutableArray *searchResults;
	
	CLLocation *userLoc;
	
	IBOutlet UIButton *catButton;
	IBOutlet UIButton *allButton;
	IBOutlet UIButton *folButton;
	
	UIBarButtonItem *listMap;
	
	IBOutlet UISearchBar *search;
	IBOutlet UITableView *table;
	IBOutlet UITableView *sTable;
	
	IBOutlet MKMapView *map;
}

@property(nonatomic,retain) NSString *pageType;
- (void)hide;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshMore;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (IBAction)filter:(UIButton*)sender;
- (void)filtered:(UIButton *)sender;
- (IBAction)filterKeyword:(UIButton*)sender;
- (void)selectInterest:(int)i:(NSString*)interest;
- (void)sortKeywords;
- (void)reloadView;
- (void)reloadMap;
- (void)reloadTable;
- (void)splitData;
- (IBAction)listMap:(UIButton*)sender;
- (void)toProfile:(UIControl *)sender;
- (void)applySearchField:(UISearchBar *)searchBar;

@end
