//
//  LoginView.m
//  Kuipp
//
//  Created by Brandon Jue on 12/14/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "LoginView.h"
#import "RegisterPage0.h"
#import "ForgotPassword.h"
#import "LogoCell.h"
#import "TopCell.h"
#import "BotCell.h"
#import "ButtonCell.h"

@implementation LoginView

- (void)createNew {
	RegisterPage0 *reg = [[RegisterPage0 alloc]init];
	[self.navigationController pushViewController:reg animated:YES];
	[reg release];
}

- (void)forgotPassword {
	ForgotPassword *pwd = [[ForgotPassword alloc]init];
	[self.navigationController pushViewController:pwd animated:YES];
	[pwd release];
}

- (void)login {
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&eml=%@&pwd=%@",
							[email.text urlEncode],
							[password.text urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"login" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect errorCode:urlContents]) return;
	
	NSMutableArray *dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[Misc updateUserSettings:[dicts objectAtIndex:0]];
	
	NSMutableArray *d = [[NSMutableArray alloc]init];
	[d addObject:[dicts objectAtIndex:1]];
	[d addObject:[dicts objectAtIndex:2]];
	[d addObject:[dicts objectAtIndex:3]];
	
	[dicts release];
	
	KuippAppDelegate *delegate = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	[delegate toMainApp:d];
	[d release];
}

- (IBAction)backgroundTouched:(id)sender {
	[email resignFirstResponder];
	[password resignFirstResponder];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return 7;}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCellStyle s = UITableViewCellStyleDefault;
	
	switch (indexPath.row) {
		case  1: {
			TopCell *c = (TopCell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
			if (!c) c = [[[TopCell alloc]initWithStyle:s reuseIdentifier:@"A"]autorelease];
			
			email.frame = c.contentView.bounds;
			[c.contentView addSubview:email];
			
			c.selectable = NO;
			return c;
		} case  2: {
			BotCell *c = (BotCell*)[tableView dequeueReusableCellWithIdentifier:@"B"];
			if (!c) c = [[[BotCell alloc]initWithStyle:s reuseIdentifier:@"B"]autorelease];
			
			password.frame = c.contentView.bounds;
			[c.contentView addSubview:password];
			
			c.selectable = NO;
			return c;
		} case  3: {
			ButtonCell *c = (ButtonCell*)[tableView dequeueReusableCellWithIdentifier:@"C"];
			if (!c) c = [[[ButtonCell alloc]initWithStyle:s reuseIdentifier:@"C"]autorelease];
			
			[c.button setTitle:@"Login" forState:UIControlStateNormal];
			[c.button addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
			return c;
		} case  4: {
			UITableViewCell *c = [tableView dequeueReusableCellWithIdentifier:@"G"];
			if (!c) c = [[[UITableViewCell alloc]initWithStyle:s reuseIdentifier:@"G"]autorelease];
			
			c.backgroundColor = [UIColor clearColor];
			c.selectionStyle = UITableViewCellSelectionStyleNone;
			return c;
		} case  5: {
			ButtonCell *c = (ButtonCell*)[tableView dequeueReusableCellWithIdentifier:@"D"];
			if (!c) c = [[[ButtonCell alloc]initWithStyle:s reuseIdentifier:@"D"]autorelease];
			
			[c.button setTitle:@"Create an Account" forState:UIControlStateNormal];
			[c.button addTarget:self action:@selector(createNew) forControlEvents:UIControlEventTouchUpInside];
			return c;
		} case  6: {
			ButtonCell *c = (ButtonCell*)[tableView dequeueReusableCellWithIdentifier:@"E"];
			if (!c) c = [[[ButtonCell alloc]initWithStyle:s reuseIdentifier:@"E"]autorelease];
			
			[c.button setTitle:@"Forgot Password" forState:UIControlStateNormal];
			[c.button addTarget:self action:@selector(forgotPassword) forControlEvents:UIControlEventTouchUpInside];
			return c;
		} default: { // row = 0
			LogoCell *c = (LogoCell*)[tableView dequeueReusableCellWithIdentifier:@"F"];
			if (!c) c = [[[LogoCell alloc]initWithStyle:s reuseIdentifier:@"F"]autorelease];
			
			return c;
		}
	}
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath {
	double buf = [Misc buffer];
	double bch = [Misc buttonCellHeight];
	if (indexPath.row==0) return 416-(buf*2+bch)*6;
	return buf*2+bch;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	[self backgroundTouched:nil];
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {
	if (textField==email) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
	if (textField==password) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	if (textField==email) {
		[password becomeFirstResponder];
		return NO;
	}
	if (textField==password) {
		[self login];
		return NO;
	}
	[textField resignFirstResponder];
	return YES;
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	CGRect frame = table.frame;
	frame.size.height -= delta*kb.size.height;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	table.frame = frame;
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	
	if (email.editing) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
	if (password.editing) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

- (void)keyboardWasHidden:(NSNotification*)note {[self keyboardAdjust:note:-1];}

#pragma mark -
#pragma mark Initializaion

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	[Misc load:self];
	self.navigationItem.leftBarButtonItem = nil;
	self.navigationItem.titleView = nil;
	self.navigationItem.title = @"";
	
	[table reloadData];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	
	[table reloadData];
}

- (void)viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return [Misc orientations:interfaceOrientation];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}

@end
