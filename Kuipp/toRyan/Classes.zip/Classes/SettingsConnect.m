//
//  SettingsConnect.m
//  Kuipp
//
//  Created by Brandon Jue on 2/10/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "SettingsConnect.h"
#import "InviteFriends.h"
#import "KuippAppDelegate.h"

@implementation SettingsConnect

- (IBAction)popBack:(UIButton*)sender {
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)inviteFacebook {
	InviteFriends *v = [[InviteFriends alloc]init];
	v.at = facebook.accessToken;
	v.tab = 1;
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"]autorelease];
	}
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	cell.backgroundView = [[UIView alloc]init];
	cell.backgroundView.backgroundColor = [UIColor colorWithWhite:.8 alpha:.25];
	cell.textLabel.font = [cell.textLabel.font fontWithSize:12];
	cell.textLabel.backgroundColor = [UIColor clearColor];
	switch (indexPath.row) {
		case  1:
			cell.imageView.image = [UIImage imageNamed:@"RedPin.png"];
			cell.textLabel.text = @"Find Facebook friends";
			break;
		case  2:
			cell.imageView.image = [UIImage imageNamed:@"RedPin.png"];
			cell.textLabel.text = @"Find Twitter friends [NYI]";
			break;
		case  3:
			cell.imageView.image = [UIImage imageNamed:@"profile.png"];
			cell.textLabel.text = @"Find by name";
			break;
		case  4:
			cell.imageView.image = [UIImage imageNamed:@"mail.png"];
			cell.textLabel.text = @"Find by email";
			break;
		default:
			cell.imageView.image = [UIImage imageNamed:@"RedPin.png"];
			cell.textLabel.text = @"Scan my address book";
			break;
	}
	cell.imageView.frame = CGRectMake(4,4,36,36);
	return cell;
}
/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */
/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */
/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */
/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */
#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	switch (indexPath.row) {
		case  1: // Facebook
			facebook = ((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).facebook;
			if (facebook.expirationDate!=nil&&[facebook.expirationDate timeIntervalSinceNow]>0) {
				[self inviteFacebook];
			} else {
				NSArray *permissions = [[NSArray arrayWithObjects:@"email",@"publish_stream",nil]retain];
				
				[facebook authorize:permissions delegate:self];
				
				[permissions release];
			}
			break;
		case  2: break; // Twitter
		default: { // AddressBook, Search Names, Search Friends
			InviteFriends *v = [[InviteFriends alloc]init];
			v.tab = indexPath.row;
			[self.navigationController pushViewController:v animated:YES];
			[v release];
			break;
		}
	}
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark -
#pragma mark FBSessionDelegate

- (void)fbDidLogin {
	[self inviteFacebook];
}

- (void)fbDidNotLogin:(BOOL)cancelled {
	NSLog(@"Failed to log into facebook. User canceled? %@",cancelled);
}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */
/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/
/*
- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
}
 */
/*
- (void)viewWillDisappear:(BOOL)animated {	
	[super viewWillDisappear:animated];
}
 */
/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}

@end
