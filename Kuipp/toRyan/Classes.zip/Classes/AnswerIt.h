//
//  AnswerIt.h
//  Kuipp
//
//  Created by Brandon Jue on 12/22/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface AnswerIt : UIViewController <CLLocationManagerDelegate,UITextViewDelegate,UIAlertViewDelegate> {
	NSMutableDictionary *dict;
	
	IBOutlet UILabel *Quser;
	IBOutlet UITextView *Qquestion;
	IBOutlet UITextView *Aanswer;
	IBOutlet UILabel *Acount;
	
	BOOL viewMoved;
	
	CLLocationManager *manager;
	CLLocation *userLoc;
}

@property(nonatomic,retain) NSMutableDictionary *dict;
- (IBAction)popBack:(id)sender;
- (void)refresh;
- (void)refreshCount;
- (IBAction)answerIt:(id)sender;
- (void)answerIt;
- (void)backgroundTouched:(id)sender;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification *)note;
- (void)keyboardWasHidden:(NSNotification *)note;

@end
