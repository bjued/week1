//
//  Interests.h
//  Kuipp
//
//  Created by Brandon Jue on 3/16/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Interests : UIViewController <UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate> {
	NSString *uid;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	
	IBOutlet UIView *top;
	IBOutlet UIView *bot;
	
	IBOutlet UITableView *table;
	
	IBOutlet UILabel *count;
	IBOutlet UITextField *interest;
}

@property(nonatomic,retain) NSString *uid;
- (void)back;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)refreshCountKey;
- (void)cancel;
- (void)addInterests;
- (IBAction)add:(UIButton*)sender;
- (void)add;
- (void)deleteInterest:(int)index;

@end
