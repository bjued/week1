//
//  ForgotPassword.m
//  Kuipp
//
//  Created by Brandon Jue on 1/29/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "ForgotPassword.h"
#import "FullCell.h"
#import "ButtonCell.h"
#import "LogoCell.h"

@implementation ForgotPassword

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)sendPassword {
	NSURLResponse *r;
	NSError *e;
	
	NSString *p = [NSString stringWithFormat:@"&eml=%@",[email.text urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"forgot" WithPost:p AndResponse:&r AndError:&e];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect errorCode:urlContents]) return;
	
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Reset Password Sent"
						  message:@"An email has been sent to reset your password."
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
}

- (void)backgroundTouched {[email resignFirstResponder];}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return 4;}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCellStyle s = UITableViewCellStyleDefault;
	
	switch (indexPath.row) {
		case  1: {
			FullCell *c = (FullCell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
			if (!c) c = [[[FullCell alloc]initWithStyle:s reuseIdentifier:@"A"]autorelease];
			
			c.item = email;
			[c.contentView addSubview:c.item];
			
			c.selectable = NO;
			return c;
		} case  3: {
			ButtonCell *c = (ButtonCell*)[tableView dequeueReusableCellWithIdentifier:@"D"];
			if (!c) c = [[[ButtonCell alloc]initWithStyle:s reuseIdentifier:@"D"]autorelease];
			
			[c.button setTitle:@"Send Password" forState:UIControlStateNormal];
			[c.button addTarget:self action:@selector(sendPassword) forControlEvents:UIControlEventTouchUpInside];
			return c;
		} default: { 
			UITableViewCell *c = [tableView dequeueReusableCellWithIdentifier:@"Z"];
			if (!c) c = [[[UITableViewCell alloc]initWithStyle:s reuseIdentifier:@"Z"]autorelease];
			
			c.backgroundColor = [UIColor clearColor];
			c.selectionStyle = UITableViewCellSelectionStyleNone;
			return c;
		}
	}	
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath {
	double buf = [Misc buffer];
	double bch = [Misc buttonCellHeight];
	return buf*2+bch;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	[self backgroundTouched];
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[self sendPassword];
	[textField resignFirstResponder];
	return YES;
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Reset Password Sent"]) {
		[self.navigationController popViewControllerAnimated:YES];
	}
}

#pragma mark -
#pragma mark Initialization

- (void)viewDidLoad {
    [super viewDidLoad];
	
	[Misc load:self];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}

@end
