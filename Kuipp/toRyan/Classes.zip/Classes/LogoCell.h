//
//  LogoCell.h
//  Kuipp
//
//  Created by Brandon Jue on 4/23/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LogoCell : UITableViewCell {
	UIImageView *logo;
	UILabel *text;
}

@end
