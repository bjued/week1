//
//  ProfileCard.h
//  Kuipp
//
//  Created by Brandon Jue on 2/3/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileCard : UITableViewCell {
	NSString *nameID;
	
	IBOutlet UIButton *bigBox;
	IBOutlet UIWebView *profilePic;
	IBOutlet UIImageView *classPic;
	IBOutlet UILabel *name;
	IBOutlet UILabel *points;
	IBOutlet UIButton *interests;
	IBOutlet UIView *boxes;
	IBOutlet UILabel *classTitle;
	IBOutlet UILabel *level;
	IBOutlet UILabel *medals;
	IBOutlet UILabel *gold;
}

@property(nonatomic,retain) NSString *nameID;
@property(nonatomic,retain) IBOutlet UIButton *bigBox;
@property(nonatomic,retain) IBOutlet UIWebView *profilePic;
@property(nonatomic,retain) IBOutlet UIImageView *classPic;
@property(nonatomic,retain) IBOutlet UILabel *name;
@property(nonatomic,retain) IBOutlet UILabel *points;
@property(nonatomic,retain) IBOutlet UIButton *interests;
@property(nonatomic,retain) IBOutlet UIView *boxes;
@property(nonatomic,retain) IBOutlet UILabel *classTitle;
@property(nonatomic,retain) IBOutlet UILabel *level;
@property(nonatomic,retain) IBOutlet UILabel *medals;
@property(nonatomic,retain) IBOutlet UILabel *gold;
//- (IBAction)medalsPressed:(UIButton*)sender;
//- (IBAction)interestsPressed:(UIButton*)sender;

@end
