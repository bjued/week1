//
//  AnswerIt.m
//  Kuipp
//
//  Created by Brandon Jue on 12/22/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "AnswerIt.h"
#import "Answer.h"
#import "Question.h"
#import	"KuippConnect.h"
#import "Parser.h"

@implementation AnswerIt

@synthesize dict;

- (IBAction)popBack:(id)sender {
	[self.navigationController popToViewController:[[self.navigationController viewControllers]objectAtIndex:1] animated:YES];
}

- (void)refresh {
	[Quser setText:[NSString stringWithFormat:
					@"%@\'s Question",
					[dict objectForKey:@"username"]]];
	[Qquestion setText:[dict objectForKey:@"question"]];
	[Aanswer setText:@""];
	[self refreshCount];
}

- (void)refreshCount {
	[Acount setText:[NSString stringWithFormat:
					 @"%d",
					 150-[Aanswer.text length]]];
}

- (IBAction)answerIt:(id)sender {
	if ([Aanswer.text length]==0) {
		NSLog(@"There isn't an answer to send.");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Error"
				 message:@"There isn't an answer to send."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else {
		[manager startUpdatingLocation];
	}
}

- (void)answerIt {
	if (userLoc==nil) return;
	[manager stopUpdatingLocation];
	
	NSURLResponse *response;
	NSError *error;
	
	CLLocation *loc = [[CLLocation alloc]initWithLatitude:[[dict objectForKey:@"latitude"]doubleValue]longitude:[[dict objectForKey:@"longitude"]doubleValue]];
	NSString *poststring = [NSString stringWithFormat:
							@"&questionID=%@"
							@"&userID=0"
							@"&answer=%@"
							@"&latitude=%.8f"
							@"&longitude=%.8f"
							@"&dist=%f",
							[dict objectForKey:@"questionID"],
							Aanswer.text,
							userLoc.coordinate.latitude,
							userLoc.coordinate.longitude,
							fabs([loc distanceFromLocation:userLoc]/1609.344)];
	
	NSLog(@"%@ to %@ = %f",loc,userLoc,fabs([loc distanceFromLocation:userLoc]/1609.344));	[loc release];
	
	NSString *urlContents = [KuippConnect formTo:@"insertAnswer" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:2]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode/10 forView:self]) return;
	if (![KuippConnect answerItCode:exitCode%10 forView:self]) return;
	
	NSMutableArray *views = [NSMutableArray arrayWithArray:[self.navigationController viewControllers]];
	while (![[views objectAtIndex:[views count]-1]isKindOfClass:[Question class]]) {
		[views removeObjectAtIndex:[views count]-1];
	}
	[self.navigationController setViewControllers:views animated:YES];
}

- (void)backgroundTouched:(id)sender {
	[Aanswer resignFirstResponder];
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	if (viewMoved&&delta==1) return;
	
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	int shiftView = 216-176;
	
	CGRect frame = self.view.frame;
	frame.origin.y -= delta*shiftView;
	frame.size.height += delta*shiftView;
	
	int shrinkAnswer = 80;
	
	CGRect textFrame = Aanswer.frame;
	textFrame.size.height -= delta*shrinkAnswer;
	
	CGRect countFrame = Acount.frame;
	countFrame.origin.y -= delta*shrinkAnswer;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	self.view.frame = frame;
	Aanswer.frame = textFrame;
	Acount.frame = countFrame;
	[UIView commitAnimations];	
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	viewMoved = YES;
}

- (void)keyboardWasHidden:(NSNotification*)note {
    if (!viewMoved) return;
	[self keyboardAdjust:note:-1];
	viewMoved = NO;
}

#pragma mark -
#pragma mark UITextViewDelegate

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
	if ([text isEqualToString:@"\n"]) {
		[textView resignFirstResponder];
		return NO;
	}
	int newCount = [Acount.text intValue]-[text length]+range.length;
	if (newCount<0) {
		return NO;
	}
	return YES;
}

- (void)textViewDidChange:(UITextView *)textView {
	if (textView==Aanswer) {
		[self refreshCount];
	}
}

#pragma mark -
#pragma mark CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager*)manager didUpdateToLocation:(CLLocation*)newLocation fromLocation:(CLLocation*)oldLocation {
	userLoc = newLocation;
	
	[self answerIt];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
	NSLog(@"%@",error);
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Session Error"]) {
		[self.navigationController popToRootViewControllerAnimated:YES];
	}
}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad {
 [super viewDidLoad];
 }
 */
- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	manager = [[CLLocationManager alloc]init];
	[manager setDelegate:self];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	
	[Aanswer setText:@""];
	
	[self refresh];
}

- (void)viewWillDisappear:(BOOL)animated {
	[manager release];
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	[super viewWillDisappear:animated];
}

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[dict release];
	
    [super dealloc];
}


@end
