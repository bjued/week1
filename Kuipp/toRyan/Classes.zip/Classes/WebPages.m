//
//  WebPages.m
//  Kuipp
//
//  Created by Brandon Jue on 4/24/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "WebPages.h"

@implementation WebPages

@synthesize url;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

#pragma mark -
#pragma mark initialization

/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	NSURLRequest *r = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
	[web loadRequest:r];
	
	[Misc load:self];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	web.delegate = nil;
	[web release];
	web = nil;
	
	[url release];
	
    [super dealloc];
}

@end
