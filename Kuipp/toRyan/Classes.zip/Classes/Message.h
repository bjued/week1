//
//  Message.h
//  Kuipp
//
//  Created by Brandon Jue on 12/19/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Message : UIViewController <UITableViewDelegate,UISearchBarDelegate,UITextViewDelegate,UIWebViewDelegate> {
	NSString *cid;
	NSString *mid;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableDictionary *images;
	
	RefreshCell *refreshCell;
	UIActivityIndicatorView *moreCell;
	
	NSString *lastIDs;
	NSString *counts;
	
	IBOutlet UIView *top;
	IBOutlet UIView *bot;
	
	IBOutlet UITableView *table;
	IBOutlet UITextView *reply;
	IBOutlet UILabel *count;
	IBOutlet UIButton *replyButton;
	
	NSMutableArray *searchResults;
	IBOutlet UISearchBar *search;
}

@property(nonatomic,retain) NSString *cid,*mid;
- (void)back;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshMore;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)refreshCount;
- (void)reply;
- (IBAction)send:(UIButton*)sender;
- (void)send;
- (void)cancel;
- (void)toProfile:(UIControl *)sender;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification *)note;
- (void)keyboardWasHidden:(NSNotification *)note;

@end
