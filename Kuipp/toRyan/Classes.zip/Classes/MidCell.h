//
//  MidCell.h
//  Kuipp
//
//  Created by Brandon Jue on 4/7/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupCell.h"

@interface MidCell  : GroupCell {
}

@end
