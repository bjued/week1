//
//  Inbox.m
//  Kuipp
//
//  Created by Brandon Jue on 1/4/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "Inbox.h"
#import "Cell.h"
#import "Message.h"
#import "Question.h"
#import "Profile.h"
#import "SearchTable.h"
#import "ASyncImageLoadDelegate.h"

@implementation Inbox

@synthesize toID,tab;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)mainThreadImages {
	[images release];
	images = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images retain];
	for (NSDictionary *d in dicts) {
		NSString *url = [d objectForKey:@"picture"];
		NSString *pic = [images objectForKey:url];
		if (pic==nil||[pic isEqual:[Misc defaultProfile]]) {
			[images setObject:[Misc defaultProfile]forKey:url];
			if (![url isEqualToString:[Misc defaultProfileURL]]) {
				ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
				[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
			}
		}
	}
}

- (void)aSyncImageLoaded {[table reloadData];}

- (void)refreshAll {
	[refreshCell refreshing];
	
	[kuipp cancel];
	NSString *p = [NSString stringWithFormat:
				   @"&uid=0&lid=%@&cnt=%@&sch=%@",
				   [[lastIDs objectAtIndex:tab]urlEncode],
				   [[counts objectAtIndex:tab]urlEncode],
				   [search.text urlEncode]];
	
	switch (tab) {
		case  0: [kuipp formTo:@"selectInbox" WithPost:p];break;
		case  1: [kuipp formTo:@"selectOutbox" WithPost:p];break;
		default: break;
	}
}

- (void)refreshMore {
	[lastIDs replaceObjectAtIndex:tab withObject:@"0"];
	NSString *cnt = [counts objectAtIndex:tab];
	cnt = [NSString stringWithFormat:@"%d",cnt?[cnt intValue]+1:1];
	[counts replaceObjectAtIndex:tab withObject:cnt];
	
	[self refreshAll];
	
	[moreCell startAnimating];
}

- (void)refresh:(id)obj {
	if ([moreCell isAnimating]) [moreCell stopAnimating];
	
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	[self mainThreadImages];
	
	[refreshCell refreshed];
	
	[searchResults release];
	searchResults = [[NSMutableArray alloc]initWithArray:tabResults];
	
	[table reloadData];
	double rch = table.tableHeaderView.frame.size.height;
	if (table.contentOffset.y<rch) [table setContentOffset:CGPointMake(0,rch) animated:[Misc tableHideHeaderAnimated]];
}

- (void)refreshCount {[count setText:[NSString stringWithFormat:@"%d",[Misc maxCharacters]-[body.text length]]];}

- (void)refreshTo {
	if (toID>-1) {	
		NSDictionary *dict = [followers objectAtIndex:toID];
		to.text = [Misc first:[dict objectForKey:@"firstName"]lastName:[dict objectForKey:@"lastName"]];
	}
	else to.text = @"";
}

- (void)splitData {
	[followers release];
	tabResults = [[NSMutableArray alloc]init];
	followers = [[NSMutableArray alloc]init];
	
	for (int i=0;i<[dicts count];i++) {
		NSDictionary *d = [dicts objectAtIndex:i];
		NSString *s = [d objectForKey:@"head"];
		if ([s isEqualToString:@"To"]) {
			NSString *lid = [lastIDs objectAtIndex:tab];
			if (!lid||[[d objectForKey:@"datetime"]intValue]<[lid intValue]) {
				[lastIDs replaceObjectAtIndex:tab withObject:[d objectForKey:@"datetime"]];
			}
			[tabResults addObject:d];
		}
		else if ([s isEqualToString:@"Followers"]) [followers addObject:d];
	}
}

- (IBAction)send:(UIButton*)sender {
	NSString *msg = @"";
	if ([body.text length]==0) msg = @"There needs to be a message!";
	else if ([subject.text length]==0) msg = @"The message needs a subject!";
	
	if (![msg isEqualToString:@""]) {
		NSLog(@"%@ - %@",@"Oops!",msg);
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Oops!"
				 message:msg
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
	
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = NO;
	
	[self send];
}

- (void)send {
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	
	NSURLResponse *r;
	NSError *e;
	
	NSString *p = [NSString stringWithFormat:
				   @"&cid=0&tid=%@&fid=0&sub=%@&msg=%@&lat=%.8f&lon=%.8f&loc=%@",
				   [[NSString stringWithFormat:@"%d",toID]urlEncode],
				   [subject.text urlEncode],
				   [body.text urlEncode],
				   del.userLoc.coordinate.latitude,
				   del.userLoc.coordinate.longitude,
				   [[Misc reverseGeocode:del.userPlace]urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"insertMessage" WithPost:p AndResponse:&r AndError:&e];
	
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	tab = 1;
	[self refreshAll];
	[self cancel];
}

- (void)cancel {
	composing = NO;
	[subject resignFirstResponder];
	[body resignFirstResponder];
}

- (IBAction)inbox:(UIButton*)sender {
	if (tab==0) return;
	
	tab = 0;
	
	[self selectTab:sender];
	
	[self refreshAll];
}

- (IBAction)outbox:(UIButton*)sender {
	if (tab==1) return;
	
	tab = 1;
	
	[self selectTab:sender];
	
	[self refreshAll];
}

- (void)reloadTable {
	double rch = table.tableHeaderView.frame.size.height;
	if (table.contentOffset.y<rch) [table setContentOffset:CGPointMake(0,rch) animated:[Misc tableHideHeaderAnimated]];
}

- (void)selectTab:(UIButton*)sender {
	[search resignFirstResponder];	
	
	[inbox setBackgroundImage:[Misc wideTabImage:sender==inbox]forState:UIControlStateNormal];
	[outbox setBackgroundImage:[Misc wideTabImage:sender==outbox]forState:UIControlStateNormal];
	table.contentOffset = CGPointMake(0,table.tableHeaderView.frame.size.height);
}

- (void)compose {
	composing = YES;
	subject.text = @"";
	body.text = @"";
	toID = -1;
	[self refreshCount];
	[self refreshTo];
	[subject becomeFirstResponder];
}

- (IBAction)to:(UIButton*)sender {
	/*
	CGRect nf = top.frame;
	double w = nf.size.width;
	double h = nf.size.height;
	
	UIView *overlay = [[UIView alloc]initWithFrame:nf];
	[overlay setBackgroundColor:[UIColor blackColor]];
	[overlay setAlpha:.25];
	[self.view addSubview:overlay];
	[overlay release];
	
	CGRect newFrame = CGRectMake(4,4,w-8,fmin(h-8,[followers count]*30));
	folTable = [[UITableView alloc]initWithFrame:newFrame style:UITableViewStylePlain];
	[folTable setDelegate:self];
	[folTable setDataSource:self];
	[folTable setRowHeight:30];
	[self.view addSubview:folTable];
	
	[folTable reloadData];
	 */
	SearchTable *s = [[SearchTable alloc]init];
	s.type = @"Kuipp";
	s.compose = self;
	[self.navigationController pushViewController:s animated:YES];
	[s release];
}

- (void)toProfile:(UIControl*)sender {
	Profile *v = [[Profile alloc]init];
	v.uid = [[NSString alloc]initWithFormat:@"%d",sender.tag];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (void)toUser:(int)userID withName:(NSString*)name {
	toID = userID;
	to.text = name;
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	if (tableView==folTable) return [followers count];
    else return [searchResults count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (tableView==folTable) {
		UITableViewCell *c = [tableView dequeueReusableCellWithIdentifier:@"F"];
		if (!c) c = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"F"]autorelease];
		
		// Configure the cell...
		NSDictionary *d = [followers objectAtIndex:indexPath.row];
		c.textLabel.text = [Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]];
		
		return c;
	} else {
		Cell *c = (Cell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
		if (!c) c = [[[Cell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"A"]autorelease];
		
		NSDictionary *d = [searchResults objectAtIndex:indexPath.row];
		
		c.dict = d;
		
		// Find short date
		int seconds = [[d objectForKey:@"datetime"]intValue];
		NSDate *date = [NSDate dateWithTimeIntervalSince1970:seconds];
		NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
		[formatter setTimeStyle:NSDateFormatterShortStyle];
		[formatter setDateStyle:NSDateFormatterShortStyle];
		
		c.imag.image = [images objectForKey:[d objectForKey:@"picture"]];
		c.ctrl.tag = [[d objectForKey:@"you"]intValue];
		[c.ctrl addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
		
		[c.name setTitle:[Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]otherText:@":"]forState:UIControlStateNormal];
		c.name.tag = [[d objectForKey:@"you"]intValue];
		[c.name addTarget:self action:@selector(toProfile:) forControlEvents:UIControlEventTouchUpInside];
		
		c.main.text = [d objectForKey:@"main"];
		
		c.foot.text = [formatter stringFromDate:date];
		[formatter release];
		
		c.selectable = YES;
		
		c.accessoryView = [Misc detailDisclosure];
		
		return c;
	}
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (tableView!=folTable) return [Misc buffer]*2+[Misc imageSize];
	return 30;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	if (tableView==folTable) {
		toID = indexPath.row;
		[tableView removeFromSuperview];
		folTable.delegate = nil;
		folTable.dataSource = nil;
		[folTable release];
		folTable = nil;
		[self refreshTo];
		
		NSArray *views = [self.view subviews];
		[[views lastObject]removeFromSuperview];
	} else {
		NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
		if ([[dict objectForKey:@"questionID"]intValue]==0) {
			// message
			Message *v = [[Message alloc]init];
			v.cid = [[NSString alloc]initWithString:[dict objectForKey:@"chainID"]];
			v.mid = [[NSString alloc]initWithString:[dict objectForKey:@"messageID"]];
			[self.navigationController pushViewController:v animated:YES];
			[v release];
		} else {
			// directed question
			Question *v = [[Question alloc]init];
			v.qid = [[NSString alloc]initWithString:[dict objectForKey:@"questionID"]];
			[self.navigationController pushViewController:v animated:YES];
			[v release];
		}
	}
}

#pragma mark -
#pragma mark UIScrollView

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	CGSize c = scrollView.contentSize;
	CGSize f = scrollView.frame.size;
	if (s.y<0&&![kuipp fetchingData]) {
		if (!refreshCell.flipped) [refreshCell flip];
	} else if (c.height-table.tableHeaderView.frame.size.height>f.height&&s.y>c.height-f.height&&![kuipp fetchingData]) {
		[self refreshMore];
	} else {
		if (refreshCell.flipped) [refreshCell flip];
	}
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		[self refreshAll];
	}
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	if ([search isFirstResponder]) {
		/*int shiftView = 37;
		double w = self.view.frame.size.width;
		double h = self.view.frame.size.height;
		
		[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
		[UIView setAnimationDuration:animationDuration];
		if (delta==0) {
			table.frame = CGRectMake(0,shiftView,w,h-shiftView);
			self.view.frame = CGRectMake(0,0,w,h);
			table.contentOffset = CGPointMake(0,table.tableHeaderView.frame.size.height);
		} else {
			self.view.frame = CGRectMake(0,0-shiftView,w,h);
			table.frame = CGRectMake(0,shiftView,w,h-kb.size.height+49);
			table.contentOffset = CGPointMake(0,[Misc refreshCellHeight]);
		}
		[UIView commitAnimations];*/
	} else {
		[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
		[UIView setAnimationDuration:animationDuration];
		top.frame = CGRectMake(top.frame.origin.x,-200+delta*200,top.frame.size.width,top.frame.size.height);
		bot.frame = CGRectMake(bot.frame.origin.x,367-delta*(kb.size.height-49),bot.frame.size.width,bot.frame.size.height);
		[UIView commitAnimations];
	}
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	
	if (subject.editing||[body isFirstResponder]) {
		self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Cancel"];
		UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
		[b addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside];
		
		self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Send"];
		b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
		[b addTarget:self action:@selector(send:) forControlEvents:UIControlEventTouchUpInside];
	}
}

- (void)keyboardWasHidden:(NSNotification*)note {
	[self keyboardAdjust:note:0];
	
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithImage:@"compose icon"];
	b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(compose) forControlEvents:UIControlEventTouchUpInside];
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	if (textField==subject) [body becomeFirstResponder];
	return NO;
}

#pragma mark -
#pragma mark UITextViewDelegate

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
	int newCount = [count.text intValue]-[text length]+range.length;
	if (newCount<0) return NO;
	return YES;
}

- (void)textViewDidChange:(UITextView *)textView {[self refreshCount];}

#pragma mark -
#pragma mark UISearchBarDelegate

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	[lastIDs replaceObjectAtIndex:tab withObject:@"0"];
	[counts replaceObjectAtIndex:tab withObject:@"1"];
	[self refreshAll];
	[searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {[searchBar resignFirstResponder];}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:YES animated:YES];
	[table setContentOffset:CGPointMake(0,[Misc refreshCellHeight]) animated:[Misc tableHideHeaderAnimated]];
	[table setAllowsSelection:NO];
	[table setScrollEnabled:NO];
	return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:NO animated:YES];
	[table setAllowsSelection:YES];
	[table setScrollEnabled:YES];
	return YES;
}

#pragma mark -
#pragma mark Initialization

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	for (UIView *v in [search subviews]) {
		if ([v conformsToProtocol:@protocol(UITextInputTraits)]) {
			@try {
				[(UITextField*)v setEnablesReturnKeyAutomatically:NO];
				[(UITextField*)v setKeyboardAppearance:UIKeyboardAppearanceAlert];
			}
			@catch (NSException *e) {
				NSLog(@"failed to change searchTextField's color and button");
			}
		}
	}
	
	[Misc load:self];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithImage:@"compose icon"];
	UIButton *b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(compose) forControlEvents:UIControlEventTouchUpInside];
	
	UIView *v = [[UIView alloc]init];
	CGRect s = search.frame;
	double w = s.size.width;
	double h = s.size.height;
	double r = [Misc refreshCellHeight];
	v.frame = CGRectMake(0,0,w,r+h);
	refreshCell = [Misc refreshCellView];
	refreshCell.table = table;
	refreshCell.frame = CGRectMake(0, 0, self.view.frame.size.width, r);
	search.frame = CGRectMake(0,r,w,h);
	[v addSubview:search];
	[v addSubview:refreshCell];
	
	[table setTableHeaderView:v];
	[v release];
	
	v = [[UIView alloc]init];
	v.contentMode = UIViewContentModeCenter;
	moreCell = [Misc activityView];
	double aiw = moreCell.frame.size.width;
	h = moreCell.frame.size.height;
	v.frame = CGRectMake((w-aiw)/2, 0, aiw, h);
	[v addSubview:moreCell];
	[table setTableFooterView:v];
	
	table.contentInset = UIEdgeInsetsMake(-r,0,0,0);
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aSyncImageLoaded) name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	
	lastIDs = [[NSMutableArray alloc]init];
	[lastIDs addObject:@"0"];[lastIDs addObject:@"0"];
	counts = [[NSMutableArray alloc]init];
	[counts addObject:@"1"];[counts addObject:@"1"];
	
	search.text = @"";
	
	if (!composing) {
		if (tab==0) {
			tab = 1;
			[self inbox:inbox];
		} else if (tab==1) {
			tab = 0;
			[self outbox:outbox];
		}
	}
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[lastIDs release];
	lastIDs = nil;
	[counts release];
	counts = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	table.delegate = nil;
	table.dataSource = nil;
	subject.delegate = nil;
	body.delegate = nil;
	search.delegate = nil;
	
    [super dealloc];
}

@end
