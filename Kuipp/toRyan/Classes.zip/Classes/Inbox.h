//
//  Inbox.h
//  Kuipp
//
//  Created by Brandon Jue on 1/4/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Inbox : UIViewController <UISearchBarDelegate,UITextViewDelegate,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource> {
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableDictionary *images;
	
	RefreshCell *refreshCell;
	UIActivityIndicatorView *moreCell;
	
	int tab;
	BOOL composing;
	
	NSMutableArray *lastIDs;
	NSMutableArray *counts;
	
	IBOutlet UITableView *table;
	IBOutlet UISearchBar *search;
	
	IBOutlet UIView *top;
	IBOutlet UIView *bot;
	
	IBOutlet UIButton *inbox;
	IBOutlet UIButton *outbox;
	
	IBOutlet UITextField *subject;
	IBOutlet UITextView *body;
	IBOutlet UILabel *to;
	int toID;
	IBOutlet UILabel *count;
	
	NSMutableArray *toUser;
	NSMutableArray *fromUser;
	NSMutableArray *followers;
	
	UITableView *folTable;
	
	NSMutableArray *tabResults;
	NSMutableArray *searchResults;
	
	BOOL viewMoved;
}

@property(nonatomic,assign) int toID;
@property(nonatomic,assign) int tab;
- (void)back;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshMore;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)refreshCount;
- (void)refreshTo;
- (void)splitData;
- (IBAction)send:(UIButton*)sender;
- (void)send;
- (void)cancel;
- (IBAction)inbox:(UIButton*)sender;
- (IBAction)outbox:(UIButton*)sender;
- (void)selectTab:(UIButton*)sender;
- (void)reloadTable;
- (void)compose;
- (IBAction)to:(UIButton*)sender;
- (void)toProfile:(UIControl*)sender;
- (void)toUser:(int)userID withName:(NSString*)name;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
