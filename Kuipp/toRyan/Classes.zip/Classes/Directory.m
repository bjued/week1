//
//  Directory.m
//  Kuipp
//
//  Created by Brandon Jue on 12/17/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "Directory.h"
#import "MyKuipps.h"
#import "KuippIt.h"
#import "ReKuipp.h"
#import "Inbox.h"
#import "Map.h"
#import "Connections.h"
#import "Profile.h"
//#import "Leaderboard.h"
#import "Settings.h"

@implementation Directory

- (IBAction)myKuippsPressed:(id)sender {
	MyKuipps *v = [[MyKuipps alloc]init];
	v.tab = 2;
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)kuippItPressed:(id)sender {
	KuippIt *v = [[KuippIt alloc]init];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)reKuippPressed:(id)sender {
	ReKuipp *v = [[ReKuipp alloc]init];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)inboxPressed:(id)sender {
	Inbox *v = [[Inbox alloc]init];
	v.toID = -1;
	v.tab = 0;
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)connectionsPressed:(id)sender {
	Connections *v = [[Connections alloc]init];
	v.tab = 0;
	v.uid = @"0";
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)mapPressed:(id)sender {
	Map *v = [[Map alloc]init];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)profilePressed:(id)sender {
	Profile *v = [[Profile alloc]init];
	v.uid = @"0";
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)leaderboardPressed:(id)sender {
	/*Leaderboard *v = [[Leaderboard alloc]init];
	[self.navigationController pushViewController:v animated:YES];
	[v release];*/
}

- (IBAction)settingsPressed:(id)sender {
	Settings *v = [[Settings alloc]init];
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)fadeWhenPressed:(UIControl*)sender {
	[sender setAlpha:0.5];
}

- (IBAction)fadeWhenDepressed:(UIControl*)sender {
	[sender setAlpha:1.0];
}

#pragma mark -
#pragma mark Initialization
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/
/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}

@end
