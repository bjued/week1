//
//  Party.h
//  Kuipp
//
//  Created by Brandon Jue on 7/12/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Party : UIViewController <UIAlertViewDelegate,UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,UITextFieldDelegate,UINavigationControllerDelegate> {
	NSString *uid;
	
	IBOutlet UITableView *table;
	IBOutlet UIView *top;
	IBOutlet UIView *bot;
	IBOutlet UITextField *name;
	
	UIView *options;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableDictionary *images;
	
	RefreshCell *refreshCell;
	
	NSMutableArray *users;
	NSDictionary *party;
}

@property(nonatomic,retain) NSString *uid;
- (void)back;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)splitData;
- (void)create;
- (void)submit;
- (void)invFol;
- (void)invite:(int)iid withName:(NSString*)n;
- (void)leave;
- (void)more;
- (void)scholarships;
- (void)accept:(NSString*)pnm;
- (void)rankings;
- (void)challenges;
- (void)start;
- (void)cancel;
- (void)memberMore:(UIButton*)sender;
- (void)memberCancel:(UIButton*)sender;
- (void)newLeader:(UIButton*)sender;
- (void)promote:(int)iid withName:(NSString*)n;
- (void)nominate:(int)iid withName:(NSString*)n;
- (void)voteOff:(UIButton*)sender;
- (void)keyboardAdjust:(NSNotification*)note:(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end

