//
//  RegisterPage2.m
//  Kuipp
//
//  Created by Brandon Jue on 4/23/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "RegisterPage2.h"
#import "Cell.h"
#import "TopCell.h"
#import "BotCell.h"
#import "ButtonCell.h"
#import "ASyncImageLoadDelegate.h"

@implementation RegisterPage2

@synthesize fName,lName,email,facebookID;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)mainThreadImages {
	[images release];
	images = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images retain];
	NSString *url = [facebookID intValue]==0?[Misc defaultProfileURL]:[NSString stringWithFormat:@"http://graph.facebook.com/%@/picture?type=large",facebookID];
	UIImage *pic = [images objectForKey:url];
	if (pic==nil||[pic isEqual:[Misc defaultProfile]]) {
		[images setObject:[Misc defaultProfile]forKey:url];
		if (![url isEqualToString:[Misc defaultProfileURL]]) {
			ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
			[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
		}
	}
}

- (void)aSyncImageLoaded {[table reloadData];}

- (void)createUser {
	NSString *msg = @"";
	if (![password.text isEqualToString:confirm.text]) msg = @"Your passwords don't match!";
	if ([password.text length]==0) msg = @"You need a password!";
	
	if (![msg isEqualToString:@""]) {
		NSLog(@"%@ - %@",@"Oops!",msg);
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Oops!"
							  message:msg
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
	
	KuippAppDelegate *del = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	NSString *at = del.facebook.accessToken;
	
	NSURLResponse *r;
	NSError *e;
	
	NSString *p = [NSString stringWithFormat:
				   @"&pwd=%@&fnm=%@&lnm=%@&wml=%@&fbid=%@&at=%@",
				   [password.text urlEncode],
				   [fName urlEncode],
				   [lName urlEncode],
				   [email urlEncode],
				   [facebookID urlEncode],
				   at?[at urlEncode]:@"0"];
	
	NSString *urlContents = [KuippConnect formTo:@"insertUser" WithPost:p AndResponse:&r AndError:&e];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect errorCode:urlContents]) return;
	
	p = [NSString stringWithFormat:@"&eml=%@&pwd=%@",
		 [email urlEncode],
		 [password.text urlEncode]];
	
	urlContents = [KuippConnect formTo:@"login" WithPost:p AndResponse:&r AndError:&e];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect errorCode:urlContents]) return;
	
	NSMutableArray *dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[Misc updateUserSettings:[dicts objectAtIndex:0]];
	
	NSMutableArray *d = [[NSMutableArray alloc]init];
	[d addObject:[dicts objectAtIndex:1]];
	[d addObject:[dicts objectAtIndex:2]];
	[d addObject:[dicts objectAtIndex:3]];
	
	if ([dicts count]>1) {
		NSUserDefaults *save = [NSUserDefaults standardUserDefaults];
		NSDictionary *d = [dicts objectAtIndex:0];
		
		for (NSString *key in [d allKeys]) [save setObject:[d objectForKey:key] forKey:key];
	}
	
	[dicts release];
	
	KuippAppDelegate *delegate = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	[delegate firstLogin:d];
	[d release];
}

- (void)backgroundTouched:(id)sender {
	[password resignFirstResponder];
	[confirm resignFirstResponder];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return 5;}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCellStyle s = UITableViewCellStyleDefault;
	
	switch (indexPath.row) {
		case  0: {
			Cell *c = (Cell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
			if (!c) c = [[[Cell alloc]initWithStyle:s reuseIdentifier:@"A"]autorelease];
			
			c.dict = [NSDictionary dictionaryWithObjectsAndKeys:@"0",@"picX",@"0",@"picY",[facebookID intValue]==0?@".65":@"1",@"picZ",nil];
			
			c.ctrl.userInteractionEnabled = NO;
			c.imag.image = [images objectForKey:[facebookID intValue]==0?[Misc defaultProfileURL]:[NSString stringWithFormat:@"http://graph.facebook.com/%@/picture?type=large",facebookID]];
			
			c.name.userInteractionEnabled = NO;
			[c.name setTitle:[Misc first:fName lastName:lName]forState:UIControlStateNormal];
			c.main.text = email;
			return c;
		} case  1: {
			TopCell *c = (TopCell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
			if (!c) c = [[[TopCell alloc]initWithStyle:s reuseIdentifier:@"B"]autorelease];
			
			c.item = password;
			[c.contentView addSubview:c.item];
			
			c.selectable = NO;
			return c;
		} case  2: {
			BotCell *c = (BotCell*)[tableView dequeueReusableCellWithIdentifier:@"C"];
			if (!c) c = [[[BotCell alloc]initWithStyle:s reuseIdentifier:@"C"]autorelease];
			
			c.item = confirm;
			[c.contentView addSubview:c.item];
			
			c.selectable = NO;
			return c;
		} case  4: {
			ButtonCell *c = (ButtonCell*)[tableView dequeueReusableCellWithIdentifier:@"D"];
			if (!c) c = [[[ButtonCell alloc]initWithStyle:s reuseIdentifier:@"D"]autorelease];
			
			[c.button setTitle:@"Register" forState:UIControlStateNormal];
			[c.button addTarget:self action:@selector(createUser) forControlEvents:UIControlEventTouchUpInside];
			return c;
		} default: { 
			UITableViewCell *c = [tableView dequeueReusableCellWithIdentifier:@"Z"];
			if (!c) c = [[[UITableViewCell alloc]initWithStyle:s reuseIdentifier:@"Z"]autorelease];
			
			c.backgroundColor = [UIColor clearColor];
			c.selectionStyle = UITableViewCellSelectionStyleNone;
			return c;
		}
	}	
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath {
	double buf = [Misc buffer];
	double bch = [Misc buttonCellHeight];
	double img = [Misc imageSize];
	if (indexPath.row==0) return buf*2+img;
	return buf*2+bch;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	[self backgroundTouched:nil];
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {
	if (textField==password) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
	if (textField==confirm) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	if (textField==password) {
		[confirm becomeFirstResponder];
		return NO;
	}
	if (textField==confirm) {
		[self createUser];
		[textField resignFirstResponder];
		return YES;
	}
	[textField resignFirstResponder];
	return YES;
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	CGRect frame = table.frame;
	frame.size.height -= delta*kb.size.height;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	table.frame = frame;
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	
	if (password.editing) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
	if (confirm.editing) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

- (void)keyboardWasHidden:(NSNotification*)note {[self keyboardAdjust:note:-1];}

#pragma mark -
#pragma mark Memory management

- (void)viewDidLoad {
    [super viewDidLoad];
	
	[Misc load:self];
	
    [table reloadData];
}

- (void)viewWillAppear:(BOOL)animated {
	 [super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	 [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aSyncImageLoaded) name:@"aSyncImageLoaded" object:nil];
	
	[self mainThreadImages];
}

- (void)viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"aSyncImageLoaded" object:nil];
	
	[super viewWillDisappear:animated];
}

/*
- (void)viewDidAppear:(BOOL)animated {
 [super viewDidAppear:animated];
}
 
- (void)viewDidDisappear:(BOOL)animated {
[super viewDidDisappear:animated];
}
*/

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}

- (void)dealloc {
	[fName release];
	[lName release];
	[email release];
	[facebookID release];
	
    [super dealloc];
}

@end
