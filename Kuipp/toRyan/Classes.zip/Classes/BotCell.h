//
//  BotCell.h
//  Kuipp
//
//  Created by Brandon Jue on 3/12/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupCell.h"

@interface BotCell : GroupCell {
}

@end
