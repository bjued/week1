//
//  RefreshCell.m
//  Kuipp
//
//  Created by Brandon Jue on 5/2/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "RefreshCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation RefreshCell

@synthesize flipped,table;

- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
		flipped = NO;
		
		arrow = [[UIImageView alloc]init];
		arrow.image = [UIImage imageNamed:@"arrow"];
		arrow.contentMode = UIViewContentModeScaleAspectFit;
		
		wheel = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
		
		directions = [[UILabel alloc]init];
		directions.font = [UIFont boldSystemFontOfSize:14];
		directions.textColor = [UIColor whiteColor];
		directions.textAlignment = UITextAlignmentCenter;
		directions.backgroundColor = [UIColor clearColor];
		directions.text = @"Pull down to refresh";
		
		lastUpdate = [[UILabel alloc]init];
		lastUpdate.font = [UIFont systemFontOfSize:12];
		lastUpdate.textColor = [UIColor whiteColor];
		lastUpdate.textAlignment = UITextAlignmentCenter;
		lastUpdate.backgroundColor = [UIColor clearColor];
		lastUpdate.text = @"";
		
		[self addSubview:wheel];
		[self addSubview:directions];
		[self addSubview:lastUpdate];
    }
    return self;
}

- (void)layoutSubviews {
	CGRect c = self.frame;
	double w = c.size.width;
	double h = c.size.height;
	double h14 = [Misc heightForFontSize:14];
	double h12 = [Misc heightForFontSize:12];
	double wht = 30;
	arrow.frame = CGRectMake(0, 0, h, h);
	wheel.frame = CGRectMake((h-wht)/2, (h-wht)/2, wht, wht);
	directions.frame = CGRectMake(0, h/2-h14, w, h14);
	lastUpdate.frame = CGRectMake(0, h/2, w, h12);
}

- (void)flip {
	flipped = !flipped;
	//arrow.layer.transform = CATransform3DMakeRotation(flipped?M_PI:0, 0, 0, 1);
	directions.text = flipped?@"Release to refresh":@"Pull down to refresh";
}

- (void)refreshing {
	//arrow.hidden = YES;
	[wheel startAnimating];
	directions.text = @"Loading...";
	
	table.contentInset = UIEdgeInsetsMake(0,0,0,0);
}

- (void)refreshed {
	[wheel stopAnimating];
	//arrow.hidden = NO;
	directions.text = flipped?@"Release to refresh":@"Pull down to refresh";
	
	table.contentInset = UIEdgeInsetsMake(-[Misc refreshCellHeight],0,0,0);
	
	NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
	[formatter setTimeStyle:NSDateFormatterShortStyle];
	[formatter setDateStyle:NSDateFormatterShortStyle];
	lastUpdate.text = [NSString stringWithFormat:@"Last Updated: %@",[formatter stringFromDate:[NSDate date]]];
	[formatter release];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
	[table release];
	
    [super dealloc];
}

@end
