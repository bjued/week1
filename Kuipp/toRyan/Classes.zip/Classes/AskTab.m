//
//  AskTab.m
//  Kuipp
//
//  Created by Brandon Jue on 2/26/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "AskTab.h"
#import "MapSelect.h"
#import "TopCell.h"
#import "MidCell.h"
#import "BotCell.h"
#import "FullCell.h"
#import "ButtonCell.h"
#import "Question.h"
#import "Answer.h"
#import "Profile.h"
#import "SearchTable.h"

@implementation AskTab

@synthesize coord;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)refreshAll {[kuipp formTo:@"selectKuippIt"];}

- (void)refresh:(id)obj {
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	
	[self refreshCount];
	
	[table reloadData];
}

- (void)refreshCount {[count setText:[NSString stringWithFormat:@"%d",[Misc maxCharacters]-[ask.text length]]];}

- (void)splitData {
	[catArray release];
	[folArray release];
	catArray = [[NSMutableArray alloc]init];
	folArray = [[NSMutableArray alloc]init];
	
	for (NSDictionary *d in dicts) {
		NSString *s = [d objectForKey:@"head"];
		if ([s isEqualToString:@"Categories"]) [catArray addObject:d];
		else if ([s isEqualToString:@"Followers"]) [folArray addObject:d];
	}
}

- (void)category {
	sArray = catArray;
	[self addSTable];
}

- (void)direct {
	sArray = folArray;
	[self addSTable];
}

- (void)addSTable {
	if (keywords) [keywords resignFirstResponder];
	if (ask) [ask resignFirstResponder];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Done"];
	[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(removeSTable) forControlEvents:UIControlEventTouchUpInside];
	self.navigationItem.leftBarButtonItem = nil;
	
	[self.view sendSubviewToBack:table];
	[sTable setHidden:NO];
	[sTable reloadData];
}

- (void)removeSTable {
	self.navigationItem.rightBarButtonItem = nil;
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
	[(UIButton*)self.navigationItem.leftBarButtonItem.customView addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	
	[self.view sendSubviewToBack:sTable];
	[sTable setHidden:YES];
	[table reloadData];
}

- (IBAction)submit:(UIButton*)sender {
	NSString *msg = @"";
	NSString *quest = [ask.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
	if ([quest length]==0) msg = @"There isn't a question to ask.";
	if ([quest isEqualToString:@"What do you want to know?"]) msg = @"You forgot to ask your question!";
	if (!isPublic.on&&[kpids count]==0) msg = @"Nobody can answer this question! Choose followers to send this to, or make it public.";
	if (catID<0) msg = @"You need to select a Primary Keyword";
	
	if (![msg isEqualToString:@""]) {
		NSLog(@"%@ - %@",@"Oops!",msg);
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Oops!"
				 message:msg
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
	
	table.userInteractionEnabled = NO;
	
	[location release];
	location = [[MKReverseGeocoder alloc]initWithCoordinate:coord];
	location.delegate = self;
	[location start];
}

- (void)submit {
	NSURLResponse *r;
	NSError *e;
	
	NSString *p = [NSString stringWithFormat:
				   @"&uid=0&cid=%@&qtn=%@&key=%@&lat=%.8f&lon=%.8f&loc=%@&pub=%@&dir=%@&pfb=%@&fbids=%@&ptw=%d&twids=%@&pyp=%d",
				   [[[catArray objectAtIndex:catID]objectForKey:@"categoryID"]urlEncode],
				   [ask.text urlEncode],
				   [keywords.text urlEncode],
				   coord.latitude,
				   coord.longitude,
				   [[Misc reverseGeocode:locationPlacemark]urlEncode],
				   isPublic.on?@"on":@"off",
				   [[self stringFromMutDict:kpids]urlEncode],
				   pubFB.tag==1?facebook.accessToken:@"",
				   pubFB.tag==1?[[self stringFromMutDict:fbids]urlEncode]:@"0",
				   pubTW.tag,
				   pubTW.tag==1?[[self stringFromMutDict:twids]urlEncode]:@"0",
				   pubYP.tag==1?[[NSUserDefaults standardUserDefaults]integerForKey:@"YelpResults"]:0];
	
	if ([Misc debug]) NSLog(@"%@",p);
	
	NSString *urlContents = [KuippConnect formTo:@"insertQuestion" WithPost:p AndResponse:&r AndError:&e];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	NSMutableArray *qDicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:qDicts];
	[parse parseXML:[urlContents substringFromIndex:2]];
	[parse release];
	
	Question *v = [[Question alloc]init];
	v.qid = [[qDicts objectAtIndex:0]objectForKey:@"questionID"];
	[[[self.tabBarController viewControllers]objectAtIndex:2]pushViewController:v animated:NO];
	[qDicts release];
	[v release];
	[self.tabBarController setSelectedIndex:2];
	
	table.userInteractionEnabled = YES;
}

- (NSString*)directToFollowerIDs {
	NSString *s = @"";
	NSDictionary *dict;
	for (dict in folArray) if ([dict objectForKey:@"c"]) s = [s stringByAppendingFormat:@",%@",[dict objectForKey:@"userID"]];
	if ([s length]>0) s = [s substringFromIndex:1];
	return s;
}

- (NSString*)stringFromMutDict:(NSMutableDictionary*)dict {
	if (!dict) return @"";
	NSString *ret = @"";
	for (NSString *str in dict) ret = [ret stringByAppendingFormat:@",%@",str];
	return [ret length]>0?[ret substringFromIndex:1]:ret;
}

- (void)toUser:(int)sysid using:(NSString*)system  {
	if (sysid==0) return;
	NSString *key = [NSString stringWithFormat:@"%d",sysid];
	if ([system isEqualToString:@"Kuipp"]) {
		if (!kpids) kpids = [[NSMutableDictionary alloc]init];
		[kpids setObject:key forKey:key];
	} else if ([system isEqualToString:@"Facebook"]) {
		if (!fbids) fbids = [[NSMutableDictionary alloc]init];
		[fbids setObject:key forKey:key];
	} else if ([system isEqualToString:@"Twitter"])  {
		if (!twids) twids = [[NSMutableDictionary alloc]init];
		[twids setObject:key forKey:key];
	}
	
	if ([Misc debug]) NSLog(@"%@\n%@\n%@",kpids,fbids,twids);
}

- (void)removeUser:(int)sysid using:(NSString*)system {
	NSString *key = [NSString stringWithFormat:@"%d",sysid];
	if ([system isEqualToString:@"Kuipp"]) {
		[kpids removeObjectForKey:key];
		if ([kpids count]==0) {
			[kpids release];
			kpids = nil;
		}
	} else if ([system isEqualToString:@"Facebook"]) {
		[fbids removeObjectForKey:key];
		if ([fbids count]==0) {
			[fbids release];
			fbids = nil;
		}
	} else if ([system isEqualToString:@"Twitter"]) {
		[twids removeObjectForKey:key];
		if ([twids count]==0) {
			[twids release];
			twids = nil;
		}
	}
	
	if ([Misc debug]) NSLog(@"%@\n%@\n%@",kpids,fbids,twids);
}

- (void)removeKB {
	[ask resignFirstResponder];
	[keywords resignFirstResponder];
}

- (void)toggleButton:(UIButton*)sender {
	sender.tag = (sender.tag+1)%2;
	
	sender.selected = sender.tag==1;
	/*
	NSArray *ips;
	int tag = pubFB.tag+pubTW.tag;
	if (sender.tag==0) { // remove a row
		[table deleteRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:3+tag inSection:2]]withRowAnimation:UITableViewRowAnimationBottom];
	} else { // add a row
		[table insertRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:2+tag inSection:2]]withRowAnimation:UITableViewRowAnimationBottom];
	}
	ips = [[NSArray alloc]initWithObjects:[NSIndexPath indexPathForRow:2 inSection:2],tag>0?[NSIndexPath indexPathForRow:3 inSection:2]:nil,tag>1?[NSIndexPath indexPathForRow:4 inSection:2]:nil,nil];
	[table reloadRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationNone];
	[ips release];*/
}

- (void)loginFB {
	facebook = ((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).facebook;
	if (facebook&&[facebook.expirationDate timeIntervalSinceNow]>0) {
		[self toggleButton:pubFB];
	} else {
		NSArray *permissions = [[Misc facebookPermissions]retain];
		
		[facebook authorize:permissions delegate:self];
		
		[permissions release];
	}
}

- (void)firstYelp {
	NSString *yelpResults = [[NSUserDefaults standardUserDefaults]objectForKey:@"YelpResults"];
	if (!yelpResults) [self createYelpPicker];
	[self toggleButton:pubYP];
}

- (void)createYelpPicker {
	double buf = [Misc buffer];
	int x = buf;
	int y = 200;
	int w = 320 - 2*x;
	yelpView = [[UIView alloc]init];
	yelpView.backgroundColor = [UIColor blackColor];
	[self.view addSubview:yelpView];
	
	NSString *text = @"How many Yelp results do you want?\nChange this number in Settings.";
	int vx = buf;
	int vy = buf;
	int vw = w - 2*x;
	double fontSize = [Misc nameSize];
	int vh = [Misc heightForText:text width:vw size:fontSize];
	
	UILabel *l = [[UILabel alloc]initWithFrame:CGRectMake(vx, vy, vw, vh)];
	l.text = text;
	l.backgroundColor = [UIColor clearColor];
	l.textColor = [Misc kuippOrangeColor];
	l.font = [UIFont systemFontOfSize:fontSize];
	l.numberOfLines = 0;
	[yelpView addSubview:l];
	[l release];
	
	vy += vh + buf;
	vw = (w - buf)/5;
	vh = vw - 2*buf;
	UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	button.frame = CGRectMake(vx, vy, vw-buf, vh);
	[button setTitle:@"1" forState:UIControlStateNormal];
	[button setTitleColor:[Misc kuippOrangeColor] forState:UIControlStateNormal];
	[button addTarget:self action:@selector(yelpPicked:) forControlEvents:UIControlEventTouchUpInside];
	button.tag = 1;
	[yelpView addSubview:button];
	
	vx += vw;
	button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	button.frame = CGRectMake(vx, vy, vw-buf, vh);
	[button setTitle:@"2" forState:UIControlStateNormal];
	[button setTitleColor:[Misc kuippOrangeColor] forState:UIControlStateNormal];
	[button addTarget:self action:@selector(yelpPicked:) forControlEvents:UIControlEventTouchUpInside];
	button.tag = 2;
	[yelpView addSubview:button];
	
	vx += vw;
	button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	button.frame = CGRectMake(vx, vy, vw-buf, vh);
	[button setTitle:@"3" forState:UIControlStateNormal];
	[button setTitleColor:[Misc kuippOrangeColor] forState:UIControlStateNormal];
	[button addTarget:self action:@selector(yelpPicked:) forControlEvents:UIControlEventTouchUpInside];
	button.tag = 3;
	[yelpView addSubview:button];
	
	vx += vw;
	button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	button.frame = CGRectMake(vx, vy, vw-buf, vh);
	[button setTitle:@"4" forState:UIControlStateNormal];
	[button setTitleColor:[Misc kuippOrangeColor] forState:UIControlStateNormal];
	[button addTarget:self action:@selector(yelpPicked:) forControlEvents:UIControlEventTouchUpInside];
	button.tag = 4;
	[yelpView addSubview:button];
	
	vx += vw;
	button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	button.frame = CGRectMake(vx, vy, vw-buf, vh);
	[button setTitle:@"5" forState:UIControlStateNormal];
	[button setTitleColor:[Misc kuippOrangeColor] forState:UIControlStateNormal];
	[button addTarget:self action:@selector(yelpPicked:) forControlEvents:UIControlEventTouchUpInside];
	button.tag = 5;
	[yelpView addSubview:button];
	
	int h = vy + vh + buf;
	
	yelpView.frame = CGRectMake(x+320, y, w, h);
	[UIView beginAnimations:@"yelp picker" context:nil];
	[UIView setAnimationDuration:[Misc animations]];
	yelpView.frame = CGRectMake(x, y, w, h);
	[UIView commitAnimations];
	
	table.userInteractionEnabled = NO;
}

- (void)yelpPicked:(UIButton*)sender {
	[[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%d",sender.tag] forKey:@"YelpResults"];
	
	[UIView beginAnimations:@"yelp picker remove" context:nil];
	[UIView setAnimationDuration:[Misc animations]];
	yelpView.frame = CGRectMake(-320, yelpView.frame.origin.y, yelpView.frame.size.width, yelpView.frame.size.height);
	[UIView commitAnimations];
	[yelpView release];
	
	table.userInteractionEnabled = YES;
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return tableView==table?4:1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	if (tableView==table) {
		switch (section) {
			case  0: return 1;
			case  1: return 2;
			case  2: return 3;//+pubFB.tag;//+pubTW.tag;
			case  3: return 1;
			default: return 0;
		}
	}
	if (tableView==sTable) return [sArray count];
	return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCellStyle s = UITableViewCellStyleDefault;
	
	if (tableView==table) {
		GroupCell *c;
		
		if (indexPath.section==0) {
			FullCell *c = (FullCell*)[table dequeueReusableCellWithIdentifier:@"F"];
			if (!c) c = [[[FullCell alloc]initWithStyle:s reuseIdentifier:@"F"]autorelease];
			c.item = ask;
			[c.contentView addSubview:c.item];
			c.bott = count;
			[c.contentView addSubview:c.bott];
			c.selectable = NO;
			return c;
		} else if (indexPath.section==3) {
			ButtonCell *c = (ButtonCell*)[tableView dequeueReusableCellWithIdentifier:@"E"];
			if (!c) c = [[[ButtonCell alloc]initWithStyle:s reuseIdentifier:@"E"]autorelease];
			[c.button setTitle:@"Ask" forState:UIControlStateNormal];
			[c.button addTarget:self action:@selector(submit:) forControlEvents:UIControlEventTouchUpInside];
			return c;
		} else if (indexPath.row==0) {
			c = (TopCell*)[table dequeueReusableCellWithIdentifier:@"A"];
			if (!c) c = [[[TopCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"A"]autorelease];
		} else if (indexPath.section==1&&indexPath.row==1) {
			c = (BotCell*)[table dequeueReusableCellWithIdentifier:@"B"];
			if (!c) c = [[[BotCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"B"]autorelease];
		} else if (indexPath.row==2/*+pubFB.tag+pubTW.tag*/) {
			c = (BotCell*)[table dequeueReusableCellWithIdentifier:@"C"];
			if (!c) c = [[[BotCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"C"]autorelease];
		} else {
			c = (MidCell*)[table dequeueReusableCellWithIdentifier:@"D"];
			if (!c) c = [[[MidCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"D"]autorelease];
		}
		
		if (indexPath.section==1) {
			if (indexPath.row==0) {
				c.label.text = @"Select Keywords";
				c.selectable = YES;
			
				UILabel *l = [[UILabel alloc]init];
				l.text = catID>-1?[[catArray objectAtIndex:catID]objectForKey:@"category"]:@"";
				l.font = [UIFont systemFontOfSize:[Misc nameSize]];
				[l sizeToFit];
				c.accessoryView = catID>-1?(UIView*)l:(UIView*)[Misc detailDisclosure];
				[l release];
			} else if (indexPath.row==1) {
				c.label.text = @"";
				c.selectable = NO;
				
				if (!keywords) {
					keywords = [[UITextField alloc]init];
					keywords.placeholder = @"Add more keywords separated by commas";
					keywords.text = @"";
					keywords.font = [UIFont systemFontOfSize:[Misc mainSize]];
					keywords.keyboardType = UIKeyboardTypeAlphabet;
					keywords.keyboardAppearance = UIKeyboardAppearanceAlert;
					keywords.returnKeyType = UIReturnKeyDone;
					keywords.textAlignment = UITextAlignmentCenter;
					keywords.autocapitalizationType = UITextAutocapitalizationTypeNone;
					keywords.delegate = self;
					
					double buf = [Misc buffer];
					double w = self.view.frame.size.width-buf*8;
					double h = [Misc heightForFontSize:[Misc mainSize]];
					keywords.frame = CGRectMake(0,0,w,h);
				}
				
				c.item = [keywords retain];
				[c.contentView addSubview:c.item];
			}
		} else if (indexPath.section==2) {
			if (indexPath.row==0) {
				c.label.text = @"Public";
				c.selectable = NO;
			
				if (!isPublic) {
					isPublic = [[UISwitch alloc]init];
					isPublic.on = YES;
				}
				c.accessoryView = isPublic;
			} else if (indexPath.row==1) {
				c.label.text = @"Send to Followers";
				c.selectable = YES;
			
				c.accessoryView = [Misc detailDisclosure];
			} else if (indexPath.row==2) {
				c.label.text = @"Ask on:";
				c.selectable = NO;
			
				double buf=[Misc buffer],x=buf,y=0,mh=0;
				
				UIView *v = [[UIView alloc]init];
				if (!pubFB) {
					pubFB = [Misc createToggle:@"settings facebook"];
					pubFB.frame = CGRectMake(x, y, pubFB.frame.size.width, pubFB.frame.size.height);
					[pubFB addTarget:self action:@selector(loginFB) forControlEvents:UIControlEventTouchUpInside];
				}
				x += pubFB.frame.size.width+buf*4;
				mh = fmax(pubFB.frame.size.height,mh);
				[v addSubview:pubFB];
				/*if (!pubTW) {
					pubTW = [Misc createToggle:@"settings twitter"];
					pubTW.frame = CGRectMake(x, y, pubTW.frame.size.width, pubTW.frame.size.height);
					[pubTW addTarget:self action:@selector(toggleButton:) forControlEvents:UIControlEventTouchUpInside];
				 }
				 x += pubTW.frame.size.width+buf*4;
				 mh = fmax(pubTW.frame.size.height,mh);
				[v addSubview:pubTW];*/
				if (!pubYP) {
					pubYP = [Misc createToggle:@"settings yelp"];
					pubYP.frame = CGRectMake(x, y, pubYP.frame.size.width, pubYP.frame.size.height);
					[pubYP addTarget:self action:@selector(firstYelp) forControlEvents:UIControlEventTouchUpInside];
				}
				x += pubYP.frame.size.width+buf*4;
				mh = fmax(pubYP.frame.size.height,mh);
				[v addSubview:pubYP];
				
				v.frame = CGRectMake(0, 0, x, mh);
				NSLog(@"%f,%f",x,mh);
				c.accessoryView = v;
				[v release];
			} else if (indexPath.row==3) {
				c.label.text = pubFB.tag==1?@"Tag Facebook friends":@"Tweet to Followers";
				c.selectable = YES;
				
				c.accessoryView = [Misc detailDisclosure];
			} else if (indexPath.row==4) {
				c.label.text = @"Tweet to Followers";
				c.selectable = YES;
				
				c.accessoryView = [Misc detailDisclosure];
			}
		}
		return c;
	} else { // tableView==sTable
		UITableViewCell *c = [sTable dequeueReusableCellWithIdentifier:@"G"];
		if (!c) c = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"G"]autorelease];
		
		NSDictionary *d = [sArray objectAtIndex:indexPath.row];
		NSString *s = [d objectForKey:@"category"];
		if (s) { // categories
			c.textLabel.text = s;
			[c.imageView setImage:indexPath.row==catID?[[Misc checkmark]image]:[[Misc checkmarkPlaceholder]image]];
		} else {
			c.textLabel.text = [Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]];
			[c.imageView setImage:[d objectForKey:@"c"]?[[Misc checkmark]image]:[[Misc checkmarkPlaceholder]image]];
		}
		return c;
	}
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath {
	if (tableView==sTable) return 40;
	
	double buf = [Misc buffer];
	if (indexPath.section==0) return buf*4+[Misc heightForFontSize:[Misc nameSize]]*5+[Misc heightForFontSize:[Misc footSize]];
	else if (indexPath.section==3) return buf*2+[Misc buttonCellHeight];
	else if (indexPath.row==0) return 40;
	else if (indexPath.section==1&&indexPath.row==1) return 40;
	else if (indexPath.row==2/*+pubFB.tag+pubTW.tag*/) return 40;
	else return 40-buf;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	if (tableView==table) {
		SearchTable *s = [[SearchTable alloc]init];
		s.askTab = self;
		if (indexPath.section==1&&indexPath.row==0) [self category];
		else if (indexPath.section==2&&indexPath.row==1) {
			s.type = @"Kuipp";
			s.checks = kpids;
		}
		else if (indexPath.row==3&&pubFB.tag==1) {
			s.type = @"Facebook";
			s.checks = fbids;
		}
		else if (indexPath.row==3||indexPath.row==4) {
			s.type = @"Twitter";
			s.checks = twids;
		}
		if (s.type) [self.navigationController pushViewController:s animated:YES];
		[s release];
	}
	// move all to different view
	if (tableView==sTable) {
		NSMutableDictionary *dict = [sArray objectAtIndex:indexPath.row];
		if ([dict objectForKey:@"category"]) {
			if (catID>-1) [[sArray objectAtIndex:catID]removeObjectForKey:@"c"];
			[dict setObject:@"1" forKey:@"c"];
			
			catID = indexPath.row;
		} else {
			if (![dict objectForKey:@"c"]) [dict setObject:@"1" forKey:@"c"];
			else [dict removeObjectForKey:@"c"];
			
			[folArray replaceObjectAtIndex:indexPath.row withObject:dict];
		}
		[sTable reloadData];
	}
}

#pragma mark -
#pragma mark FBSessionDelegate

- (void)fbDidLogin {[self toggleButton:pubFB];}

- (void)fbDidNotLogin:(BOOL)cancelled {NSLog(@"Failed to log into facebook. User canceled? %@",cancelled?@"YES":@"NO");}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	table.frame = CGRectMake(0,table.frame.origin.y,table.frame.size.width,table.frame.size.height-delta*(kb.size.height-49));
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	
	if (keywords.editing) [table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:1]atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

- (void)keyboardWasHidden:(NSNotification*)note {[self keyboardAdjust:note:-1];}

#pragma mark -
#pragma mark UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {
	self.navigationItem.leftBarButtonItem = nil;
	self.navigationItem.rightBarButtonItem = nil;
	
	[table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:1]atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	self.navigationItem.rightBarButtonItem = nil;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[textField resignFirstResponder];
	return YES;
}

#pragma mark -
#pragma mark UITextViewDelegate

- (void)textViewDidChange:(UITextView *)textView {[self refreshCount];}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
	int newCount = [count.text intValue]-[text length]+range.length;
	if (newCount<0) return NO;
	return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
	self.navigationItem.leftBarButtonItem = nil;
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Done"];
	UIButton *b = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
	[b addTarget:self action:@selector(removeSTable) forControlEvents:UIControlEventTouchUpInside];
	
	if ([textView.text isEqualToString:@"What do you want to know?"]) textView.text = @"";
	
	[table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

- (void)textViewDidEndEditing:(UITextView *)textView {
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
	UIButton *b = (UIButton*)self.navigationItem.leftBarButtonItem.customView;
	[b addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	self.navigationItem.rightBarButtonItem = nil;
}

#pragma mark -
#pragma mark MKReverseGeocoderDelegate

- (void)reverseGeocoder:(MKReverseGeocoder*)geocoder didFindPlacemark:(MKPlacemark*)placemark {
	[geocoder cancel];
	locationPlacemark = [placemark retain];
	[self submit];
}

- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFailWithError:(NSError *)error {
	NSLog(@"%@",error);
	if (locationPlacemark&&[Misc reverseGeocode:locationPlacemark]) {
		NSLog(@"Sending with old Location data");
		[geocoder cancel];
		[self submit];
	} else {
		table.userInteractionEnabled = YES;
	}
}

#pragma mark -
#pragma mark Initialization

/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */

- (void)viewDidLoad {
	[super viewDidLoad];
	
	[Misc load:self];
	
	ask = [[UITextView alloc]init];
	ask.backgroundColor = [UIColor clearColor];
	ask.textColor = [UIColor darkGrayColor];
	ask.font = [UIFont systemFontOfSize:[Misc nameSize]];
	ask.keyboardType = UIKeyboardTypeASCIICapable;
	ask.keyboardAppearance = UIKeyboardAppearanceAlert;
	ask.text = @"What do you want to know?";
	ask.delegate = self;
	
	count = [[UILabel alloc]init];
	count.backgroundColor = [UIColor clearColor];
	count.textColor = [UIColor redColor];
	count.font = [UIFont systemFontOfSize:[Misc footSize]];
	count.textAlignment = UITextAlignmentRight;
	
	catID = -1;
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	[self refreshCount];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	[self refreshAll];
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	table.delegate = nil;
	table.dataSource = nil;
	keywords.delegate = nil;
	ask.delegate = nil;
	[ask release];
	[count release];
	
    [super dealloc];
}

@end
