//
//  Me.m
//  Kuipp
//
//  Created by Brandon Jue on 2/27/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "Me.h"
#import "ProfileCard.h"
#import "SingleTextCell.h"
#import "ChainCell.h"
#import "UserCell.h"
#import "ProfileTable.h"
#import "Profile.h"
#import "Question.h"
#import "Answer.h"
#import "Message.h"
#import "InviteFriends.h"
#import "KuippAppDelegate.h"
#import "KuippConnect.h"
#import "Parser.h"
#import "Misc.h"

@implementation Me

@synthesize uid,toID,tab;

- (IBAction)refresh:(UIBarButtonItem*)sender {
	NSURLResponse *response;
	NSError *error;
	
	NSString *urlContents = [KuippConnect formTo:@"selectMe" WithPost:@"" AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:1]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode forView:self]) return;
	
	if (dicts!=nil) [dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	
	[self filter:sender];
}

- (void)refreshCount {
	count.text = [NSString stringWithFormat:@"%d",150-[body.text length]];
}

- (void)refreshTo {
	if (toID>-1) {	
		NSDictionary *dict = [followers objectAtIndex:toID];
		to.text = [Misc first:[dict objectForKey:@"firstName"] lastName:[dict objectForKey:@"lastName"]];
	}
	else to.text = @"";
}

- (void)refreshCategory {
	if (catID==-1) [category setTitle:@"Choose a category to follow" forState:UIControlStateNormal];
	else if (catID==0) [category setTitle:@"ALL CATEGORIES" forState:UIControlStateNormal];
	else [category setTitle:[[catArray objectAtIndex:catID-1]objectForKey:@"category"]forState:UIControlStateNormal];
}

- (void)splitData {
	userSet = NO;questionSet = NO;answerSet = NO;levelSet = NO;
	
	if (toUser!=nil) [toUser release];
	if (fromUser!=nil) [fromUser release];
	if (following!=nil) [following release];
	if (followers!=nil) [followers release];
	if (catArray!=nil) [catArray release];
	toUser = [[NSMutableArray alloc]init];
	fromUser = [[NSMutableArray alloc]init];
	following = [[NSMutableArray alloc]init];
	followers = [[NSMutableArray alloc]init];
	catArray = [[NSMutableArray alloc]init];
	
	NSMutableArray *toArray = [[NSMutableArray alloc]init];
	NSMutableArray *dToArray = [[NSMutableArray alloc]init];
	NSMutableArray *fromArray = [[NSMutableArray alloc]init];
	NSMutableArray *dFromArray = [[NSMutableArray alloc]init];
	
	for (int i=0;i<[dicts count];i++) {
		NSDictionary *d = [dicts objectAtIndex:i];
		if ([[d objectForKey:@"head"]isEqualToString:@"Users"]) {
			userSet = YES;
			user = [[NSDictionary alloc]initWithDictionary:d];
		} else if ([[d objectForKey:@"head"]isEqualToString:@"Questions"]) {
			questionSet = YES;
			question = [[NSDictionary alloc]initWithDictionary:d];
		} else if ([[d objectForKey:@"head"]isEqualToString:@"Answers"]) {
			answerSet = YES;
			answer = [[NSDictionary alloc]initWithDictionary:d];
		} else if ([[d objectForKey:@"head"]isEqualToString:@"Level"]) {
			levelSet = YES;
			level = [[NSDictionary alloc]initWithDictionary:d];
		} else if ([[d objectForKey:@"head"]isEqualToString:@"Categories"]) {
			[catArray addObject:d];
		} else if ([[d objectForKey:@"head"]isEqualToString:@"To"]) {
			[toArray addObject:d];
		} else if ([[d objectForKey:@"head"]isEqualToString:@"From"]) {
			[fromArray addObject:d];
		} else if ([[d objectForKey:@"head"]isEqualToString:@"DirectedTo"]) {
			[dToArray addObject:d];
		} else if ([[d objectForKey:@"head"]isEqualToString:@"DirectedFrom"]) {
			[dFromArray addObject:d];
		} else if ([[d objectForKey:@"head"]isEqualToString:@"Following"]) {
			[following addObject:d];
		} else if ([[d objectForKey:@"head"]isEqualToString:@"Followers"]) {
			[followers addObject:d];
		}
	}
	
	for (int msg=0,dir=0;msg+dir<[toArray count]+[dToArray count];) {
		if (msg==[toArray count]) {
			[toUser addObject:[dToArray objectAtIndex:dir]];
			dir++;
		} else if (dir==[dToArray count]) {
			[toUser addObject:[toArray objectAtIndex:msg]];
			msg++;
		} else if ([[[toArray objectAtIndex:msg]objectForKey:@"datetime"]intValue]>[[[dToArray objectAtIndex:dir]objectForKey:@"datetime"]intValue]) {
			[toUser addObject:[toArray objectAtIndex:msg]];
			msg++;
		} else {
			[toUser addObject:[dToArray objectAtIndex:dir]];
			dir++;
		}
	}

	for (int msg=0,dir=0;msg+dir<[fromArray count]+[dFromArray count];) {
		if (msg==[fromArray count]) {
			[fromUser addObject:[dFromArray objectAtIndex:dir]];
			dir++;
		} else if (dir==[dFromArray count]) {
			[fromUser addObject:[fromArray objectAtIndex:msg]];
			msg++;
		} else if ([[[fromArray objectAtIndex:msg]objectForKey:@"datetime"]intValue]>[[[dFromArray objectAtIndex:dir]objectForKey:@"datetime"]intValue]) {
			[fromUser addObject:[fromArray objectAtIndex:msg]];
			msg++;
		} else {
			[fromUser addObject:[dFromArray objectAtIndex:dir]];
			dir++;
		}
	}
	
	[toArray release];
	[dToArray release];
	[fromArray release];
	[dFromArray release];
}

- (IBAction)filter:(UIBarButtonItem*)sender {
	tab = sender.tag;
	
	if (tabResults!=nil) [tabResults release];
	
	NSString *ph = @"Search Your ";
	
	profileButton.style = UIBarButtonItemStyleBordered;
	messageButton.style = UIBarButtonItemStyleBordered;
	inboxButton.style = UIBarButtonItemStyleBordered;
	outboxButton.style = UIBarButtonItemStyleBordered;
	connectionButton.style = UIBarButtonItemStyleBordered;
	followingButton.style = UIBarButtonItemStyleBordered;
	followersButton.style = UIBarButtonItemStyleBordered;
	switch (tab) {
		case  1:
			[ph stringByAppendingString:@"Inbox"];
			messageButton.style = UIBarButtonItemStyleDone;
			inboxButton.style = UIBarButtonItemStyleDone;
			tabResults = [[NSMutableArray alloc]initWithArray:toUser];
			break;
		case  3:
			[ph stringByAppendingString:@"Outbox"];
			messageButton.style = UIBarButtonItemStyleDone;
			outboxButton.style = UIBarButtonItemStyleDone;
			tabResults = [[NSMutableArray alloc]initWithArray:fromUser];
			break;
		case  2:
			[ph stringByAppendingString:@"Following"];
			connectionButton.style = UIBarButtonItemStyleDone;
			followingButton.style = UIBarButtonItemStyleDone;
			tabResults = [[NSMutableArray alloc]initWithArray:following];
			break;
		case  4:
			[ph stringByAppendingString:@"Followers"];
			connectionButton.style = UIBarButtonItemStyleDone;
			followersButton.style = UIBarButtonItemStyleDone;
			tabResults = [[NSMutableArray alloc]initWithArray:followers];
			break;
		case  5: //Settings
			break;
		default: //Profile
			[table reloadData];
			profileButton.style = UIBarButtonItemStyleDone;
			tabResults = [[NSMutableArray alloc]init];
			return;
	}
	
	[search setText:@""];
	[search setPlaceholder:ph];
	[self applySearchField:search];
}

- (IBAction)compose:(UIBarButtonItem*)sender {
	[subject becomeFirstResponder];
	to.text = @"";
	toID = -1;
}

- (IBAction)to:(UIButton*)sender {
	CGRect nf = CGRectMake(0,0,320,460);
	UIView *overlay = [[UIView alloc]initWithFrame:nf];
	[overlay setBackgroundColor:[UIColor blackColor]];
	[overlay setAlpha:.25];
	[self.view addSubview:overlay];
	[overlay release];
	
	CGRect newFrame = CGRectMake(4,87,312,fmin(109,[followers count]*30));
	if (folTable!=nil) [folTable release];
	folTable = [[UITableView alloc]initWithFrame:newFrame style:UITableViewStylePlain];
	[folTable setDelegate:self];
	[folTable setDataSource:self];
	[folTable setRowHeight:30];
	[self.view addSubview:folTable];
	
	[folTable reloadData];
}

- (IBAction)cancel:(UIBarButtonItem*)sender {
	[subject resignFirstResponder];
	[body resignFirstResponder];
	[interest resignFirstResponder];
	subject.text = @"";
	body.text = @"";
	interest.text = @"";
	[self refreshCount];
}

- (IBAction)send:(UIBarButtonItem*)sender {
	if (toID<0) {
		NSLog(@"There isn't a user to send to.");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Error"
				 message:@"There isn't a user to send to."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else if ([body.text length]==0) {
		NSLog(@"There isn't a message to send.");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Error"
				 message:@"There isn't a message to send."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else if ([subject.text length]==0) {
		NSLog(@"There is no subject!");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Error"
				 message:@"There isn't a message to send."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else {
		[manager startUpdatingLocation];
	}
}

- (void)send {
	if (userLoc==nil) return;
	[manager stopUpdatingLocation];
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&chainID=0"
							@"&toUser=%@"
							@"&fromUser=0"
							@"&subject=%@"
							@"&message=%@"
							@"&latitude=%.8f"
							@"&longitude=%.8f",
							[[followers objectAtIndex:toID]objectForKey:@"userID"],
							subject.text,
							body.text,
							userLoc.coordinate.latitude,
							userLoc.coordinate.longitude];
	
	NSString *urlContents = [KuippConnect formTo:@"insertMessage" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:2]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode/10 forView:self]) return;
	if (![KuippConnect sendMessageCode:exitCode%10 forView:self]) return;
	
	[self refresh:outboxButton];
	[self cancel:nil];
}

- (IBAction)addInterests:(UIBarButtonItem*)sender {
	[interest becomeFirstResponder];
	catID = -1;
	[self refreshCategory];
	interest.text = @"";
}

- (IBAction)categoryTable:(UIButton*)sender {
	CGRect newFrame = CGRectMake(4,87,312,fmin(109,[catArray count]*30+30));
	if (catTable!=nil) [catTable release];
	catTable = [[UITableView alloc]initWithFrame:newFrame style:UITableViewStylePlain];
	[catTable setDelegate:self];
	[catTable setDataSource:self];
	[catTable setRowHeight:30];
	[self.view addSubview:catTable];
	
	[catTable reloadData];
}

- (IBAction)add:(UIBarButtonItem *)sender {
	if (catID==-1) {
		NSLog(@"A Category was never picked");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Error"
				 message:@"You must choose a category."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else if (catID==0&&[interest.text length]==0) {
		NSLog(@"ALL CATEGORY and no keyword *:* choosen, illegal");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Error"
				 message:@"You cannot follow all categores and all keywords at once."
				 delegate:self
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else if (catID==0) {
		NSLog(@"There is no category!");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Confirm Interest"
				 message:@"Are you sure you are interested in every category where this interest appears in?"
				 delegate:self
				 cancelButtonTitle:@"Cancel"
				 otherButtonTitles:@"Follow Interest",nil];
		[alert show];
		[alert release];
	} else if ([interest.text length]==0) {
		NSLog(@"There is no keyword!");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Confirm Interest"
				 message:@"Are you sure you are interested in this entire category?"
				 delegate:self
				 cancelButtonTitle:@"Cancel"
				 otherButtonTitles:@"Follow Category",nil];
		[alert show];
		[alert release];
	} else {
		[self add];
	}
}

- (void)add {
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=0"
							@"&cid=%d"
							@"&int=%@",
							catID,
							interest.text];
	
	NSString *urlContents = [KuippConnect formTo:@"insertInterest" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:2]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode/10 forView:self]) return;
	if (![KuippConnect sendMessageCode:exitCode%10 forView:self]) return;
	
	[self refresh:nil];
	[self cancel:nil];
}

- (void)toggleBars {
	BOOL wasVisible = bars.frame.origin.y==0;
	
	[UIView beginAnimations:@"toggleBars" context:nil];
	[UIView setAnimationDuration:[Misc animations]];
	bars.frame = CGRectMake(0,wasVisible?-44:0,bars.frame.size.width,bars.frame.size.height);
	table.frame = CGRectMake(0,wasVisible?0:44,table.frame.size.width,table.frame.size.height+(wasVisible?44:-44));
	setTable.frame = CGRectMake(0,wasVisible?0:44,setTable.frame.size.width,setTable.frame.size.height+(wasVisible?44:-44));
	[UIView commitAnimations];
	self.navigationItem.rightBarButtonItem.style = wasVisible?UIBarButtonItemStyleBordered:UIBarButtonItemStyleDone;
}

- (IBAction)toggleFilter:(UIBarButtonItem*)sender {
	UIToolbar *tool;
	switch (sender.tag) {
		case  1: tool=messageBar;break;
		case  2: tool=connectionsBar;break;
		default: tool=profileBar;break;
	}
	
	BOOL wasVisible = tool.frame.origin.x==0;
	
	[UIView beginAnimations:@"toggleFilter" context:nil];
	[UIView setAnimationDuration:[Misc animations]];
	tool.frame = CGRectMake(wasVisible?-self.view.frame.size.width:0,0,self.view.frame.size.width,tool.frame.size.height);
	[UIView commitAnimations];
	
	if (!wasVisible&&sender.style==UIBarButtonItemStyleBordered) [self filter:sender];
}

- (IBAction)toggleSearch:(UIBarButtonItem*)sender {
	BOOL wasVisible = search.frame.origin.x==0;
	
	[UIView beginAnimations:@"toggleSearch" context:nil];
	[UIView setAnimationDuration:[Misc animations]];
	search.frame = CGRectMake(wasVisible?self.view.frame.size.width:0,0,self.view.frame.size.width,search.frame.size.height);
	[UIView commitAnimations];
	
	wasVisible?[search resignFirstResponder]:[search becomeFirstResponder];
}

- (IBAction)toggleSettings:(UIButton*)sender {
	tab == 5;
	[UIView beginAnimations:@"toggleSettings" context:nil];
	[UIView setAnimationDuration:[Misc animations]];
	settingsBar.frame = CGRectMake(0,0,self.view.frame.size.width,settingsBar.frame.size.height);
	[UIView commitAnimations];
	[self.view bringSubviewToFront:setTable];
	[setTable reloadData];
}

- (IBAction)backSettings:(UIBarButtonItem*)sender {
	[UIView beginAnimations:@"toggleSettings" context:nil];
	[UIView setAnimationDuration:[Misc animations]];
	settingsBar.frame = CGRectMake(self.view.frame.size.width,0,self.view.frame.size.width,settingsBar.frame.size.height);
	[UIView commitAnimations];
	
	[self.view sendSubviewToBack:setTable];
}

- (IBAction)cancelSettings:(UIBarButtonItem*)sender {
	NSUserDefaults *save = [NSUserDefaults standardUserDefaults];
	
	if (settings!=nil) [settings release];
	settings = [[NSMutableArray alloc]init];
	
	while ([settings count]<4) [settings addObject:[NSMutableArray array]];
	// Top Card
	[[settings objectAtIndex:0]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[Misc first:[save objectForKey:@"firstName"] lastName:[save objectForKey:@"lastName"]otherText:@"Settings"],@"p",[NSString stringWithFormat:@"v:%@ b:%@ t:%@",[[NSBundle mainBundle]objectForInfoDictionaryKey:@"CFBundleShortVersionString"],[[NSBundle mainBundle]objectForInfoDictionaryKey:@"CFBundleVersion"],[[NSBundle mainBundle]objectForInfoDictionaryKey:@"CFBuildDate"]],@"s",@"1",@"!s",nil]];
	// Location & Time, Find Connections, Notifications
	[[settings objectAtIndex:1]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Location & Time",@"p",@"0",@"o",nil]];
	[[settings objectAtIndex:1]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Find Connections",@"p",@"0",@"o",nil]];
	[[settings objectAtIndex:1]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Notifications",@"p",@"0",@"o",nil]];
	// Terms of Service, Privacy Policy
	[[settings objectAtIndex:2]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Terms of Service",@"p",nil]];
	[[settings objectAtIndex:2]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Privacy Policy",@"p",nil]];
	// Change Password, Logout
	[[settings objectAtIndex:3]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Change Password",@"p",@"0",@"o",nil]];
	[[settings objectAtIndex:3]addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Logout",@"p",nil]];
	
	if (locationTime!=nil) [locationTime release];
	locationTime = [[NSMutableArray alloc]init];
	
	NSDictionary *n = [[NSDictionary alloc]initWithDictionary:[save dictionaryForKey:@"locationTime"]copyItems:YES];
	[locationTime addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Define a...",@"p",@"1",@"!s",@"1",@"i",nil]];
	[locationTime addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Local Question",@"p",@"1",@"!s",@"2",@"i",@"local",@"k",[n objectForKey:@"local"],@"t",nil]];
	[locationTime addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Recent Question",@"p",@"1",@"!s",@"2",@"i",@"recent",@"k",[n objectForKey:@"recent"],@"t",nil]];
	[n release];
	
	if (findConnections!=nil) [findConnections release];
	findConnections = [[NSMutableArray alloc]init];
	
	n = [[NSDictionary alloc]initWithDictionary:[save dictionaryForKey:@"findConnections"]copyItems:YES];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Find friends through...",@"p",@"1",@"!s",@"1",@"i",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Address Book",@"p",@"RedPin.png",@"m",@"2",@"i",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Facebook",@"p",@"RedPin.png",@"m",@"2",@"i",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Twitter",@"p",@"RedPin.png",@"m",@"2",@"i",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"First & Last Names",@"p",@"RedPin.png",@"m",@"2",@"i",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Email Addresses",@"p",@"RedPin.png",@"m",@"2",@"i",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Forward messages & directed questions to my email",@"p",@"1",@"i",@"forward",@"k",[n objectForKey:@"forward"],@"c",nil]];
	[findConnections addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Allow others to find me",@"p",@"1",@"i",@"visible",@"k",[n objectForKey:@"visible"],@"c",nil]];
	[n release];
	
	if (notifications!=nil) [notifications release];
	notifications = [[NSMutableArray alloc]init];
	
	n = [[NSDictionary alloc]initWithDictionary:[save dictionaryForKey:@"notifications"]copyItems:YES];
	// A=Answer, Q=Question, C=Comment, M=Message, I=Interests, F=Follow
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Send me notifications when...",@"p",@"1",@"!s",@"1",@"i",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Someone answers my question",@"p",@"2",@"i",@"AMyQ",@"k",[n objectForKey:@"AMyQ"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Someone answers a question I am following",@"p",@"2",@"i",@"AFQ",@"k",[n objectForKey:@"AFQ"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Someone comments my answer",@"p",@"2",@"i",@"CMyA",@"k",[n objectForKey:@"CMyA"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Someone follows me",@"p",@"2",@"i",@"FMe",@"k",[n objectForKey:@"FMe"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Someone messages me",@"p",@"2",@"i",@"MMe",@"k",[n objectForKey:@"MMe"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Someone asks a question about my interests",@"p",@"2",@"i",@"QMyI",@"k",[n objectForKey:@"QMyI"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Someone asks a related question to questions I am following",@"p",@"2",@"i",@"QFQ",@"k",[n objectForKey:@"QFQ"],@"c",nil]];
	[notifications addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Achievement opportunities come up",@"p",@"2",@"i",@"Rmnd",@"k",[n objectForKey:@"Rmnd"],@"c",nil]];
	[n release];
	
	[self backSettings:sender];
	[self settingsChanged:NO];
}

- (IBAction)saveSettings:(UIBarButtonItem*)sender {
	NSString *keys = @"";
	NSString *vals = @"";
	
	for (NSDictionary *d in locationTime) if ([d objectForKey:@"k"]!=nil) {
		keys = [keys stringByAppendingFormat:@",%@",[d objectForKey:@"k"]];
		vals = [vals stringByAppendingFormat:@",%@",[d objectForKey:@"t"]==nil?@"2":[d objectForKey:@"t"]];
	}
	for (NSDictionary *d in findConnections) if ([d objectForKey:@"k"]!=nil) {
		keys = [keys stringByAppendingFormat:@",%@",[d objectForKey:@"k"]];
		vals = [vals stringByAppendingFormat:@",%d",[d objectForKey:@"c"]==nil?0:1];
	}
	for (NSDictionary *d in notifications) if ([d objectForKey:@"k"]!=nil) {
		keys = [keys stringByAppendingFormat:@",%@",[d objectForKey:@"k"]];
		vals = [vals stringByAppendingFormat:@",%d",[d objectForKey:@"c"]==nil?0:1];
	}
	if ([keys length]>0) {
		keys = [keys substringFromIndex:1];
		vals = [vals substringFromIndex:1];
	}
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&userID=0"
							@"&keys=%@"
							@"&vals=%@",
							keys,
							vals];
	
	NSString *urlContents = [KuippConnect formTo:@"updateSettings" WithPost:poststring AndResponse:&response AndError:&error];
	
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:2]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode/10 forView:self]) return;
	if (![KuippConnect sendMessageCode:exitCode%10 forView:self]) return;
	
	NSMutableArray *toSave = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:toSave];
	[parse parseXML:[urlContents substringFromIndex:2]];
	[parse release];
	
	[Misc updateUserSettings:[toSave objectAtIndex:0]];
	
	[toSave release];
	
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Settings Changed"
						  message:@"Your settings have successfully been changed!"
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
	[self settingsChanged:NO];
}

- (void)settingsChanged:(BOOL)itDid {
	saveSettingsButton.enabled = itDid;
	backCancelSettingsButton.title = itDid?@"Cancel":@"Back";
	backCancelSettingsButton.action = itDid?@selector(cancelSettings:):@selector(backSettings:);
}

- (void)changePassword {
	if ([oldpwd.text length]==0) {
		NSLog(@"You need a Password!");
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Error"
							  message:@"You need to input your old password!"
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
	if ([newpwd.text length]==0) {
		NSLog(@"You need a Password!");
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Error"
							  message:@"You need a password!"
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
	if (![newpwd.text isEqualToString:confirm.text]) {
		NSLog(@"Your Passwords don't match!");
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Error"
							  message:@"Your passwords don't match!"
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
		
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&uid=0"
							@"&pwd=%@"
							@"&npw=%@",
							oldpwd.text,
							newpwd.text];
	
	NSString *urlContents = [KuippConnect formTo:@"updatePassword" WithPost:poststring AndResponse:&response AndError:&error];
	
	
	if ([urlContents length]==0) return;
	
	int exitCode = [urlContents intValue];
	
	if (![KuippConnect checkSessionCode:exitCode/10 forView:self]) return;
	if (![KuippConnect registerUser:exitCode%10 forView:self]) return;
	
	NSLog(@"Password successfully changed!");
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Success"
						  message:@"Your password was changed!"
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
}

- (void)cancelKB:(UIBarButtonItem*)sender {
	[local resignFirstResponder];
	[recent resignFirstResponder];
	[oldpwd resignFirstResponder];
	[newpwd resignFirstResponder];
	[confirm resignFirstResponder];
	[interest resignFirstResponder];
	[subject resignFirstResponder];
	[body resignFirstResponder];
	[twitter resignFirstResponder];
}

- (void)inviteFriendsPage:(int)i withToken:(NSString*)s {
	InviteFriends *v = [[InviteFriends alloc]init];
	v.at = s;
	v.tab = i;
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (void)inviteFacebook {
	[self inviteFriendsPage:1 withToken:facebook.accessToken];
}

- (void)inviteTwitter {
	[self inviteFriendsPage:2 withToken:nil];
}

- (void)inputTwitter {
	[twitter becomeFirstResponder];
}

- (void)submitTwitter {
	if ([twitter.text length]==0) {
		NSLog(@"No Twitter Screen Name!");
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Error"
							  message:@"Your Twitter screen name is blank!"
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else {
		[[NSUserDefaults standardUserDefaults]setObject:twitter.text forKey:@"twitterSN"];
		[twitter resignFirstResponder];
		[self inviteTwitter];
	}
}

- (IBAction)numberPadButtonPressed:(UIBarButtonItem*)sender {
	UITextField *t;
	int i;
	if (local.editing) {
		t=local;i=1;
	} else {
		t=recent;i=2;
	}
		
	switch (sender.tag) {
		case 10:
			t.text = [t.text stringByAppendingString:@"."];
			period.enabled = NO;break;
		case 11:
			t.text = [t.text length]==0?[[locationTime objectAtIndex:i]objectForKey:@"t"]:[NSString stringWithFormat:@"%.2f",[t.text doubleValue]];
			[[locationTime objectAtIndex:i]setObject:t.text forKey:@"t"];
			[self settingsChanged:YES];
			[t resignFirstResponder];break;
		default:
			t.text = [t.text stringByAppendingString:[NSString stringWithFormat:@"%d",sender.tag]];break;
	}
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	if (tableView==setTable) return [settings count];
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	if (tableView==catTable) return [catArray count]+1;
	if (tableView==folTable) return [followers count];
	if (tableView==setTable) return [[settings objectAtIndex:section]count];
	if (tab==0) return 11; //Profile
	if (tab!=0) return [searchResults count];
	return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	// Secondary Tables
	if (tableView!=table) {
		if (tableView==setTable) return [self settingTableCell:indexPath];
		
		UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
		
		if (cell==nil) cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"]autorelease];
		
		if (tableView==catTable) {
			if (indexPath.row==0) cell.textLabel.text = @"ALL CATEGORIES";
			else cell.textLabel.text = [[catArray objectAtIndex:indexPath.row-1]objectForKey:@"category"];
		} else {
			NSDictionary *dict = [followers objectAtIndex:indexPath.row];
			cell.textLabel.text = [Misc first:[dict objectForKey:@"firstName"]lastName:[dict objectForKey:@"lastName"]];
		}
		return cell;
	}
	// Main Table
	if (tab==0) return [self profileTableCell:indexPath];
	else if (tab%2==1) return [self messageTableCell:indexPath];
	else return [self connectionTableCell:indexPath];
}

- (UITableViewCell*)settingTableCell:(NSIndexPath*)indexPath {
	NSDictionary *dict = [[settings objectAtIndex:indexPath.section]objectAtIndex:indexPath.row];
	
	UITableViewCell *cell = [setTable dequeueReusableCellWithIdentifier:@"C"];
	if (cell==nil) cell = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"C"]autorelease];
	
	// Get rid of old stuff
	for (id v in [cell.contentView subviews]) {
		if ([v isKindOfClass:[UITextField class]]||
			([v isKindOfClass:[UILabel class]]&&((UILabel*)v).tag!=0)) {
			[v removeFromSuperview];
		}
	}
	// Put in new stuff
	NSString *p = [dict objectForKey:@"p"];
	cell.textLabel.text = p;
	if ([p isEqualToString:@"Local Question"]) {
		NSString *t = [dict objectForKey:@"t"];
		if (local!=nil) [local release];
		local = [[Misc cellTextField:self]retain];
		local.text = [NSString stringWithFormat:@"%.2f",t==nil?0:[t doubleValue]];
		local.inputView = input;
		local.tag = indexPath.row;
		[cell.contentView addSubview:local];
		UILabel *l = [[UILabel alloc]initWithFrame:CGRectMake(local.frame.origin.x+local.frame.size.width+4,local.frame.origin.y,40,local.frame.size.height)];
		l.text = @"miles";
		l.font = [l.font fontWithSize:12];
		l.tag = 1;
		[cell.contentView addSubview:l];
		[l release];
	} else if ([p isEqualToString:@"Recent Question"]) {
		NSString *t = [dict objectForKey:@"t"];
		if (recent!=nil) [recent release];
		recent = [[Misc cellTextField:self]retain];
		recent.text = [NSString stringWithFormat:@"%.2f",t==nil?0:[t doubleValue]];
		recent.inputView = input;
		recent.tag = indexPath.row;
		[cell.contentView addSubview:recent];
		UILabel *l = [[UILabel alloc]initWithFrame:CGRectMake(recent.frame.origin.x+recent.frame.size.width+4,recent.frame.origin.y,40,recent.frame.size.height)];
		l.text = @"hours";
		l.font = [l.font fontWithSize:12];
		l.tag = 1;
		[cell.contentView addSubview:l];
		[l release];
	} else if ([p isEqualToString:@"Old Password"]) {
		cell.textLabel.text = @"";
		if (oldpwd!=nil) [oldpwd release];
		oldpwd = [[Misc cellPasswordField:self]retain];
		oldpwd.placeholder = p;
		oldpwd.tag = indexPath.row;
		[cell.contentView addSubview:oldpwd];
	} else if ([p isEqualToString:@"New Password"]) {
		cell.textLabel.text = @"";
		if (newpwd!=nil) [newpwd release];
		newpwd = [[Misc cellPasswordField:self]retain];
		newpwd.placeholder = p;
		newpwd.tag = indexPath.row;
		[cell.contentView addSubview:newpwd];
	} else if ([p isEqualToString:@"Confirm Password"]) {
		cell.textLabel.text = @"";
		if (confirm!=nil) [confirm release];
		confirm = [[Misc cellPasswordField:self]retain];
		confirm.placeholder = p;
		confirm.tag = indexPath.row;
		confirm.returnKeyType = UIReturnKeySend;
		[cell.contentView addSubview:confirm];
	}
	NSString *s = [dict objectForKey:@"s"];
	cell.detailTextLabel.text = s==nil?@"":s;
	NSString *m = [dict objectForKey:@"m"];
	cell.imageView.image = m==nil?nil:[UIImage imageNamed:m];
	NSString *c = [dict objectForKey:@"c"];
	cell.accessoryType = (c==nil||[c intValue]==0)?UITableViewCellAccessoryNone:UITableViewCellAccessoryCheckmark;
	NSString *o = [dict objectForKey:@"o"];
	if (o!=nil) cell.accessoryView = [[[UIImageView alloc]initWithImage:[UIImage imageNamed:[o intValue]==0?@"BluePin.png":@"RedPin.png"]]autorelease];
	else cell.accessoryView = nil;
	NSString *i = [dict objectForKey:@"i"];
	cell.indentationLevel = i==nil?0:[i intValue];
	cell.textLabel.font = [cell.textLabel.font fontWithSize:17-(i==nil?0:1+[i intValue]*2)];
	cell.selectionStyle = [dict objectForKey:@"!s"]==nil?UITableViewCellSelectionStyleBlue:UITableViewCellSelectionStyleNone;
	
	return cell;
}

- (UITableViewCell*)profileTableCell:(NSIndexPath*)indexPath {
	if (indexPath.row==0) {
		ProfileCard *cell = (ProfileCard*)[table dequeueReusableCellWithIdentifier:@"ProfileCard"];
		if (cell == nil) {
			NSArray *a = [[NSBundle mainBundle]loadNibNamed:@"ProfileCard" owner:nil options:nil];
			for (id cur in a) {
				if ([cur isMemberOfClass:[ProfileCard class]]) {
					cell = cur;
					break;
				}
			}
		}
		
		// Configure the cell...
		[cell.profilePic loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[user objectForKey:@"picture"]]]];
		
		[cell.classPic setImage:[UIImage imageNamed:@"profile.png"]];
		
		cell.name.text = [Misc first:[user objectForKey:@"firstName"]lastName:[user objectForKey:@"lastName"]];
		
		cell.points.text = [NSString stringWithFormat:@"Total Points: %@   Points to Level: %d",[user objectForKey:@"points"],[[level objectForKey:@"maxPoints"]intValue]-[[user objectForKey:@"points"]intValue]];
		
		[cell.interests setTitle:[NSString stringWithFormat:@"Interests: %@",[user objectForKey:@"interests"]]forState:UIControlStateNormal];
		cell.interests.titleLabel.frame = CGRectMake(0,0,250,15*150);
		cell.interests.titleLabel.numberOfLines = 0;
		[cell.interests.titleLabel sizeToFit];
		cell.interests.frame = CGRectMake(62,57-4,250,cell.interests.titleLabel.frame.size.height+8);
		
		if ([uid intValue]!=0) cell.interests.enabled = NO;
		
		cell.boxes.frame = CGRectMake(8,cell.interests.frame.origin.y+cell.interests.frame.size.height,304,47);
		
		cell.bigBox.frame = CGRectMake(4,4,312,cell.boxes.frame.origin.y+cell.boxes.frame.size.height);
		
		cell.classTitle.text = [user objectForKey:@"class"];
		
		cell.level.text = [NSString stringWithFormat:@"Level: %@",[user objectForKey:@"level"]];
		
		cell.medals.text = @"12";
		
		cell.gold.text = [user objectForKey:@"coins"];
		
		cell.nameID = uid;
		return cell;
	} else {
		SingleTextCell *cell = (SingleTextCell*)[table dequeueReusableCellWithIdentifier:@"SingleTextCell"];
		if (cell==nil) {
			NSArray *a = [[NSBundle mainBundle]loadNibNamed:@"SingleTextCell" owner:nil options:nil];
			for (id cur in a) {
				if ([cur isMemberOfClass:[SingleTextCell class]]) {
					cell = cur;
					break;
				}
			}
		}
		
		UILabel *label = cell.text;
		
		switch (indexPath.row) {
			case  1: label.text = [NSString stringWithFormat:@"Asked Kuipps (%@)",[user objectForKey:@"qCount"]];break;
			case  2: label.text = [NSString stringWithFormat:@"Answered Kuipps (%@)",[user objectForKey:@"aCount"]];break;
			case  3: label.text = [NSString stringWithFormat:@"Following (%@)",[user objectForKey:@"numFollowing"]];break;
			case  4: label.text = [NSString stringWithFormat:@"Followers (%@)",[user objectForKey:@"numFollowers"]];break;
			case  5: label.text = @"School";break;
			case  6: label.text = @"";break;
			case  7: label.text = @"Recently Asked";break;
			case  8: label.text = [question objectForKey:@"question"];break;
			case  9: label.text = @"Recently Answered";break;
			case 10: label.text = [answer objectForKey:@"answer"];break;
			default: break;
		}
		
		if (indexPath.row==6||indexPath.row==7||indexPath.row==9) {
			cell.accessoryType = UITableViewCellAccessoryNone;
			cell.selectionStyle = UITableViewCellSelectionStyleNone;
		} else {
			cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
			cell.selectionStyle = UITableViewCellSelectionStyleBlue;
		}

		
		if (indexPath.row==6) {
			cell.backgroundView.backgroundColor = [UIColor lightGrayColor];
		} else if (indexPath.row==7||indexPath.row==9) {
			cell.backgroundView.backgroundColor = [UIColor darkGrayColor];
			cell.text.textColor = [UIColor whiteColor];
		} else {
			cell.backgroundView.backgroundColor = [UIColor whiteColor];
			cell.text.textColor = [UIColor darkGrayColor];
		}
		
		label.frame = CGRectMake(4,4,292,15*150);
		[label sizeToFit];
		cell.frame = CGRectMake(0,0,cell.frame.size.width,label.frame.origin.y+label.frame.size.height+4);
		return cell;
	}
}

- (UITableViewCell*)messageTableCell:(NSIndexPath*)indexPath {
	ChainCell *cell = (ChainCell*)[table dequeueReusableCellWithIdentifier:@"ChainCell"];
	if (cell==nil) {
		NSArray *a = [[NSBundle mainBundle]loadNibNamed:@"ChainCell" owner:nil options:nil];
		for (id cur in a) {
			if ([cur isMemberOfClass:[ChainCell class]]) {
				cell = cur;
				break;
			}
		}
	}
	
	NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
	
	// Find short date
	int seconds = [[dict objectForKey:@"datetime"]intValue];
	NSDate *date = [NSDate dateWithTimeIntervalSince1970:seconds];
	NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
	[formatter setTimeStyle:NSDateFormatterShortStyle];
	[formatter setDateStyle:NSDateFormatterShortStyle];
	
	[cell.pic setImage:[UIImage imageNamed:@"RedPin.png"]];
	
	[cell.name setUserInteractionEnabled:NO];
	[cell.name setEnabled:NO];
	[cell.name setTitle:[NSString stringWithFormat:@"%@: %@",tab==0?@"From":@"To",[Misc first:[dict objectForKey:@"firstName"]lastName:[dict objectForKey:@"lastName"]]]forState:UIControlStateNormal];
	
	if ([[dict objectForKey:@"questionID"]intValue]==0) { // message
		[cell.icon setImage:[UIImage imageNamed:@"mail.png"]];
		
		cell.primary1.text = [NSString stringWithFormat:@"       <%@>",[dict objectForKey:@"subject"]];
		cell.primary1.frame = CGRectMake(cell.primary1.frame.origin.x,cell.primary1.frame.origin.y,232,15*150);
		cell.primary1.numberOfLines = 1;
		[cell.primary1 sizeToFit];
		
		cell.primary2.text = [dict objectForKey:@"message"];
	} else { // directed question
		[cell.icon setImage:[UIImage imageNamed:@"YellowPin.png"]];
		
		cell.primary1.text = [NSString stringWithFormat:@"       %@",[dict objectForKey:@"question"]];
		cell.primary1.frame = CGRectMake(cell.primary1.frame.origin.x,cell.primary1.frame.origin.y,232,15*150);
		cell.primary1.numberOfLines = 0;
		[cell.primary1 sizeToFit];
		
		cell.primary2.text = @"";
	}
	
	cell.uclass.text = [dict objectForKey:@"class"];
	
	cell.secondary.text = [formatter stringFromDate:date];
	[formatter release];
	
	cell.frame = CGRectMake(cell.frame.origin.x,cell.frame.origin.y,cell.frame.size.width,fmax(65,cell.primary1.frame.origin.y+cell.primary1.frame.size.height)+4);
	return cell;
}

- (UITableViewCell*)connectionTableCell:(NSIndexPath*)indexPath {
	UserCell *cell = (UserCell*)[table dequeueReusableCellWithIdentifier:@"UserCell"];
	if (cell==nil) {
		NSArray *a = [[NSBundle mainBundle]loadNibNamed:@"UserCell" owner:nil options:nil];
		for (id cur in a) {
			if ([cur isMemberOfClass:[UserCell class]]) {
				cell = cur;
				break;
			}
		}
	}
	
	NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
	
	[cell.pic setImage:[UIImage imageNamed:@"RedPin.png"]];
	
	cell.name.text = [Misc first:[dict objectForKey:@"firstName"]lastName:[dict objectForKey:@"lastName"]];
	[cell.name sizeToFit];
	
	cell.primary.text = [NSString stringWithFormat:@"Level %@ - %@",[dict objectForKey:@"level"],[dict objectForKey:@"class"]];
	return cell;
}
/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */
/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */
/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */
/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */
#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	// Category/Follower Overlay
	if (tableView==catTable||tableView==folTable) return 30;
	// Settings Table
	if (tableView==setTable) return indexPath.section==0?44:30;
	// Main Table
	if (tab==0) switch (indexPath.row) {
		case  0: {
			UILabel *one = [[UILabel alloc]init];
			one.text = [NSString stringWithFormat:@"Interests: %@",[user objectForKey:@"interests"]];
			one.font = [one.font fontWithSize:12];
			one.numberOfLines = 0;
			one.frame = CGRectMake(62,57,250,15*150);
			[one sizeToFit];
			
			int ret = fmax(23,one.frame.origin.y+one.frame.size.height+4+47+8);
			
			[one release];
			
			return ret;
		}
		case  6: return 10;
		case  8: {
			UILabel *one = [[UILabel alloc]init];
			one.text = [question objectForKey:@"question"];
			one.font = [one.font fontWithSize:14];
			one.numberOfLines = 0;
			one.frame = CGRectMake(4,4,292,17*150);
			[one sizeToFit];
			
			int ret = fmax(23,one.frame.origin.y+one.frame.size.height+4);
			
			[one release];
			
			return ret;
		}
		case 10: {
			UILabel *one = [[UILabel alloc]init];
			one.text = [answer objectForKey:@"answer"];
			one.font = [one.font fontWithSize:14];
			one.numberOfLines = 0;
			one.frame = CGRectMake(4,4,292,17*150);
			[one sizeToFit];
			
			int ret = fmax(23,one.frame.origin.y+one.frame.size.height+4);
			
			[one release];
			
			return ret;
		}
		default: return 25;
	} else if (tab%2==1) {
		NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
		
		if ([[dict objectForKey:@"questionID"]intValue]==0) return 69;
		
		UILabel *one = [[UILabel alloc]init];
		one.text = @"1";
		one.font = [one.font fontWithSize:12];
		[one sizeToFit];
		
		UILabel *two = [[UILabel alloc]init];
		two.text = 	[NSString stringWithFormat:@"      %@",[dict objectForKey:@"question"]];
		two.font = [two.font fontWithSize:12];
		two.numberOfLines = 0;
		two.frame = CGRectMake(0,one.frame.size.height,232,15*150);
		[two sizeToFit];
		
		int ret = fmax(65,two.frame.origin.y+two.frame.size.height)+4;
		
		[one release];
		[two release];
		
		return ret;
	} else {
		return 56; //Following/Follower
	}
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	// Category/Follower Overlay
	if (tableView==catTable) {
		catID = indexPath.row;
		[catTable removeFromSuperview];
		catTable = nil;
		[self refreshCategory];
		return;
	} else if (tableView==folTable) {
		toID = indexPath.row;
		[folTable removeFromSuperview];
		folTable = nil;
		[self refreshTo];
		
		NSArray *views = [self.view subviews];
		[[views objectAtIndex:[views count]-1]removeFromSuperview];
		return;
	} else if (tableView==setTable) {
		NSMutableArray *a = [settings objectAtIndex:indexPath.section];
		NSMutableDictionary *d = [a objectAtIndex:indexPath.row];
		NSString *p = [d objectForKey:@"p"];
		if ([d objectForKey:@"!s"]==nil) switch (indexPath.section) {
			case  1: if ([p isEqualToString:@"Location & Time"]) {
				NSIndexSet *is = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(indexPath.row+1,[locationTime count])];
				
				NSMutableArray *ips = [[NSMutableArray alloc]init];
				for (int i=0;i<[locationTime count];i++) [ips addObject:[NSIndexPath indexPathForRow:indexPath.row+1+i inSection:indexPath.section]];
				
				[tableView beginUpdates];
				if ([[d objectForKey:@"o"]intValue]==0) { // was Closed
					[a insertObjects:locationTime atIndexes:is];
					[d setObject:@"1" forKey:@"o"];
					[tableView insertRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
				} else { // was Open
					[a removeObjectsAtIndexes:is];
					[d setObject:@"0" forKey:@"o"];
					[tableView deleteRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
				}
				[ips release];
				[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationNone];
				[tableView endUpdates];
			} else if ([p isEqualToString:@"Find Connections"]) {
				NSIndexSet *is = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(indexPath.row+1,[findConnections count])];
				
				NSMutableArray *ips = [[NSMutableArray alloc]init];
				for (int i=0;i<[findConnections count];i++) [ips addObject:[NSIndexPath indexPathForRow:indexPath.row+1+i inSection:indexPath.section]];
				
				[tableView beginUpdates];
				if ([[d objectForKey:@"o"]intValue]==0) { // was Closed
					[a insertObjects:findConnections atIndexes:is];
					[d setObject:@"1" forKey:@"o"];
					[tableView insertRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
				} else { // was Open
					[a removeObjectsAtIndexes:is];
					[d setObject:@"0" forKey:@"o"];
					[tableView deleteRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
				}
				[ips release];
				[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationNone];
				[tableView endUpdates];
			} else if ([p isEqualToString:@"Notifications"]) {
				NSIndexSet *is = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(indexPath.row+1,[notifications count])];
				
				NSMutableArray *ips = [[NSMutableArray alloc]init];
				for (int i=0;i<[notifications count];i++) [ips addObject:[NSIndexPath indexPathForRow:indexPath.row+1+i inSection:indexPath.section]];
				
				[tableView beginUpdates];
				if ([[d objectForKey:@"o"]intValue]==0) { // was Closed
					[a insertObjects:notifications atIndexes:is];
					[d setObject:@"1" forKey:@"o"];
					[tableView insertRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
				} else { // was Open
					[a removeObjectsAtIndexes:is];
					[d setObject:@"0" forKey:@"o"];
					[tableView deleteRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
				}
				[ips release];
				[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationFade];
				[tableView endUpdates];
			} else if ([p isEqualToString:@"Facebook"]) {
				facebook = ((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).facebook;
				if (facebook.expirationDate!=nil&&[facebook.expirationDate timeIntervalSinceNow]>0) {
					[self inviteFacebook];
				} else {
					NSArray *permissions = [[Misc facebookPermissions]retain];
					
					[facebook authorize:permissions delegate:self];
					
					[permissions release];
				}
			} else if ([p isEqualToString:@"Twitter"]) {
				NSString *tid = [[NSUserDefaults standardUserDefaults]objectForKey:@"twitterID"];
				if ([tid intValue]!=0) {
					[self inviteTwitter];
				} else {
					[self inputTwitter];
				}
			} else if ([p isEqualToString:@"Address Book"]) {
				[self inviteFriendsPage:0 withToken:nil];
			} else if ([p isEqualToString:@"Email Addresses"]) {
				[self inviteFriendsPage:4 withToken:nil];
			} else if ([p isEqualToString:@"First & Last Names"]) {
				[self inviteFriendsPage:3 withToken:nil];
			} else { // Checkmark Stuff
				[d setObject:[[d objectForKey:@"c"]intValue]==0?@"1":@"0" forKey:@"c"];
				[self settingsChanged:YES];
				[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationFade];
			} break;
			case  2: switch (indexPath.row) {
				case  0: break;//Terms of Service
				case  1: break;//Privacy Policy
				default: break;
			}
			case  3: if ([p isEqualToString:@"Change Password"]) {
				NSMutableArray *ips = [[NSMutableArray alloc]init];
				for (int i=0;i<3;i++) [ips addObject:[NSIndexPath indexPathForRow:indexPath.row+1+i inSection:indexPath.section]];
				
				[tableView beginUpdates];
				if ([[d objectForKey:@"o"]intValue]==0) { // was Closed
					[a insertObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Old Password",@"p",@"1",@"!s",@"1",@"i",nil]atIndex:indexPath.row+1];
					[a insertObject:[NSDictionary dictionaryWithObjectsAndKeys:@"New Password",@"p",@"1",@"!s",@"1",@"i",nil]atIndex:indexPath.row+2];
					[a insertObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Confirm Password",@"p",@"1",@"!s",@"1",@"i",nil]atIndex:indexPath.row+3];
					[d setObject:@"1" forKey:@"o"];
					[tableView insertRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
				} else { // was Open
					[a removeObjectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(indexPath.row+1,3)]];
					[d setObject:@"0" forKey:@"o"];
					[tableView deleteRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationBottom];
				}
				[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationNone];
				[tableView endUpdates];
			} else if ([p isEqualToString:@"Logout"]) {
				NSUserDefaults *save = [NSUserDefaults standardUserDefaults];
				[save setObject:@"0" forKey:@"sessionID"];
				[(KuippAppDelegate*)[UIApplication sharedApplication].delegate toLogin];
			} break;//Logout
			default: break;
		}
	} else if (tab==0) {
		if (indexPath.row==8&&questionSet) {
			Question *v = [[Question alloc]init];
			v.qid = [question objectForKey:@"questionID"];
			[self.navigationController pushViewController:v animated:YES];
			[v release];
		} else if (indexPath.row==10&&answerSet) {
			Answer *v = [[Answer alloc]init];
			v.aid = [answer objectForKey:@"answerID"];
			[self.navigationController pushViewController:v animated:YES];
			[v release];
		} else if (indexPath.row==1||indexPath.row==2/*||indexPath.row==5*/) {
			ProfileTable *v = [[ProfileTable alloc]init];
			v.uid=uid;
			switch (indexPath.row) {
				case  2: v.tab=0;break;
				case  3: v.tab=1;break;
				default: v.tab=2;break;
			}
			[self.navigationController pushViewController:v animated:YES];
			[v release];
		} else if (indexPath.row==3||indexPath.row==4) {
			[self toggleFilter:connectionButton];
			if (indexPath.row==4) [self filter:followersButton];
		}
	} else if (tab%2==1) {
		NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
		if ([[dict objectForKey:@"questionID"]intValue]==0) { // message
			Message *v = [[Message alloc]init];
			v.dict = dict;
			[self.navigationController pushViewController:v animated:YES];
			[v release];
		} else { // directed question
			Question *v = [[Question alloc]init];
			v.qid = [dict objectForKey:@"questionID"];
			[self.navigationController pushViewController:v animated:YES];
			[v release];
		}
	} else {
		NSDictionary *dict = [searchResults objectAtIndex:indexPath.row];
		Profile *v = [[Profile alloc]init];
		v.uid = [dict objectForKey:@"userID"];
		[self.navigationController pushViewController:v animated:YES];
		[v release];
	}
}
	
#pragma mark -
#pragma mark FBSessionDelegate
	
- (void)fbDidLogin {
	[self inviteFacebook];
}
	
- (void)fbDidNotLogin:(BOOL)cancelled {
	NSLog(@"Failed to log into facebook. User canceled? %@",cancelled);
}
		
#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	UIView *top;
	
	if (subject.editing||[body isFirstResponder]) top = messageView;
	else if (twitter.editing) top = twitterView;
	else if (interest.editing) top = interestsView;
	else top = nil;
	
	[self.view bringSubviewToFront:top];
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	top.frame = CGRectMake(top.frame.origin.x,-1*top.frame.size.height/2+delta*top.frame.size.height/2,top.frame.size.width,top.frame.size.height);
	bot.frame = CGRectMake(bot.frame.origin.x,self.view.frame.size.height+bot.frame.size.height/2-delta*bot.frame.size.height/2,bot.frame.size.width,bot.frame.size.height);
	table.frame = CGRectMake(0,table.frame.origin.y,table.frame.size.width,table.frame.size.height-delta*(kb.size.height-49));
	setTable.frame = CGRectMake(0,setTable.frame.origin.y,setTable.frame.size.width,setTable.frame.size.height-delta*(kb.size.height-49));
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	if (bars.frame.origin.y==0&&
		(recent.editing||local.editing||oldpwd.editing||newpwd.editing||confirm.editing))
		[self toggleBars];
	if (local.editing||recent.editing) {
		int tag;
		if (local.editing) tag=local.tag;
		else tag=recent.tag;
		[setTable scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:tag inSection:1]atScrollPosition:UITableViewScrollPositionTop animated:YES];
	}
	if (oldpwd.editing||newpwd.editing||confirm.editing) {
		int tag;
		if (oldpwd.editing) tag=oldpwd.tag;
		else if (newpwd.editing) tag=newpwd.tag;
		else tag=confirm.tag;
		[setTable scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:tag inSection:3]atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
	}
	options.action = @selector(cancelKB:);
	options.title = @"Cancel";
	options.style = UIBarButtonItemStyleDone;
}

- (void)keyboardWasHidden:(NSNotification*)note {
	[self keyboardAdjust:note:-1];
	options.action = @selector(toggleBars);
	options.title = @"Options";
	options.style = bars.frame.origin.y==0?UIBarButtonItemStyleDone:UIBarButtonItemStyleBordered;
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	if (textField==subject) {
		[body becomeFirstResponder];
		return NO;
	}
	if (textField==oldpwd) {
		[newpwd becomeFirstResponder];
		return NO;
	}
	if (textField==newpwd) {
		[confirm becomeFirstResponder];
		return NO;
	}
	if (textField==confirm) [self changePassword];
	if (textField==twitter) [self submitTwitter];
	if (textField==interest) [self add:nil];
	[textField resignFirstResponder];
	return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
	if (textField==local||textField==recent) period.enabled = YES;
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
	if (textField==local||textField==recent) period.enabled = YES;
}

#pragma mark -
#pragma mark UITextViewDelegate

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
	int newCount = [count.text intValue]-[text length]+range.length;
	if (newCount<0) return NO;
	return YES;
}

- (void)textViewDidChange:(UITextView *)textView {
	[self refreshCount];
}

#pragma mark -
#pragma mark UIScrollView

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (scrollView!=table) return;
	if (scrollView.contentOffset.y < 0) {
		switch (tab) {
			case  0: [self refresh:profileButton];break;
			case  1: [self refresh:messageButton];break;
			case  2: [self refresh:connectionButton];break;
			case  3: [self refresh:outboxButton];break;
			case  4: [self refresh:followersButton];break;
			default: break;
		}
	}
}

#pragma mark -
#pragma mark UISearchBarDelegate

- (BOOL)searchString:(NSArray*)array inDict:(NSDictionary*)dict {
	BOOL found = YES;
	NSString *element;
	for (int i=0;i<[array count];i++) {
		element = [[[array objectAtIndex:i]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]lowercaseString];
		
		if ([element length]!=0) {
			NSRange r1 = [[[dict objectForKey:@"firstName"]lowercaseString]rangeOfString:element];
			
			NSRange r2 = [[[dict objectForKey:@"lastName"]lowercaseString]rangeOfString:element];
			
			NSRange r3 = [[[dict objectForKey:@"email"]lowercaseString]rangeOfString:element];
			
			NSRange r4 = [[[dict objectForKey:@"subject"]lowercaseString]rangeOfString:element];
			
			NSRange r5 = [[[dict objectForKey:@"message"]lowercaseString]rangeOfString:element];
			
			found = found && (r1.length>0	||	r2.length>0	||	r3.length>0	|| r4.length>0	||	r5.length>0);
			
			if (!found) return NO;
		}
	}
	return found;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	[self applySearchField:searchBar];
	[self toggleSearch:nil];
}

- (void)applySearchField:(UISearchBar*)searchBar {
	if (searchResults!=nil) [searchResults release];
	
	if ([searchBar.text length]==0) {
		searchResults = [[NSMutableArray alloc]initWithArray:tabResults];
	} else {
		searchResults = [[NSMutableArray alloc]init];
		
		NSArray *explode = [searchBar.text componentsSeparatedByString:@" "];
		for (int i=0;i<[tabResults count];i++) {
			NSDictionary *dict = [tabResults objectAtIndex:i];
			if ([self searchString:explode inDict:dict]) {
				[searchResults addObject:dict];
			}
		}
	}
	
	[self.view bringSubviewToFront:table];
	[table reloadData];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
	[self toggleSearch:nil];
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:YES animated:YES];
	[table setAllowsSelection:NO];
	[table setScrollEnabled:NO];
	return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
	[searchBar setShowsCancelButton:NO animated:YES];
	[table setAllowsSelection:YES];
	[table setScrollEnabled:YES];
	return YES;
}

#pragma mark -
#pragma mark CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager*)manager didUpdateToLocation:(CLLocation*)newLocation fromLocation:(CLLocation*)oldLocation {
	userLoc = newLocation;
	
	[self send];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
	NSLog(@"%@",error);
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Session Error"]) {
		[self.navigationController popToRootViewControllerAnimated:YES];
	} else if ([alertView.title isEqualToString:@"Confirm Interest"]&&buttonIndex==1) {
		[self add];
	}
}

#pragma mark -
#pragma mark Initialization
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[super viewDidLoad];

	for (UIView *v in [search subviews]) {
		if ([v conformsToProtocol:@protocol(UITextInputTraits)]) {
			@try {
				[(UITextField*)v setEnablesReturnKeyAutomatically:NO];
				[(UITextField*)v setKeyboardAppearance:UIKeyboardAppearanceAlert];
			}
			@catch (NSException *e) {
				NSLog(@"failed to change searchTextField's color and button");
			}
		}
	}
	
	self.navigationItem.backBarButtonItem.title = @"Back";
	[table setTableHeaderView:[Misc refreshCellView]];
	table.contentInset = UIEdgeInsetsMake(-1*[Misc refreshCellHeight],0,0,0);
	
	[self refresh:profileButton];
	
	[self cancelSettings:nil];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	manager = [[CLLocationManager alloc]init];
	[manager setDelegate:self];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	
	self.navigationItem.titleView = [Misc logoBar];
	options = [Misc options:self];
	[self.navigationItem setRightBarButtonItem:options animated:NO];
	
	subject.text = @"";
	body.text = @"";
	interest.text = @"";
}

- (void)viewWillDisappear:(BOOL)animated {
	[manager release];
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	self.navigationItem.titleView = nil;
	self.navigationItem.rightBarButtonItem = nil;
	
	[super viewWillDisappear:animated];
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return [Misc orientations:interfaceOrientation];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[uid release];
	
    [super dealloc];
}

@end
