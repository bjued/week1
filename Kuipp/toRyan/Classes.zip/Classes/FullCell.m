//
//  FullCell.m
//  Kuipp
//
//  Created by Brandon Jue on 3/12/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "FullCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation FullCell

@synthesize selectable,item,bott;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        // Initialization code.
		self.backgroundView = [[UIView alloc]init];
		self.backgroundView.layer.masksToBounds = YES;
		self.backgroundView.layer.cornerRadius = [Misc borderCurve];
		self.backgroundView.layer.borderColor = [[Misc kuippOrangeColor]CGColor];
		self.backgroundView.layer.borderWidth = [Misc border];
		
		self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect c = self.bounds;
	double w = c.size.width;
	double h = c.size.height;
	
	double buf = [Misc buffer];
	
	self.backgroundView.frame = CGRectMake(buf*2,buf,w-buf*4,h-buf*2);
	
	c = self.contentView.bounds;
	w = c.size.width;
	h = c.size.height;
	
	self.contentView.frame = CGRectMake(buf*2,buf,w-buf*4,h-buf*2);
	
	c = self.contentView.bounds;
	w = c.size.width;
	h = c.size.height;
	
	double cx = self.imageView.image?buf*3+self.imageView.image.size.width:buf*2;
	double cw = w-cx-buf*2;
	
	((UIView*)item).frame = CGRectMake(cx, 0, cw, h);
	
	double ih = [Misc heightForFontSize:[Misc mainSize]];
	((UIView*)bott).frame = CGRectMake(cx, h-ih, cw, ih);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	self.backgroundView.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)setHighlighted:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	self.backgroundView.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)dealloc {
	[item release];
	[bott release];
	
    [super dealloc];
}

@end
