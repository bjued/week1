//
//  TopCell.m
//  Kuipp
//
//  Created by Brandon Jue on 3/12/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "TopCell.h"

@implementation TopCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect c = self.bounds;
	double w = c.size.width;
	double h = c.size.height;
	
	double buf = [Misc buffer];
	
	self.backgroundView.frame = CGRectMake(buf*2, buf, w-buf*4, h-buf);
	bkgd.frame = CGRectMake(0, 0, w-buf*4, h-buf+20);
	
	c = self.contentView.bounds;
	w = c.size.width;
	h = c.size.height;
	
	self.contentView.frame = CGRectMake(buf*2, buf, w-buf*4, h-buf);
	
	c = self.contentView.frame;
	w = c.size.width;
	h = c.size.height;
	
	double cx = self.imageView.image?buf*3+self.imageView.image.size.width:buf*2;
	double cw = w-cx-buf*2;
	
	double lh = [Misc heightForFontSize:label.font.pointSize];
	label.frame = CGRectMake(cx, (h-lh)/2, cw, lh);
	
	double ih = ((UIView*)item).frame.size.height;
	((UIView*)item).frame = CGRectMake(cx, (h-ih)/2, cw, ih);
	
	if (self.accessoryView) {
		c = self.accessoryView.frame;
		w = c.size.width;
		double ah = c.size.height;
		double x = c.origin.x;
		self.accessoryView.frame = CGRectMake(x-buf*2, buf+(h-ah)/2, w, ah);
	}
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	bkgd.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)setHighlighted:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	bkgd.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)dealloc {
    [super dealloc];
}

@end
