//
//  UrFeats.h
//  Kuipp
//
//  Created by Brandon Jue on 3/17/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIScrollViewCancelControls.h"

@interface UrFeats : UIViewController {
	NSString *uid;
	int mid;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	
	NSArray *medNames;
	NSArray *medDescs;
	
	NSMutableArray *medals;
	
	// Views
	IBOutlet UIView *scrollV;
	IBOutlet UIView *imageV;
	IBOutlet UILabel *mName;
	IBOutlet UIImageView *image;
	UIView *divider;
	IBOutlet UILabel *text;
	IBOutlet UIScrollViewCancelControls *scroll;
}

@property(nonatomic,retain) NSString *uid;
@property(nonatomic,assign) int mid;
- (void)back;
- (void)createGhostsMedals:(NSArray *)names descriptions:(NSArray *)descs;
- (void)refreshAll;
- (void)refresh:(id)obj;
- (void)splitData;
- (void)reloadView;
- (void)reloadScroll;
- (void)displayMedal:(UIButton *)sender;

@end
