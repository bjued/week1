//
//  LeaderCell.m
//  Kuipp
//
//  Created by Brandon Jue on 3/14/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "LeaderCell.h"


@implementation LeaderCell

@synthesize selectable,dict,rank,mark,imag,name,foot;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        // Initialization code.
		cell = [[UIView alloc]init];
		cell.backgroundColor = [UIColor whiteColor];
		
		rank = [[UILabel alloc]init];
		rank.backgroundColor = [UIColor clearColor];
		rank.font = [UIFont systemFontOfSize:[Misc nameSize]];
		rank.textColor = [Misc kuippOrangeColor];
		rank.textAlignment = UITextAlignmentRight;
		
		mark = [[UIImageView alloc]init];
		mark.clipsToBounds = YES;
		mark.contentMode = [Misc imageFitStyle];
		mark.backgroundColor = [UIColor clearColor];
		mark.userInteractionEnabled = NO;
		
		imgV = [[UIView alloc]init];
		imgV.clipsToBounds = YES;
		imgV.backgroundColor = [UIColor clearColor];
		
		imag = [[UIImageView alloc]init];
		imag.clipsToBounds = YES;
		imag.contentMode = [Misc imageFitStyle];
		imag.backgroundColor = [UIColor clearColor];
		imag.userInteractionEnabled = NO;
		
		name = [[UILabel alloc]init];
		name.backgroundColor = [UIColor clearColor];
		name.font = [UIFont boldSystemFontOfSize:[Misc nameSize]];
		name.textColor = [Misc kuippOrangeColor];
		
		foot = [[UILabel alloc]init];
		foot.backgroundColor = [UIColor clearColor];
		foot.font = [UIFont systemFontOfSize:[Misc mainSize]];
		foot.textColor = [UIColor whiteColor];
		
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		
		[self.backgroundView addSubview:cell];
		[self.contentView addSubview:rank];
		[self.contentView addSubview:mark];
		[self.contentView addSubview:imgV];
		[imgV addSubview:imag];
		[self.contentView addSubview:name];
		[self.contentView addSubview:foot];
    }
    return self;
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGRect c = self.contentView.bounds;
	double w = c.size.width;
	double h = c.size.height;
	
	double buf = [Misc buffer];
	double img = [Misc leaderSize];
	
	CGRect a = self.accessoryView.frame;
	double aw = (!self.accessoryView?0:(a.size.width+buf*2));
	
	cell.frame = CGRectMake(0,0,self.frame.size.width,self.frame.size.height);
	
	/*
	 * [buf|buf|rank|buf|img|buf|name/foot|buf|buf|aw|buf|buf]
	 */
	
	rank.frame = CGRectMake(    0,   buf   ,buf*6,h-buf*2);
	mark.frame = CGRectMake(buf*2,(h-15 )/2,15   ,15	 );
	imgV.frame = CGRectMake(buf*7,(h-img)/2,img  ,  img  );
	
	BOOL b = [imag.image isEqual:[Misc defaultProfile]];
	double r = img/[Misc profileSize];
	int picX = [[dict objectForKey:@"picX"]intValue]*r;
	int picY = [[dict objectForKey:@"picY"]intValue]*r;
	double picZ = [[dict objectForKey:@"picZ"]doubleValue]*r;
	CGSize picS = imag.image.size;
	imag.frame = CGRectMake(b?0:picX, b?0:picY, b?img:picS.width*picZ, b?img:picS.height*picZ);
	
	double nh = [Misc heightForFontSize:[Misc nameSize]];
	double fh = [Misc heightForFontSize:[Misc mainSize]];
	
	name.frame = CGRectMake(buf*8+img,h/2-nh,w-buf*8-img-aw,nh);
	foot.frame = CGRectMake(buf*8+img,h/2   ,w-buf*8-img-aw,fh);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	cell.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)setHighlighted:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
	selected = selected && selectable;
	cell.backgroundColor = selected?[Misc selectedColor]:[UIColor whiteColor];
}

- (void)dealloc {
	[dict release];
	[rank release];
	[mark release];
	[imag release];
	[name release];
	[foot release];
	
    [super dealloc];
}

@end
