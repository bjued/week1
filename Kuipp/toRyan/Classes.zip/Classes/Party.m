//
//  Party.m
//  Kuipp
//
//  Created by Brandon Jue on 7/12/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import "Party.h"
//#import "PartyCell.h"
#import "ASyncImageLoadDelegate.h"
#import "SearchTable.h"
#import "ButtonCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation Party

@synthesize uid;

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (void)mainThreadImages {
	[images release];
	images = [((KuippAppDelegate*)[UIApplication sharedApplication].delegate).images retain];
	for (NSDictionary *d in users) {
		NSString *url = [d objectForKey:@"picture"];
		UIImage *pic = [images objectForKey:url];
		if (pic==nil||[pic isEqual:[Misc defaultProfile]]) {
			[images setObject:[Misc defaultProfile]forKey:url];
			if (![url isEqualToString:[Misc defaultProfileURL]]) {
				ASyncImageLoadDelegate *del = [[[ASyncImageLoadDelegate alloc]init]autorelease];
				[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]delegate:[del loadURLString:url intoDictionary:images]];
			}
		}
	}
}

- (void)aSyncImageLoaded {[table reloadData];}

- (void)refreshAll {
	[refreshCell refreshing];
	
	NSString *p = [NSString stringWithFormat:
				   @"&userID=%@",
				   [uid urlEncode]];
	
	[kuipp formTo:@"selectParty" WithPost:p];
}

- (void)refresh:(id)obj {
	NSString *urlContents = [KuippConnect connectionData:kuipp.data];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[dicts release];
	dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	[self splitData];
	[self mainThreadImages];
	
	[refreshCell refreshed];
	
	NSUserDefaults *s = [NSUserDefaults standardUserDefaults];
	int myID = [[s objectForKey:@"userID"]intValue];
	
	if ([uid intValue]==myID) {
		self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"More"];
		UIButton *button = (UIButton*)self.navigationItem.rightBarButtonItem.customView;
		[button addTarget:self action:@selector(more) forControlEvents:UIControlEventTouchUpInside];
	}
	
	[table reloadData];
}

- (void)splitData {
	[users release];
	users = [[NSMutableArray alloc]initWithCapacity:[Misc maxPartySize]];
	[party release];
	party = nil;
	
	for (int i=0;i<[dicts count];i++) {
		NSDictionary *d = [dicts objectAtIndex:i];
		NSString *s = [d objectForKey:@"head"];
		if ([s isEqualToString:@"Party"]) party = [[NSDictionary alloc]initWithDictionary:d];
		else if ([s isEqualToString:@"User"]) [users addObject:d];
	}
}

- (void)create {
	[name becomeFirstResponder];
	
	[self start];
}

- (void)submit {
	if ([name.text length]==0) {
		NSLog(@"Your party needs a name!");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Oops!"
				 message:@"Your Party needs a name!"
				 delegate:nil
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else if ([name.text length]>50) {
		NSLog(@"Your party name is too long!");
		UIAlertView *alert;
		alert = [[UIAlertView alloc]
				 initWithTitle:@"Oops!"
				 message:@"Your Party name is too long!"
				 delegate:nil
				 cancelButtonTitle:@"OK"
				 otherButtonTitles:nil];
		[alert show];
		[alert release];
	} else {
		((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = NO;
		NSURLResponse *r;
		NSError *e;
		
		NSString *p = [NSString stringWithFormat:
					   @"&uid=0&pnm=%@",
					   [name.text urlEncode]];
		
		NSString *urlContents = [KuippConnect formTo:@"insertParty" WithPost:p AndResponse:&r AndError:&e];
		
		((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
		
		if ([urlContents length]==0) return;
		
		if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
		
		[self cancel];
	}
}

- (void)invFol {
	SearchTable *v = [[SearchTable alloc]init];
	v.type = @"Party";
	v.party = self;
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (void)invite:(int)iid withName:(NSString*)n{
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = NO;
	NSURLResponse *r;
	NSError *e;
	
	NSString *p = [NSString stringWithFormat:
				   @"&uid=0&iid=%d",
				   iid];
	
	NSString *urlContents = [KuippConnect formTo:@"insertPartyInvite" WithPost:p AndResponse:&r AndError:&e];
	
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Scholarship Sent!"
						  message:[NSString stringWithFormat:@"A scholarship has been offered to %@ to attend %@!",n,[party objectForKey:@"name"]]
						  delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];
	[alert release];
}

- (void)leave {
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = NO;
	NSURLResponse *r;
	NSError *e;
	
	NSString *p = [NSString stringWithFormat:
				   @"&uid=0&pnm=%@&acp=0",
				   [[party objectForKey:@"name"] urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"updatePartyInvite" WithPost:p AndResponse:&r AndError:&e];
	
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[self refreshAll];
	
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Bye!"
						  message:[NSString stringWithFormat:@"You are no longer a member of %@!",[party objectForKey:@"name"]]
						  delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];
	[alert release];
}

- (void)more {
	if (!options) {
		options = [[UIView alloc]init];
		options.backgroundColor = [UIColor blackColor];
		[self.view addSubview:options];
		double height = 0;
		double buf = [Misc buffer];
		double w = self.view.frame.size.width;
		double bch = [Misc buttonCellHeight];
		
		UIButton *b;
		// View Scholarships
		b = [UIButton buttonWithType:UIButtonTypeCustom];
		[b setBackgroundImage:[Misc buttonCell] forState:UIControlStateNormal];
		[b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
		b.titleLabel.font = [UIFont systemFontOfSize:[Misc buttonFontSize]];
		[b setTitle:@"Scholarships" forState:UIControlStateNormal];
		[b addTarget:self action:@selector(scholarships) forControlEvents:UIControlEventTouchUpInside];
		b.frame = CGRectMake(buf*2, height+buf, w-buf*4, bch);
		[options addSubview:b];
		height += bch+buf*2;
		if (party) {
			// View Rankings
			b = [UIButton buttonWithType:UIButtonTypeCustom];
			[b setBackgroundImage:[Misc buttonCell] forState:UIControlStateNormal];
			[b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
			b.titleLabel.font = [UIFont systemFontOfSize:[Misc buttonFontSize]];
			[b setTitle:@"Rankings" forState:UIControlStateNormal];
			[b addTarget:self action:@selector(rankings) forControlEvents:UIControlEventTouchUpInside];
			b.frame = CGRectMake(buf*2, height+buf, w-buf*4, bch);
			[options addSubview:b];
			height += bch+buf*2;
			// View Challenges
			/*b = [UIButton buttonWithType:UIButtonTypeCustom];
			 [b setBackgroundImage:[Misc buttonCell] forState:UIControlStateNormal];
			 [b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
			 b.titleLabel.font = [UIFont systemFontOfSize:[Misc buttonFontSize]];
			 [b setTitle:@"Challenges" forState:UIControlStateNormal];
			 [b addTarget:self action:@selector(challenges) forControlEvents:UIControlEventTouchUpInside];
			 b.frame = CGRectMake(buf*2, height+buf, w-buf*4, bch);
			 [options addSubview:b];
			 height += bch+buf*2;*/
		}
		/*
		 // Pass Leader
		 if ([users count]>1) {
		 b = [UIButton buttonWithType:UIButtonTypeCustom];
		 [b setBackgroundImage:[Misc buttonCell] forState:UIControlStateNormal];
		 [b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
		 b.titleLabel.font = [UIFont systemFontOfSize:[Misc buttonFontSize]];
		 [b setTitle:@"Pass Leader" forState:UIControlStateNormal];
		 [b addTarget:self action:@selector(pass) forControlEvents:UIControlEventTouchUpInside];
		 b.frame = CGRectMake(buf*2, height+buf, w-buf*4, bch);
		 [options addSubview:b];
		 height += bch+buf*2;
		 }
		 // Invite Followers
		 if ([users count]<5) {
		 b = [UIButton buttonWithType:UIButtonTypeCustom];
		 [b setBackgroundImage:[Misc buttonCell] forState:UIControlStateNormal];
		 [b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
		 b.titleLabel.font = [UIFont systemFontOfSize:[Misc buttonFontSize]];
		 [b setTitle:@"Invite Followers" forState:UIControlStateNormal];
		 [b addTarget:self action:@selector(invFol) forControlEvents:UIControlEventTouchUpInside];
		 b.frame = CGRectMake(buf*2, height+buf, w-buf*4, bch);
		 [options addSubview:b];
		 height += bch+buf*2;
		 }
		 */
		options.frame = CGRectMake(0, -height, w, height);
	}
	
	CGRect f = options.frame;
	double y = f.origin.y;
	CGSize z = f.size;
	[UIView beginAnimations:@"moreOptions" context:nil];
	[UIView setAnimationDuration:[Misc animations]];
	options.frame = CGRectMake(0, y==0?-z.height:0, z.width, z.height);
	[UIView commitAnimations];
}

- (void)scholarships {
	SearchTable *v = [[SearchTable alloc]init];
	v.type = @"Scholarships";
	v.party = self;
	[self.navigationController pushViewController:v animated:YES];
	[v release];
}

- (void)accept:(NSString*)pnm {
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = NO;
	NSURLResponse *r;
	NSError *e;
	
	NSString *p = [NSString stringWithFormat:
				   @"&uid=0&pnm=%@&acp=1",
				   [pnm urlEncode]];
	
	NSString *urlContents = [KuippConnect formTo:@"updatePartyInvite" WithPost:p AndResponse:&r AndError:&e];
	
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:[NSString stringWithFormat:@"Welcome to %@!",pnm]
						  message:[NSString stringWithFormat:@"You have joined %@!",pnm]
						  delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];
	[alert release];
}

//
- (void)rankings {
	
}

//
- (void)challenges {
	
}

- (void)start {
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Cancel"];
	[(UIButton*)self.navigationItem.leftBarButtonItem.customView addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"Submit"];
	[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(submit) forControlEvents:UIControlEventTouchUpInside];
}

- (void)cancel {
	self.navigationItem.leftBarButtonItem = [Misc pointBarButtonItem:@"Back"];
	[(UIButton*)self.navigationItem.leftBarButtonItem.customView addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	
	self.navigationItem.rightBarButtonItem = [Misc barButtonItemViewWithTitle:@"More"];
	[(UIButton*)self.navigationItem.rightBarButtonItem.customView addTarget:self action:@selector(more) forControlEvents:UIControlEventTouchUpInside];
	
	[name resignFirstResponder];
}

- (void)memberMore:(UIButton*)sender {
	int row = sender.tag;
	NSMutableDictionary *d = [NSMutableDictionary dictionaryWithDictionary:[users objectAtIndex:row-1]];
	
	[d setObject:@"1" forKey:@"more"];
	
	[users replaceObjectAtIndex:row-1 withObject:d];
	
	NSArray *ips = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:row inSection:0]];
	[table reloadRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationLeft];
}

- (void)memberCancel:(UIButton*)sender {
	int row = sender.tag;
	NSMutableDictionary *d = [NSMutableDictionary dictionaryWithDictionary:[users objectAtIndex:row-1]];
	
	[d removeObjectForKey:@"more"];
	
	[users replaceObjectAtIndex:row-1 withObject:d];
	
	NSArray *ips = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:row inSection:0]];
	[table reloadRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationRight];
}

- (void)newLeader:(UIButton*)sender {
	BOOL myParty = [[party objectForKey:@"leaderID"]intValue]==[[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue];
	
	NSDictionary	*d		= [users objectAtIndex:sender.tag-1];
	int				 iid	= [[d objectForKey:@"userID"]intValue];
	NSString		*first	= [d objectForKey:@"firstName"];
	NSString		*last	= [d objectForKey:@"lastName"];
	NSString		*iName	= [Misc first:first lastName:last];
	
	if (myParty) [self promote:iid withName:iName];
	else [self nominate:iid withName:iName];
}

- (void)promote:(int)iid withName:(NSString*)n {
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = NO;
	NSURLResponse *r;
	NSError *e;
	
	NSString *p = [NSString stringWithFormat:
				   @"&uid=0&iid=%d",
				   iid];
	
	NSString *urlContents = [KuippConnect formTo:@"updatePartyLeader" WithPost:p AndResponse:&r AndError:&e];
	
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[self refreshAll];
	
	int pl = [[party objectForKey:@"level"]intValue];
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Leadership Passed On!"
						  message:[NSString stringWithFormat:@"You have promoted %@ to be the %@'s %@!",n,[Misc partyLevel:pl],[Misc partyLeader:pl]]
						  delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];
	[alert release];
}

- (void)nominate:(int)iid withName:(NSString*)n {
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = NO;
	NSURLResponse *r;
	NSError *e;
	
	NSString *p = [NSString stringWithFormat:
				   @"&uid=0&iid=%d",
				   iid];
	
	NSString *urlContents = [KuippConnect formTo:@"updatePartyNominate" WithPost:p AndResponse:&r AndError:&e];
	
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[self refreshAll];
	
	int pl = [[party objectForKey:@"level"]intValue];
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Nomination Made!"
						  message:[NSString stringWithFormat:@"You have nominated %@ to be the %@'s %@!",n,[Misc partyLevel:pl],[Misc partyLeader:pl]]
						  delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];
	[alert release];
}

- (void)voteOff:(UIButton*)sender {
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = NO;
	NSURLResponse *r;
	NSError *e;
	
	NSDictionary	*d	= [users objectAtIndex:sender.tag-1];
	int				 iid	= [[d objectForKey:@"userID"]intValue];
	NSString		*first	= [d objectForKey:@"firstName"];
	NSString		*last	= [d objectForKey:@"lastName"];
	NSString		*n		= [Misc first:first lastName:last];
	
	
	NSString *p = [NSString stringWithFormat:
				   @"&uid=0&iid=%d",
				   iid];
	
	NSString *urlContents = [KuippConnect formTo:@"insertPartyKick" WithPost:p AndResponse:&r AndError:&e];
	
	((UIButton*)self.navigationItem.rightBarButtonItem.customView).userInteractionEnabled = YES;
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect checkSessionCode:urlContents forView:self]) return;
	
	[self refreshAll];
	
	int pl = [[party objectForKey:@"level"]intValue];
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Vote Registered!"
						  message:[NSString stringWithFormat:@"You have voted to kick %@ out of the %@!",n,[Misc partyLevel:pl]]
						  delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];
	[alert release];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return [users count]+1;}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *c = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"A"];
	if (!c) c = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"A"]autorelease];
	
	//double buf = [Misc buffer];
	int myID = [[[NSUserDefaults standardUserDefaults]objectForKey:@"userID"]intValue];
	BOOL myParty = party?[[party objectForKey:@"leaderID"]intValue]==myID:NO;
	BOOL myPage = [uid intValue]==myID;
	UIButton *b;
	
	if (indexPath.row==0) {
		if (party) {
			// Party Cell
			if (myPage) {
				if (myParty) {
					b = (UIButton*)[Misc barButtonItemViewWithTitle:@"Invite"].customView;
					[b addTarget:self action:@selector(invFol) forControlEvents:UIControlEventTouchUpInside];
				} else {
					b = (UIButton*)[Misc barButtonItemViewWithTitle:@"Leave"].customView;
					[b addTarget:self action:@selector(leave) forControlEvents:UIControlEventTouchUpInside];
				}
				c.accessoryView = b;
			}
			c.textLabel.text = [party objectForKey:@"name"];
		} else if (myPage) {
			// Create Button
			ButtonCell *c = (ButtonCell*)[tableView dequeueReusableCellWithIdentifier:@"B"];
			if (!c) c = [[[ButtonCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"B"]autorelease];
			
			[c.button setTitle:@"Create a New Party" forState:UIControlStateNormal];
			[c.button addTarget:self action:@selector(create) forControlEvents:UIControlEventTouchUpInside];
			return c;
		}
	} else {
		// Party Member Cells
		NSDictionary *d = [users objectAtIndex:indexPath.row-1];
		if ([d objectForKey:@"more"]) {
			UIView *v = [[UIView alloc]init];
			v.backgroundColor = [UIColor blackColor];
			
			double buf = [Misc buffer];
			double ch = table.frame.size.height/6;
			double x = buf;
			
			b = (UIButton*)[Misc barButtonItemViewWithTitle:myParty?@"Promote":@"Nominate"].customView;
			[b addTarget:self action:@selector(newLeader:) forControlEvents:UIControlEventTouchUpInside];
			b.tag = indexPath.row;
			double h = b.frame.size.height;
			double y = (ch-h)/2;
			b.frame = CGRectMake(x, y, b.frame.size.width, h);
			[v addSubview:b];
			x += b.frame.size.width+buf;
			
			b = (UIButton*)[Misc barButtonItemViewWithTitle:@"Vote Off"].customView;
			[b addTarget:self action:@selector(voteOff:) forControlEvents:UIControlEventTouchUpInside];
			b.tag = indexPath.row;
			b.frame = CGRectMake(x, y, b.frame.size.width, h);
			[v addSubview:b];
			x += b.frame.size.width+buf;
			
			b = (UIButton*)[Misc barButtonItemViewWithTitle:@"Cancel"].customView;
			[b addTarget:self action:@selector(memberCancel:) forControlEvents:UIControlEventTouchUpInside];
			b.tag = indexPath.row;
			b.frame = CGRectMake(x, y, b.frame.size.width, h);
			[v addSubview:b];
			x += b.frame.size.width+buf;
			
			v.frame = CGRectMake(0, 0, x, ch);
			
			c.accessoryView = v;
			[v release];
		} else if (myPage) {
			if ([[d objectForKey:@"userID"]intValue]!=myID) {
				b = (UIButton*)[Misc barButtonItemViewWithTitle:@"More"].customView;
				[b addTarget:self action:@selector(memberMore:) forControlEvents:UIControlEventTouchUpInside];
				b.tag = indexPath.row;
			} else {
				b = nil;
			}
			c.accessoryView = b;
		}
		
		c.textLabel.text = [Misc first:[d objectForKey:@"firstName"]lastName:[d objectForKey:@"lastName"]];
	}
	
	c.selectionStyle = UITableViewCellSelectionStyleNone;
	
	return c;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark -
#pragma mark Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {return !party?[Misc buttonCellHeight]+[Misc buffer]*2:table.frame.size.height/6;}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {[tableView deselectRowAtIndexPath:indexPath animated:YES];}

#pragma mark -
#pragma mark UIScrollView

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		if (!refreshCell.flipped) [refreshCell flip];
	} else {
		if (refreshCell.flipped) [refreshCell flip];
	}
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (scrollView!=table) return;
	CGPoint s = scrollView.contentOffset;
	if (s.y<0&&![kuipp fetchingData]) {
		[self refreshAll];
	}
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	CGRect kb;
	[[info objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&kb];
	
	CGRect t = top.frame;
	double tx = t.origin.x;
	double tw = t.size.width;
	double th = t.size.height;
	CGRect b = bot.frame;
	double bx = b.origin.x;
	double bw = b.size.width;
	double bh = b.size.height;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	top.frame = CGRectMake(tx,-200+delta*200,tw,th);
	bot.frame = CGRectMake(bx,367-delta*(kb.size.height-49),bw,bh);
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {[self keyboardAdjust:note:1];}

- (void)keyboardWasHidden:(NSNotification*)note {[self keyboardAdjust:note:0];}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[self submit];
	return NO;
}

#pragma mark -
#pragma mark Initialization
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)viewDidLoad {
    [super viewDidLoad];
	
	[Misc load:self];
	
	if (self==[[self.navigationController viewControllers]objectAtIndex:0]) self.navigationItem.leftBarButtonItem = nil;
	
	double r = [Misc refreshCellHeight];
	refreshCell = [Misc refreshCellView];
	refreshCell.table = table;
	refreshCell.frame = CGRectMake(0, 0, self.view.frame.size.width, r);
	[table setTableHeaderView:refreshCell];
	
	table.contentInset = UIEdgeInsetsMake(-r,0,0,0);
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(aSyncImageLoaded) name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refresh:) name:@"connectionFinished" object:self];
	
	kuipp = [[KuippConnect alloc]init];
	kuipp.owner = self;
	
	if (options) {
		[options removeFromSuperview];
		[options release];
		options = nil;
	}
	
	[self refreshAll];
}

- (void)viewWillDisappear:(BOOL)animated {
	[kuipp cancel];
	[kuipp release];
	kuipp = nil;
	
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"aSyncImageLoaded" object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:@"connectionFinished" object:self];
	
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {return [Misc orientations:interfaceOrientation];}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[uid release];
	
    [super dealloc];
}

@end
