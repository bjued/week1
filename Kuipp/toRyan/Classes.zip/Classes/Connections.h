//
//  Connections.h
//  Kuipp
//
//  Created by Brandon Jue on 1/4/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Connections : UIViewController <UITableViewDelegate,UITextFieldDelegate,UISearchBarDelegate> {
	NSString *uid;
	
	KuippConnect *kuipp;
	NSMutableArray *dicts;
	NSMutableArray *tabArray;
	NSMutableArray *searchArray;
	NSMutableDictionary *images;
	
	RefreshCell *refreshCell;
	UIActivityIndicatorView *moreCell;
	
	NSMutableArray *lastIDs;
	NSMutableArray *counts;
	
	int tab;
	
	IBOutlet UIView *bar;
	IBOutlet UISearchBar *search;
	IBOutlet UITableView *table;
	
	IBOutlet UIButton* followingButton;
	IBOutlet UIButton* followersButton;
}

@property(nonatomic,assign) int tab;
@property(nonatomic,retain) NSString *uid;
- (void)back;
- (void)mainThreadImages;
- (void)aSyncImageLoaded;
- (void)refreshAll;
- (void)refreshMore;
- (void)refresh:(id)obj;
- (IBAction)following:(UIButton*)sender;
- (IBAction)followers:(UIButton*)sender;
- (void)selectTab:(UIButton*)sender;
- (IBAction)backgroundTouched:(UIControl*)sender;
- (void)deleteFollowing:(int)index;
- (void)findFriends;
- (void)keyboardAdjust:(NSNotification *)note :(int)delta;
- (void)keyboardWasShown:(NSNotification*)note;
- (void)keyboardWasHidden:(NSNotification*)note;

@end
