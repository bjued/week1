//
//  RegisterView.m
//  Kuipp
//
//  Created by Brandon Jue on 12/14/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "RegisterView.h"
#import "Settings.h"

@implementation RegisterView

- (void)back {[self.navigationController popViewControllerAnimated:YES];}

- (IBAction)facebookPressed:(UIButton*)sender {
	facebook = ((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).facebook;
	
	NSArray *permissions = [[Misc facebookPermissions]retain];
	
	[facebook authorize:permissions delegate:self];
	
	[permissions release];
}

- (IBAction)registerPressed:(UIButton*)sender {
	NSString *msg = @"";
	if (![password.text isEqualToString:confirm.text]) msg = @"Your Passwords don't match!";
	if ([password.text length]==0) msg = @"You need a Password!";
	NSRange at = [email.text rangeOfString:@"@"];
	if (at.length!=0) {
		NSString *svr = [email.text substringFromIndex:at.location+at.length];
		NSRange per = [svr rangeOfString:@"."];
		if ([email.text length]==0||per.length==0||per.location==0||per.length+per.location==[svr length]) msg = @"You need a valid Email Address!";
	} else msg = @"You need a valid Email Address!";
	if ([lName.text length]==0) msg = @"You need a Last Name!";
	if ([fName.text length]==0) msg = @"You need a First Name!";
	
	if (![msg isEqualToString:@""]) {
		NSLog(@"%@ - %@",@"Oops!",msg);
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Oops!"
							  message:msg
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
		return;
	}
	
	NSURLResponse *response;
	NSError *error;
	
	NSString *poststring = [NSString stringWithFormat:
							@"&pwd=%@"
							@"&fnm=%@"
							@"&lnm=%@"
							@"&wml=%@"
							@"&fbid=%@",
							password.text,
							fName.text,
							lName.text,
							email.text,
							facebookID];
	
	NSString *urlContents = [KuippConnect formTo:@"insertUser" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect errorCode:urlContents]) return;
	
	poststring = [NSString stringWithFormat:
				  @"&eml=%@"
				  @"&pwd=%@",
				  email.text,
				  password.text];
	
	urlContents = [KuippConnect formTo:@"login" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	if (![KuippConnect errorCode:urlContents]) return;
	
	NSMutableArray *dicts = [[NSMutableArray alloc]init];
	
	Parser *parse = [[Parser alloc]initWithDicts:dicts];
	[parse parseXML:[urlContents substringFromIndex:1]];
	[parse release];
	
	if ([dicts count]==1) {
		NSUserDefaults *save = [NSUserDefaults standardUserDefaults];
		NSDictionary *d = [dicts objectAtIndex:0];
		
		for (NSString *key in [d allKeys]) [save setObject:[d objectForKey:key] forKey:key];
	}
	
	[dicts release];
	
	[facebookID release];
	
	KuippAppDelegate *delegate = (KuippAppDelegate*)[[UIApplication sharedApplication]delegate];
	[delegate firstLogin];
}

- (IBAction)backgroundTouched:(UIControl*)sender {
	[password resignFirstResponder];
	[confirm resignFirstResponder];
	[fName resignFirstResponder];
	[lName resignFirstResponder];
	[email resignFirstResponder];
}

#pragma mark -
#pragma mark FBRequestDelegate

- (void)request:(FBRequest *)request didLoad:(id)result {
	if ([result isKindOfClass:[NSDictionary class]]) {
		fName.text = [NSString stringWithString:[result objectForKey:@"first_name"]];
		lName.text = [NSString stringWithString:[result objectForKey:@"last_name"]];
		email.text = [NSString stringWithString:[result objectForKey:@"email"]];
		[facebookID release];
		facebookID = [[NSString alloc]initWithString:[result objectForKey:@"id"]];
	}	
}

- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {NSLog(@"%@",error);}

#pragma mark -
#pragma mark FBSessionDelegate

- (void)fbDidLogin {
	// Pull registration data
	[facebook requestWithGraphPath:@"me" andDelegate:self];
}

- (void)fbDidNotLogin:(BOOL)cancelled {
	// Don't pull registration data
}

#pragma mark -
#pragma mark KeyboardMethods

- (void)keyboardAdjust:(NSNotification*)note:(int)delta {
	if (viewMoved&&delta==1) return;
	
	NSDictionary *info = [note userInfo];
	NSTimeInterval animationDuration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey]doubleValue];
	
	int shiftView = 216-96;
	
	CGRect frame = self.view.frame;
	frame.origin.y -= delta*shiftView;
	frame.size.height += delta*shiftView;
	
	[UIView beginAnimations:@"ResizeForKeyboard" context:nil];
	[UIView setAnimationDuration:animationDuration];
	self.view.frame = frame;
	[UIView commitAnimations];
}

- (void)keyboardWasShown:(NSNotification*)note {
	[self keyboardAdjust:note:1];
	viewMoved = YES;
}

- (void)keyboardWasHidden:(NSNotification*)note {
    if (!viewMoved) return;
	[self keyboardAdjust:note:-1];
	viewMoved = NO;
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[textField resignFirstResponder];
	return YES;
}

#pragma mark -
#pragma mark Initializaion
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	[Misc load:self];
	
	facebookID = [[NSString alloc]initWithString:@"0"];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
	[super viewWillDisappear:animated];
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return [Misc orientations:interfaceOrientation];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}

@end
