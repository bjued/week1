//
//  UpdateCell3.m
//  Kuipp
//
//  Created by Brandon Jue on 1/29/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "UpdateCell3.h"
#import "KuippAppDelegate.h"
#import "Profile.h"

@implementation UpdateCell3

@synthesize nameID1,nameID2,picLeft,name1,primary1,name2,primary2,picRight,secondary;

- (IBAction)name1Touched:(UIButton*)sender {
	Profile *v = [[Profile alloc]init];
	v.uid = nameID1;
	[((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).navigationController pushViewController:v animated:YES];
	[v release];
}

- (IBAction)name2Touched:(UIButton*)sender {
	Profile *v = [[Profile alloc]init];
	v.uid = nameID2;
	[((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).navigationController pushViewController:v animated:YES];
	[v release];
}

#pragma mark -
#pragma mark Initialization

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad {
 [super viewDidLoad];
 }
 */

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)dealloc {
	[nameID1 release];
	[nameID2 release];
	[picLeft release];
	[name1 release];
	[primary1 release];
	[name2 release];
	[primary2 release];
	[picRight release];
	[secondary release];
	
    [super dealloc];
}

@end
