<?
$pnTypes = array(
	'default' => array('alert' => 'This is the alert text', 'badge' => 1, 'sound' => 'default')
	);
?>
