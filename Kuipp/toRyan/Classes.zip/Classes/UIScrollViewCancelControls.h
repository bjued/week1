//
//  UIScrollViewCancelControls.h
//  Kuipp
//
//  Created by Brandon Jue on 3/17/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollViewCancelControls : UIScrollView {
}

- (BOOL)touchesShouldCancelInContentView:(UIView*)view;

@end
