//
//  LeaderCell.h
//  Kuipp
//
//  Created by Brandon Jue on 3/14/11.
//  Copyright 2011 Kuipp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeaderCell : UITableViewCell {
	BOOL selectable;
	
	NSDictionary *dict;
	
	UIView *cell;
	UIView *imgV;
	
	UILabel *rank;
	UIImageView *mark;
	UIImageView *imag;
	UILabel *name;
	UILabel *foot;
}

@property(nonatomic,assign) BOOL selectable;
@property(nonatomic,retain) NSDictionary *dict;
@property(nonatomic,retain) UILabel *rank,*name,*foot;
@property(nonatomic,retain) UIImageView *mark,*imag;

@end
