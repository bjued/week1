//
//  AnswerCell.m
//  Kuipp
//
//  Created by Brandon Jue on 1/31/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import "AnswerCell.h"
#import "Answer.h"
#import "KuippConnect.h"
#import "KuippAppDelegate.h"

@implementation AnswerCell

@synthesize pic,header,primary,classname,time,like,slash,dislike,comments,flag,dict;

- (IBAction)likeIt:(UIButton*)sender {
	check = YES;
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Confirm Like"
						  message:@"Are you sure you LIKE this answer?"
						  delegate:self
						  cancelButtonTitle:@"Cancel"
						  otherButtonTitles:@"I like it",nil];
	[alert show];
	[alert release];
}

- (IBAction)dislikeIt:(UIButton*)sender {
	check = NO;
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Confirm Dislike"
						  message:@"Are you sure you DISLIKE this answer?"
						  delegate:self
						  cancelButtonTitle:@"Cancel"
						  otherButtonTitles:@"I dislike it",nil];
	[alert show];
	[alert release];
}

- (void)likeDislike {
	[manager stopUpdatingLocation];
	
	NSURLResponse *response;
	NSError *error;
	
	CLLocation *loc = [[CLLocation alloc]initWithLatitude:[[dict objectForKey:@"latitude"]doubleValue]longitude:[[dict objectForKey:@"longitude"]doubleValue]];
	NSString *poststring = [NSString stringWithFormat:
							@"&userID=0"
							@"&answerID=%@"
							@"&latitude=%.8f"
							@"&longitude=%.8f"
							@"&doLike=%@"
							@"&dist=%f",
							[dict objectForKey:@"answerID"],
							userLoc.coordinate.latitude,
							userLoc.coordinate.longitude,
							check?@"on":@"off",
							fabs([loc distanceFromLocation:userLoc]/1609.344)];
	[loc release];
	
	NSString *urlContents = [KuippConnect formTo:@"insertLikeDislike" WithPost:poststring AndResponse:&response AndError:&error];
	
	if ([urlContents length]==0) return;
	
	int exitCode = [[urlContents substringToIndex:2]intValue];
	
	if (![KuippConnect checkSessionCode:exitCode/10 forView:nil]) return;
	if (![KuippConnect answerCode:exitCode%10 forView:nil]) return;
	
	NSString *message = [NSString stringWithFormat:
						 @"Now %@ %@ %@.\'s Answer",
						 check?@"liking":@"disliking",
						 [dict objectForKey:@"firstName"],
						 [[dict objectForKey:@"lastName"]substringToIndex:1]];
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Success"
						  message:message
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
	if ([self.superview isKindOfClass:[UITableView class]]) {
		[(Answer*)((UITableView*)self.superview).delegate refresh:nil];
	}
}

#pragma mark -
#pragma mark CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager*)manager didUpdateToLocation:(CLLocation*)newLocation fromLocation:(CLLocation*)oldLocation {
	userLoc = newLocation;
	
	[self likeDislike];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
	NSLog(@"%@",error);
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Session Error"]) {
		[((KuippAppDelegate*)[[UIApplication sharedApplication]delegate]).navigationController popToRootViewControllerAnimated:YES];
	} else if (([alertView.title isEqualToString:@"Confirm Like"]||[alertView.title isEqualToString:@"Confirm Dislike"])&&buttonIndex==1) {
		manager = [[CLLocationManager alloc]init];
		[manager setDelegate:self];
		[manager startUpdatingLocation];
	}
}

- (void)dealloc {
	[pic release];
	[header release];
	[primary release];
	[classname release];
	[time release];
	[like release];
	[slash release];
	[dislike release];
	[comments release];
	[flag release];
	
	[dict release];
	
	[manager release];
	
    [super dealloc];
}

@end
