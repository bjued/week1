//
//  Parser.m
//  Kuipp
//
//  Created by Brandon Jue on 12/19/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "Parser.h"

@implementation Parser

- (id)initWithDicts:(NSMutableArray*)d {
	if ((self=[super init])) {
		dicts = d;
	}
	return self;
}

- (void)parseXML:(NSString*)s {
	/* s =  <?xml~?>
	 <xml>
	 <Person>
	 <name>Bob</name>
	 <age>23</age>
	 </Person>
	 <Item>
	 <thing>Joe</thing>
	 <age>3</age>
	 </Item>
	 </xml>
	 */
	NSRange r = [s rangeOfString:@"<?xml version="];
	s = [s substringFromIndex:r.location+r.length];
	r = [s rangeOfString:@"><"];
	s = [s substringFromIndex:r.location+r.length];
	// s = xml><Person><name>Bob</name><age>23</age></Person><Item><thing>Joe</thing><age>3</age></Item></xml>
	r = [s rangeOfString:@">"];
	NSString *items = [s substringToIndex:r.location];
	// items = xml
	s = [s substringFromIndex:r.location+1];
	// s = <Person><name>Bob</name><age>23</age></Person><Item><thing>Joe</thing><age>3</age></Item></xml>
	r = [s rangeOfString:[NSString stringWithFormat:@"</%@>",items]];
	s = [s substringToIndex:r.location];
	// s = <Person><name>Bob</name><age>23</age></Person><Item><thing>Joe</thing><age>3</age></Item>
	
	[self parseItems:s];
}

- (void)parseItems:(NSString*)s {
	/* s =  <Person>
	 <name>Bob</name>
	 <age>23</age>
	 </Person>
	 <Item>
	 <thing>Joe</thing>
	 <age>3</age>
	 </Item>
	 */
	NSString *item;
	NSRange r = [s rangeOfString:@">"];
	while (r.length>0) {
		s = [s substringFromIndex:1];
		// s = Person><name>Bob</name><age>23</age></Person><Item><thing>Joe</thing><age>3</age></Item>
		item = [s substringToIndex:r.location-1];
		// item = Person
		s = [s substringFromIndex:r.location];
		// s = <name>Bob</name><age>23</age></Person><Item><thing>Joe</thing><age>3</age></Item>
		r = [s rangeOfString:[NSString stringWithFormat:@"</%@>",item]];
		[self parseFields:[s substringToIndex:r.location]andHead:item];
		// passed = <name>Bob</name><age>23</age>
		s = [s substringFromIndex:r.location+r.length];
		// s = <Item><thing>Joe</thing><age>3</age></Item>
		
		r = [s rangeOfString:@">"];
	}
}

- (void)parseFields:(NSString*)s andHead:(NSString*)h {
	/* s =	<name>Bob</name>
	 <age>23</age>
	 */
	NSString *field;
	NSMutableDictionary *fields = [[NSMutableDictionary alloc]init];
	[fields setObject:h forKey:@"head"];
	NSRange r = [s rangeOfString:@">"];
	while (r.length>0) {
		s = [s substringFromIndex:1];
		// s = name>Bob</name><age>23</age>
		field = [s substringToIndex:r.location-1];
		// field = name
		s = [s substringFromIndex:r.location];
		// s = Bob</name><age>23</age>
		r = [s rangeOfString:[NSString stringWithFormat:@"</%@>",field]];
		[fields setObject:[s substringToIndex:r.location] forKey:field];
		// fields['field'] = Bob
		s = [s substringFromIndex:r.location+r.length];
		// s = <age>23</age>
		
		r = [s rangeOfString:@">"];
	}
	[dicts addObject:fields];
	[fields release];
}

@end
