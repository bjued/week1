//
//  UserCell.h
//  Kuipp
//
//  Created by Brandon Jue on 2/1/11.
//  Copyright 2011 Kuipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserCell : UITableViewCell {
	IBOutlet UIImageView *pic;
	IBOutlet UILabel *name;
	IBOutlet UILabel *primary;
}

@property(nonatomic,retain) UIImageView *pic;
@property(nonatomic,retain) UILabel *name;
@property(nonatomic,retain) UILabel *primary;

@end
