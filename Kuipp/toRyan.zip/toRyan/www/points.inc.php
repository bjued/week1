<?
// Points awarded for actions
$pointsQuestion			= 2;
$pointsAnswer			= 3;
$pointsLikeDislike		= 1;

$pointsGainFollower		= 1;
$pointsLoseFollower		= -1;
$pointsGainLike			= 1;
$pointsGainDislike		= -1;

$pointsAnswerUnder2		= 10;
$pointsAnswerUnder5		= 5;
$pointsAnswerUnder15	= 3;
$pointsAnswerUnder30	= 2;
$pointsAnswerUnder60	= 1;

$pointsAnswerWithin1	= 3;
$pointsAnswerWithin3	= 2;
$pointsAnswerWithin10	= 1;

$pointsLikeDisUnder5	= 5;
$pointsLikeDisUnder15	= 3;
$pointsLikeDisUnder30	= 2;
$pointsLikeDisUnder60	= 1;

$pointsLikeDisWithin3	= 2;
$pointsLikeDisWithin10	= 1;

// Coins awarded for actions
$coinsGainFollower		= 1;

$coinsAnswerUnder2		= 3;
$coinsAnswerUnder5		= 2;
$coinsAnswerUnder15		= 1;

$coinsAnswerWithin1		= 1;

$coinsLikeDisUnder5		= 2;
$coinsLikeDisUnder15	= 1;
?>
