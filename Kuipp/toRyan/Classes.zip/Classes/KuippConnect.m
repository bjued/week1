//
//  KuippConnect.m
//  Kuipp
//
//  Created by Brandon Jue on 12/26/10.
//  Copyright 2010 Kuipp. All rights reserved.
//

#import "KuippConnect.h"

@implementation KuippConnect

@synthesize owner,data;

+ (NSString*)urlString:(NSString*)page {
	UIDevice *d = [UIDevice currentDevice];
	NSBundle *b = [NSBundle mainBundle];
	NSUserDefaults *u = [NSUserDefaults standardUserDefaults];
	
	NSString* model = @"Simulator";
	NSString *device = [d model];
	if ([device isEqualToString:@"iPhone"]) model = @"iPhone";
	else if ([device isEqualToString:@"iPod touch"]) model = @"iTouch";
	else if ([device isEqualToString:@"iPad"]) model = @"iPad";
	
	NSString *ver = [b objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
	NSString *key = [NSString stringWithFormat:@"%@.%@",
					 ver,
					 [b objectForInfoDictionaryKey:@"CFBundleVersion"]];
	
	return [NSString stringWithFormat:
			@"%@/%@.php?sid=%@&did=%@&dev=%@&iOS=%@&ver=%@",
			[Misc url],
			page,
			[u objectForKey:@"sessionID"],
			[d uniqueIdentifier],
			model,
			[d systemVersion],
			([Misc debug]||[Misc beta])?key:ver];
}

- (void)formTo:(NSString*)page {[self formTo:page WithPost:@""];}

- (void)formTo:(NSString*)page WithPost:(NSString*)poststring {
	NSData *postData = [poststring dataUsingEncoding:NSUTF8StringEncoding];
	NSString *postLen = [NSString stringWithFormat:@"%d",[postData length]];
	NSString *url = [KuippConnect urlString:page];
	NSMutableURLRequest *post = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
	[post setHTTPMethod:@"POST"];
	[post setHTTPBody:postData];
	[post setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
	[post setValue:postLen forHTTPHeaderField:@"content-length"];
	
	data = [[NSMutableData alloc]initWithCapacity:2048];
	connection = [NSURLConnection connectionWithRequest:post delegate:self];
}

- (void)cancel {if (connection) [connection cancel];connection = nil;}

- (BOOL)fetchingData {return connection!=nil;}

+ (NSString*)formTo:(NSString*)page WithPost:(NSString*)poststring AndResponse:(NSURLResponse**)response AndError:(NSError**)error {
	NSData *postData = [poststring dataUsingEncoding:NSUTF8StringEncoding];
	NSString *postLen = [NSString stringWithFormat:@"%d",[postData length]];
	NSString *url = [KuippConnect urlString:page];
	NSMutableURLRequest *post = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
	[post setHTTPMethod:@"POST"];
	[post setHTTPBody:postData];
	[post setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
	[post setValue:postLen forHTTPHeaderField:@"content-length"];
	 
	NSData *data = [NSURLConnection sendSynchronousRequest:post returningResponse:response error:error];
	
	NSString *urlContents = [[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]autorelease];
	
	if ([urlContents length]==0) {
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Cannot Connect To Internet"
							  message:@"Kuipp cannot fulfill the request because it is not connected to the Internet."
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
	}

	if ([Misc debug]) NSLog(@"Sync: %@",urlContents);
	
	return urlContents;
}

+ (NSString*)connectionData:(NSData*)d {
	NSString *urlContents = [[[NSString alloc]initWithData:d encoding:NSUTF8StringEncoding]autorelease];
	
	if ([urlContents length]==0) {
		UIAlertView *alert = [[UIAlertView alloc]
							  initWithTitle:@"Cannot Connect To Internet"
							  message:@"Kuipp cannot fulfill the request because it is not connected to the Internet."
							  delegate:self
							  cancelButtonTitle:@"OK"
							  otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
	
	if ([Misc debug]) NSLog(@"ASync: %@",urlContents);
	
	return urlContents;
}

- (void)connection:(NSURLConnection*)c didReceiveData:(NSData*)d {[data appendData:d];}

- (void)connectionDidFinishLoading:(NSURLConnection*)c {
	[[NSNotificationCenter defaultCenter]postNotificationName:@"connectionFinished" object:owner];
	connection = nil;
}

- (void)connection:(NSURLConnection*)c didFailWithError:(NSError*)e {
	NSLog(@"%@",e);
	connection = nil;
}

+ (BOOL)checkSessionCode:(NSString*)code forView:(UIViewController*)view {
	UIAlertView *alert;
	switch ([[code substringToIndex:1]intValue]) {
		case  1:
			NSLog(@"Device/Session not in table");
			alert = [[UIAlertView alloc]
					 initWithTitle:@"Session Error"
					 message:@"You do not have a Session."
					 delegate:self
					 cancelButtonTitle:@"OK"
					 otherButtonTitles:nil];
			[alert show];
			[alert release];
			return NO;
		default: {
			NSString *c = [code substringFromIndex:1];
			NSUserDefaults *s = [NSUserDefaults standardUserDefaults];
			
			NSRange x = [c rangeOfString:@"<versionUpdate>"];
			if (x.length>0) {
				NSRange y = [c rangeOfString:@"</versionUpdate>"];
				NSString *ver = [[c substringToIndex:y.location]substringFromIndex:x.location+x.length];
				c = [c substringFromIndex:y.location+y.length];
				
				NSString *bld = [NSString stringWithString:ver];
				int i = 0;
				
				x =  [bld rangeOfString:@"."];
				while (x.length>0) {
					bld = [bld substringFromIndex:x.location+x.length];
					x =  [bld rangeOfString:@"."];
					i++;
					NSLog(@"%d",i);
				}
				
				ver = [ver substringToIndex:[ver length]-[bld length]-1];
				
				if (![ver isEqualToString:@""]&&![s objectForKey:ver]) {
					[s setObject:@"1" forKey:ver];
					NSString *msg = [Misc newVersion:ver WithBuild:([Misc debug]||[Misc beta])?bld:nil];
					
					alert = [[UIAlertView alloc]
							 initWithTitle:@"Update Available"
							 message:msg
							 delegate:self
							 cancelButtonTitle:@"Ignore"
							 otherButtonTitles:@"Update",nil];
					[alert show];
					[alert release];
					[msg release];
				}
			}
			
			NSMutableArray *badges = [[NSMutableArray alloc]initWithCapacity:4];
			for (int i=0;i<4;i++) {
				NSRange r = [c rangeOfString:@"<422>"];
				if (r.length>0) {
					c = [c substringFromIndex:r.location+r.length];
					r = [c rangeOfString:@"</422>"];
					[badges addObject:[c substringToIndex:r.location]];
					c = [c substringFromIndex:r.location+r.length];
				}
			}
			KuippAppDelegate *delegate = (KuippAppDelegate*)[UIApplication sharedApplication].delegate;
			NSArray *vcs = delegate.tabBarController.viewControllers;
			for (int i=0;i<[badges count];i++)
				if ([[badges objectAtIndex:i]intValue]>0)
					[[[vcs objectAtIndex:i+1]tabBarItem]setBadgeValue:[badges objectAtIndex:i]];
			[delegate.tabBarController setViewControllers:vcs animated:YES];
			[badges release];
			
			return [KuippConnect errorCode:c];
		}
	}
}

+ (BOOL)errorCode:(NSString*)err {
	if ([err length]==0) return YES;
	
	if ([[err substringToIndex:1]intValue]==0) return YES;
	NSRange r = [err rangeOfString:@" - "];
	NSString *ttl = [[err substringFromIndex:1]substringToIndex:r.location];
	NSString *msg = [err substringFromIndex:r.location+r.length];
	NSLog(@"%@ - %@",ttl,msg);
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:ttl
						  message:msg
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];
	return NO;
}

#pragma mark -
#pragma mark UIAlertViewDelegate

+ (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ([alertView.title isEqualToString:@"Session Error"]) {
		[(KuippAppDelegate*)[UIApplication sharedApplication].delegate toLogin];
	}
	if ([alertView.title isEqualToString:@"Update Available"]) {
		if (buttonIndex==1) {
			NSURLResponse *r;
			NSError *e;
			
			NSString *urlContents = [KuippConnect formTo:@"appUpdate" WithPost:@"" AndResponse:&r AndError:&e];
			
			if ([urlContents length]==0) return;
			
			[[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlContents]];
		}
	}
}

- (void)dealloc {
	[owner release];
	[data release];
	
	[super dealloc];
}

@end
